"""Local standard-library HTTP interface for PLAN's assessment workspace."""
from __future__ import annotations

import argparse
import base64
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

if __package__:
    from . import engine, exports
    from .workspace import Workspace, Conflict, SCHEMA, _json
else:
    import engine
    import exports
    from workspace import Workspace, Conflict, SCHEMA, _json

ROOT = Path(__file__).resolve().parent
MAX_JSON_BYTES = 72 * 1024 * 1024
MAX_RESTORE_JSON_BYTES = 256 * 1024 * 1024


def catalog():
    evidence = {"provider_id": None, "title": "", "kind": "observation", "classification": "lsp_confidential", "source_url": "", "locator": "", "summary": "", "limitations": "", "version": ""}
    templates = {
        "providers": {"name": "", "category": "unspecified", "candidate_ids": [], "roster_status": "proposed", "roster_rationale": "", "context": "", "success_statement": "", "evidence_refs": [], "local_success_refs": []},
        "evidence": evidence,
        "offices": {"provider_id": "", "name": "", "status": "reported", "location": "", "notes": "", "evidence_refs": []},
        "channels": {"provider_id": "", "name": "", "kind": "telephone", "office_ids": [], "status": "reported", "centralized": None, "availability": "", "evidence_refs": []},
        "metric_definitions": {"provider_id": "", "name": "", "type": "channel_volume", "version": "1", "unit": "", "counting_unit": "", "population": "", "numerator_definition": "", "denominator_definition": "", "exclusions": "", "clock": "elapsed", "decision_kind": "unspecified", "outcome_mapping": {}, "short_abandon_rule": None, "evidence_refs": []},
        "measurements": {"provider_id": "", "definition_id": "", "basis": "aggregate", "period": {"start": "", "end": "", "cutoff": "", "timezone": "America/New_York"}, "values": {}, "events": [], "office_ids": [], "channel_ids": [], "numerator_channel_ids": [], "sample_status": "unknown", "aggregation": {"mode": "unknown", "basis": "", "evidence_refs": []}, "evidence_refs": []},
        "workflows": {"provider_id": "", "name": "", "status": "draft", "office_ids": [], "channel_ids": [], "nodes": [], "edges": [], "review_basis": "", "evidence_refs": []},
        "recommendations": {"provider_id": None, "title": "", "problem": "", "action": "", "status": "proposed", "horizon": "near_term", "priority": "unranked", "owner_role": "", "dependencies": [], "prerequisites": [], "duration_workdays": None, "effort_person_days": None, "cost": None, "estimate_basis": "", "governance": "", "accessibility": "", "vendor_rfp_needed": False, "deliverables": "", "acceptance": "", "evidence_refs": []},
        "network_findings": {"title": "", "body": "", "provider_ids": [], "measurement_ids": [], "recommendation_ids": [], "evidence_refs": [], "presentation": "aggregate", "aggregation": "none"},
        "permissions": {"provider_id": None, "finding_id": "", "authority": "plan", "decision": "pending", "position": "not_stated", "target_digest": "", "basis": "", "recorded_by": "", "evidence_refs": []},
    }
    for template in templates.values():
        template["id"] = ""
    source_contract = None
    path = ROOT / "demo" / "sources" / "phase1-source-contract.json"
    if path.exists():
        original = _json(path.read_bytes())
        source_contract = {key: original[key] for key in ("source_rfp", "requirements", "proposed_metric_contracts", "proposed_relationships", "source_milestones", "submission") if key in original}
    return {"engine_schema": engine.SCHEMA, "workspace_schema": SCHEMA, "collections": list(engine.COLLECTIONS), "channel_kinds": list(engine.CHANNEL_KINDS),
            "metric_types": engine.METRIC_CATALOG, "record_templates": templates, "timestamp_fields": list(engine.TIMESTAMP_FIELDS), "source_contract": source_contract,
            "workflow_template": {"name": "Local intake pathway — collection template", "status": "draft", "notes": "Authored interview template. Replace steps and branches with the source-supported local process; this is not a reported provider workflow.",
                                  "nodes": [{"id": "contact", "label": "Contact enters this pathway", "kind": "start", "role": "Applicant / referring partner"}, {"id": "access", "label": "Identify access and language needs", "kind": "action", "role": "Intake staff"}, {"id": "triage", "label": "Local eligibility or referral decision", "kind": "decision", "role": "Responsible local reviewer"}, {"id": "handoff", "label": "Follow the local handoff", "kind": "handoff", "role": "Assigned local role"}, {"id": "close", "label": "Record the source outcome", "kind": "end", "role": "Responsible local reviewer"}],
                                  "edges": [{"from": "contact", "to": "access", "label": "Observed intake route"}, {"from": "access", "to": "triage", "label": "Local process"}, {"from": "triage", "to": "handoff", "label": "Document the actual branch"}, {"from": "handoff", "to": "close", "label": "Document the actual outcome"}]},
            "audiences": ["lsp", "plan_restricted", "consolidated"], "archive_audiences": ["private_restore", "lsp", "plan_restricted", "consolidated"],
            "consolidation_decisions": {"plan": ["approved", "changes_requested", "withdrawn", "pending"], "lsp": ["consulted", "pending"], "position": ["supports", "objects", "mixed", "not_stated"]},
            "operations": ["record.save", "record.delete", "evidence.add", "measurement.import", "measurement.rebind", "recommendation.decide", "project.rename", "scope.save"]}


def handler_for(workspace):
    class Handler(BaseHTTPRequestHandler):
        server_version = "PLANAssessment/0.1"
        protocol_version = "HTTP/1.1"

        def setup(self):
            super().setup()
            self.connection.settimeout(30)

        def log_message(self, format, *args):
            sys.stderr.write(f"{self.log_date_time_string()} {format % args}\n")

        def send(self, body, content_type="application/json; charset=utf-8", status=200, filename=None):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, ensure_ascii=False, allow_nan=False).encode()
            elif isinstance(body, str):
                body = body.encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
            if filename:
                self.send_header("Content-Disposition", 'attachment; filename="' + exports.safe_name(filename) + '"')
            self.end_headers()
            self.wfile.write(body)

        def check_origin(self):
            allowed = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
            if self.headers.get("Host") not in allowed:
                raise ValueError("Open the local workbench address printed by the server.")
            origin = self.headers.get("Origin")
            if origin and (urlsplit(origin).scheme != "http" or urlsplit(origin).netloc not in allowed):
                raise ValueError("This local operator workspace does not accept cross-origin requests.")

        def body(self, maximum=MAX_JSON_BYTES):
            if self.headers.get("Transfer-Encoding"):
                raise ValueError("Send this bounded JSON request with an explicit Content-Length.")
            if self.headers.get("Content-Type", "").split(";", 1)[0].strip() != "application/json":
                raise ValueError("This endpoint accepts application/json.")
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > maximum:
                raise ValueError("The JSON request is empty or exceeds this endpoint's size limit.")
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("The request ended before its declared content length.")
            result = _json(raw)
            if not isinstance(result, dict):
                raise ValueError("Request body must be a JSON object.")
            return result

        def do_GET(self):
            try:
                self.check_origin()
                url = urlsplit(self.path)
                bits = [part for part in url.path.split("/") if part]
                query = {key: values[0] for key, values in parse_qs(url.query).items()}
                if not bits or bits == ["index.html"]:
                    return self.send((ROOT / "web/index.html").read_bytes(), "text/html; charset=utf-8")
                if len(bits) == 1 and bits[0] in ("app.js", "styles.css", "style.css"):
                    return self.send((ROOT / "web" / bits[0]).read_bytes(), "application/javascript; charset=utf-8" if bits[0].endswith(".js") else "text/css; charset=utf-8")
                if bits == ["api", "status"]:
                    return self.send({"workspace_schema": SCHEMA, "engine_schema": engine.SCHEMA, "mode": "local_operator", "runtime_dependencies": [], "network_clients": 0})
                if bits == ["api", "catalog"]:
                    return self.send(catalog())
                if bits == ["api", "projects"]:
                    return self.send(workspace.list_projects())
                if len(bits) >= 3 and bits[:2] == ["api", "projects"]:
                    project_id = bits[2]
                    if len(bits) == 3:
                        return self.send(workspace.get(project_id))
                    if bits[3:] == ["history"]:
                        return self.send(workspace.history(project_id, query.get("offset", 0), query.get("limit", 100)))
                    if len(bits) in (5, 6) and bits[3] == "records":
                        if len(bits) == 6:
                            return self.send(workspace.record(project_id, bits[4], bits[5]))
                        return self.send(workspace.records(project_id, bits[4], query.get("offset", 0), query.get("limit", 100)))
                    if bits[3:] == ["events"]:
                        return self.send(workspace.measurement_events(project_id, query["measurement_id"], query.get("offset", 0), query.get("limit", 100)))
                    if len(bits) == 5 and bits[3] == "files":
                        raw, original = workspace.original(project_id, bits[4])
                        return self.send(raw, "application/octet-stream", filename=original["filename"])
                    if bits[3:] == ["projection"]:
                        return self.send(workspace.projection(project_id, query.get("audience", "consolidated"), query.get("provider_id")))
                    if bits[3:] == ["report"]:
                        projection = workspace.projection(project_id, query.get("audience", "consolidated"), query.get("provider_id"))
                        return self.send(exports.report_html(projection), "text/html; charset=utf-8")
                    if bits[3:] == ["export"]:
                        audience = query.get("audience", "private_restore")
                        data, manifest = exports.export_project(workspace, project_id, audience, query.get("provider_id"))
                        return self.send(data, "application/zip", filename=f"plan-{audience}-{project_id}-r{manifest['revision']}.zip")
                return self.send({"error": "Resource not found."}, status=404)
            except Exception as exc:
                self.error(exc)

        def do_POST(self):
            try:
                self.check_origin()
                bits = [part for part in urlsplit(self.path).path.split("/") if part]
                maximum = MAX_RESTORE_JSON_BYTES if bits == ["api", "restore"] else MAX_JSON_BYTES
                body = self.body(maximum)
                if bits == ["api", "projects"]:
                    return self.send(workspace.create(body.get("name"), body.get("actor", "Operator")), status=201)
                if bits == ["api", "demo"]:
                    if __package__:
                        from .demo import seed_demo
                    else:
                        from demo import seed_demo
                    return self.send(seed_demo(workspace), status=201)
                if bits == ["api", "restore"]:
                    encoded = body.get("content_base64")
                    if not isinstance(encoded, str):
                        raise ValueError("Restore needs the complete ZIP as content_base64.")
                    return self.send(exports.import_project(workspace, base64.b64decode(encoded, validate=True)))
                if len(bits) == 4 and bits[:2] == ["api", "projects"] and bits[3] == "operations":
                    return self.send(workspace.apply(bits[2], body["operation"], body.get("payload", {}), body["expected_revision"], body["request_id"], body.get("actor", "Operator")))
                return self.send({"error": "Endpoint not found."}, status=404)
            except Exception as exc:
                self.error(exc)

        def error(self, exc):
            if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
                return
            # Discard unread content after a rejected request before reusing the socket.
            self.close_connection = True
            if isinstance(exc, Conflict):
                return self.send({"error": str(exc), "current_revision": exc.current_revision, "input_preserved": True}, status=409)
            if isinstance(exc, (KeyError, FileNotFoundError)):
                return self.send({"error": str(exc).strip("'")}, status=404)
            if isinstance(exc, (ValueError, TypeError, UnicodeError)):
                return self.send({"error": str(exc)}, status=400)
            sys.stderr.write("PLAN workspace failure: " + type(exc).__name__ + "\n")
            return self.send({"error": "The operation could not complete. Its transaction was not partially saved."}, status=500)
    return Handler


def main(argv=None):
    parser = argparse.ArgumentParser(description="PLAN Phase 1 independent intake assessment workbench")
    parser.add_argument("--workspace", type=Path, default=Path("plan-workspace"))
    parser.add_argument("--port", type=int, default=8769)
    parser.add_argument("--demo", action="store_true", help="Load the original public PLAN sources once")
    parser.add_argument("--restore", type=Path, help="Restore a complete private project ZIP before serving")
    parser.add_argument("--export", metavar="PROJECT_ID", help="Export an existing project and exit")
    parser.add_argument("--audience", choices=("private_restore", "lsp", "plan_restricted", "consolidated"), default="private_restore")
    parser.add_argument("--provider-id", help="Required for an LSP recipient report")
    parser.add_argument("--output", type=Path, help="ZIP output path for --export")
    args = parser.parse_args(argv)
    workspace = Workspace(args.workspace / "projects.sqlite3")
    if args.restore:
        print(json.dumps(exports.import_project(workspace, args.restore.read_bytes())))
    if args.demo:
        if __package__:
            from .demo import seed_demo
        else:
            from demo import seed_demo
        print(json.dumps(seed_demo(workspace)))
    if args.export:
        if not args.output:
            parser.error("--export requires --output")
        raw, manifest = exports.export_project(workspace, args.export, args.audience, args.provider_id)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_bytes(raw)
        print(json.dumps({"output": str(args.output), "project_id": manifest["project_id"], "revision": manifest["revision"], "audience": manifest["audience"], "bytes": len(raw)}))
        return
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler_for(workspace))
    print(f"PLAN assessment workbench: http://127.0.0.1:{server.server_port}", flush=True)
    print(f"Workspace: {args.workspace.resolve()}", flush=True)
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
