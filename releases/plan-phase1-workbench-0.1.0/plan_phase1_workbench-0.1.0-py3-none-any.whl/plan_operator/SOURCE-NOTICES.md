# Original public source material

The application code and its authored technical documentation use the MIT license in `LICENSE`. Original publications retain their own ownership and terms. No PLAN affiliation, procurement award, provider engagement or publication license is created by this demonstration.

The exact original bytes, URLs, acquisition facts, checksums and derivation descriptions are identified in `demo/sources/source_manifest.json`. The public demonstration contains these source groups:

| Material | Publisher / original location | Treatment |
| --- | --- | --- |
| PLAN Phase 1 RFP, issued September 24, 2026 | [Original RFP hosted by LSNTAP](https://www.lsntap.org/sites/default/files/2026-09/plan-statewide-intake-improvement-project-phase-1-assessment-and-planning-rfp-issue-2026-09-24-1.pdf) | Original 11-page PDF retained; OCR is a derived reading aid and the PDF controls |
| Network overview | [Pennsylvania Legal Aid Network](https://palegalaid.net/overview) | Original downloaded HTML retained |
| Regional program directory | [PLAN regional legal-aid programs](https://palegalaid.net/plan-regional-legal-aid-programs) | Original HTML and explicitly derived candidate records retained |
| Specialty program directory | [PLAN specialty legal-aid programs](https://palegalaid.net/plan-specialty-legal-aid-program) | Original HTML and explicitly derived candidate records retained |
| Source contract and collection workstreams | Authored from the retained RFP and directory pages | Proposed application behavior is separated from published requirements; these records are not reported operating findings |

Directory spellings and counts remain source facts. Fourteen public program entries are candidates for explicit engagement mapping; the RFP specifies thirteen assessment units. The six published program-office counts total forty-eight, which is a different quantity from the RFP's forty-eight offices offering walk-in intake. The source records preserve both meanings.

The installable source package contains public reference inputs only. Actual organization records added by an operator belong to that operator's separate workspace and appear only in the chosen project/report export scope.

