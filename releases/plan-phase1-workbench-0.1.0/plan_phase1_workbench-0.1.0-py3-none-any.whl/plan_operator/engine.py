"""Source-bound, individualized PLAN Phase 1 assessment engine.

The caller owns storage, authentication, source files and revision history. This
module performs no network, model, database or outbound-message operation. Public
provider candidates remain separate from the engagement roster. Published count
contexts, observed baselines, locally selected success criteria and proposed
implementation estimates retain their distinct meanings.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from copy import deepcopy
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import re
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


SCHEMA = "plan.individual-assessment/v1"
COLLECTIONS = ("candidates", "providers", "offices", "channels", "evidence", "metric_definitions", "measurements", "workflows", "recommendations", "permissions", "network_findings")
CHANNEL_KINDS = ("telephone", "hotline", "online", "walk_in", "partner_referral", "outreach_clinic", "mail", "other")
METRIC_TYPES = ("channel_volume", "channel_share", "call_wait", "call_talk", "intake_decision_time", "abandonment", "capacity", "local_success")
TIMESTAMP_FIELDS = ("occurred_at", "queue_entered_at", "answered_at", "ended_at", "first_contact_at", "decision_at", "wrap_completed_at")
METRIC_CATALOG = [
    {"type": "channel_volume", "name": "Intake volume by channel", "kind": "count", "unit": "source-defined intake units", "source_section": "5.2", "required_definition": "Define whether a unit is a call attempt, contact, application, intake or person; retain channel/office assignment and duplicate handling."},
    {"type": "channel_share", "name": "Channel share", "kind": "proportion", "unit": "percent", "source_section": "5.2", "required_definition": "Use numerator and denominator from the same LSP, cohort and counting unit. Multi-touch channels can overlap; shares need not sum to 100 percent."},
    {"type": "call_wait", "name": "Time waiting for an answer", "kind": "duration", "unit": "seconds", "source_section": "5.2", "required_definition": "Queue entry to answer for answered interactions. Keep abandonment, still waiting, missing timestamps and the observation cutoff separate."},
    {"type": "call_talk", "name": "Call handling duration", "kind": "duration", "unit": "seconds", "source_section": "5.2", "required_definition": "Answer to the defined completion event; state call-leg and wrap-up treatment. Identify the completed-call denominator."},
    {"type": "intake_decision_time", "name": "First contact to a specified decision", "kind": "duration", "unit": "hours", "source_section": "5.2", "required_definition": "Define eligibility, case acceptance or rejection separately; retain a first-contact cohort, cutoff, pending cases and missing records."},
    {"type": "abandonment", "name": "Abandonment rate", "kind": "proportion", "unit": "percent", "source_section": "5.2", "required_definition": "Declare eligible offered interactions, terminal outcome mapping and any short-abandon exclusion before calculating the rate."},
    {"type": "capacity", "name": "Staffing and demand capacity", "kind": "capacity", "unit": "declared staff-pool time", "source_section": "5.2", "required_definition": "Keep intake and attorney capacity distinct. Bind staffing time, workload and demand to one period/pool; separate observed work from assumed handling time."},
    {"type": "local_success", "name": "Organization-defined success", "kind": "reported", "unit": "locally defined", "source_section": "5.2", "required_definition": "Record the LSP/PLAN success statement, baseline definition/version, target basis and the organization's capacity and client-access context. No common SLA is prescribed."},
]


class AssessmentError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def _text(value, label, required=False, limit=20000):
    if value is None and not required:
        return ""
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
        raise AssessmentError(f"{label} must be {'nonempty ' if required else ''}text of at most {limit:,} characters.")
    return value.strip()


def _id(value, label="Record ID"):
    value = _text(value, label, True, 100)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]*", value):
        raise AssessmentError(label + " must use letters, digits, period, underscore, colon or hyphen.")
    return value


def _choice(value, choices, label, default=None):
    value = default if value is None else value
    if value not in choices:
        raise AssessmentError(label + " must be one of: " + ", ".join(choices))
    return value


def _ids(value, label, limit=1000):
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > limit:
        raise AssessmentError(f"{label} must be a list with at most {limit} entries.")
    result = [_id(item, label) for item in value]
    if len(set(result)) != len(result):
        raise AssessmentError(label + " contains a repeated identifier.")
    return result


def _decimal(value, label, nonnegative=True):
    if isinstance(value, bool) or value is None:
        raise AssessmentError(label + " must be a finite number; missing is not zero.")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise AssessmentError(label + " must be a finite number.") from exc
    if not result.is_finite() or (nonnegative and result < 0):
        raise AssessmentError(label + " must be finite" + (" and nonnegative." if nonnegative else "."))
    return result


def _count(value, label):
    result = _decimal(value, label)
    if result != result.to_integral_value():
        raise AssessmentError(label + " must be a whole count.")
    return int(result)


def _number(value):
    return format(value, "f") if isinstance(value, Decimal) else str(value)


def _index(state, collection):
    return {record["id"]: record for record in state.get(collection, [])}


def _record(state, collection, record_id):
    record = _index(state, collection).get(record_id)
    if record is None:
        raise AssessmentError(f"{collection} does not contain record {record_id!r}.")
    return record


def _provider(state, provider_id):
    return _record(state, "providers", _id(provider_id, "Provider ID"))


def _references(state, ids, provider_id=None, allow_cross_provider=False):
    refs = _ids(ids, "Evidence references")
    for ref in refs:
        evidence = _record(state, "evidence", ref)
        if not allow_cross_provider and evidence.get("provider_id") not in (None, provider_id):
            raise AssessmentError("A local record cannot reference another LSP's evidence identity. Use common public evidence with provider_id null, or a separately scoped network finding.")
    return refs


def _instant(value, label, zone=None):
    value = _text(value, label, True, 100)
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            if not zone:
                raise AssessmentError(label + " requires an explicit timezone for a date-only boundary.")
            result = datetime.combine(date.fromisoformat(value), time(), ZoneInfo(zone))
        else:
            result = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if result.tzinfo is None or result.utcoffset() is None:
                raise AssessmentError(label + " must include a UTC offset; resolve ambiguous source-local timestamps before importing.")
        return result.astimezone(timezone.utc)
    except (ValueError, ZoneInfoNotFoundError) as exc:
        if isinstance(exc, AssessmentError):
            raise
        raise AssessmentError(label + " is not an ISO date/time with an explicit valid timezone.") from exc


def _period(value):
    if not isinstance(value, dict):
        raise AssessmentError("Measurement period must define start, end, cutoff and timezone.")
    zone = _text(value.get("timezone"), "Period timezone", True, 100)
    try:
        ZoneInfo(zone)
    except ZoneInfoNotFoundError as exc:
        raise AssessmentError("Period timezone must be a valid IANA timezone.") from exc
    start = _instant(value.get("start"), "Period start", zone)
    end = _instant(value.get("end"), "Period end", zone)
    cutoff = _instant(value.get("cutoff"), "Observation cutoff", zone)
    if end <= start or cutoff < start:
        raise AssessmentError("The period must end after its start, and its observation cutoff cannot precede the start.")
    return {"start": value["start"], "end": value["end"], "cutoff": value["cutoff"], "timezone": zone, "boundary": "start_inclusive_end_exclusive"}


def new_assessment(name, candidates=None, source_refs=None):
    """Create an empty assessment with source-grounded public context.

    candidates accepts the acquired {records:[...]} object or that records list.
    It creates candidate identities only, never contracted provider identities.
    """
    records = candidates.get("records", []) if isinstance(candidates, dict) else candidates or []
    if not isinstance(records, list):
        raise AssessmentError("Public provider candidates must be a records list.")
    result = {"schema": SCHEMA, "name": _text(name, "Assessment name", True, 200), "source_refs": deepcopy(source_refs or []),
              "scope": {"lsp_count": 13, "regional_count": 7, "specialized_count": 6, "office_count": 67,
                        "assessment_months": [9, 12], "scope_source": "PLAN RFP sections 1–3, issue 2026-09-24",
                        "reported_office_channels": [{"channel": "walk_in", "count": 48}, {"channel": "telephone_hotline_host", "count": 22}],
                        "reference_count_meaning": "Published network context, not named-office assignments; channel sets may overlap.",
                        "appendix_a": "Anonymized organization-level profiles are available on request; they are not supplied inside the public RFP.",
                        "phase": "Independent assessments and planning; future design and implementation depend on accepted findings and separately scoped work."},
              **{collection: [] for collection in COLLECTIONS}}
    for record in records:
        item = deepcopy(record)
        item["id"] = item.get("id") or "candidate-" + digest({"name": item.get("name_published"), "link": item.get("published_link"), "source": item.get("source_sha256")})[:20]
        item["project_roster_mapping"] = None
        result["candidates"].append(item)
    if len({item["id"] for item in result["candidates"]}) != len(result["candidates"]):
        raise AssessmentError("The public candidate source repeats an identity; retain and resolve that source explicitly.")
    return result


def validate_record(collection, record, state):
    """Normalize one operator record against current source/provider identities.

    Persist the returned object. Unknown fields are retained only on acquired
    public candidates; all other records have an explicit product schema so an
    audience projection cannot accidentally copy an unrelated payload.
    """
    if collection not in COLLECTIONS or not isinstance(record, dict):
        raise AssessmentError("Select a known assessment collection and a record object.")
    raw = deepcopy(record)
    result = {"id": _id(raw.get("id"))}
    if collection == "candidates":
        result.update(raw)
        result["name_published"] = _text(raw.get("name_published"), "Published candidate name", True, 300)
        result["group_published"] = _choice(raw.get("group_published"), ("regional", "specialized"), "Published candidate group")
        return result
    if collection == "providers":
        result.update({"name": _text(raw.get("name"), "Assessment provider name", True, 300), "category": _choice(raw.get("category"), ("regional", "specialized", "unspecified"), "Provider category", "unspecified"),
                       "candidate_ids": _ids(raw.get("candidate_ids"), "Public candidate IDs"), "roster_status": _choice(raw.get("roster_status"), ("proposed", "confirmed", "excluded", "ambiguous"), "Roster status", "proposed"),
                       "roster_rationale": _text(raw.get("roster_rationale"), "Roster rationale"), "context": _text(raw.get("context"), "Provider context"),
                       "success_statement": _text(raw.get("success_statement"), "Local success statement"), "recommendations_requested": raw.get("recommendations_requested"),
                       "evidence_refs": _references(state, raw.get("evidence_refs"), result["id"]), "local_success_refs": _references(state, raw.get("local_success_refs"), result["id"])})
        if result["recommendations_requested"] not in (None, True, False):
            raise AssessmentError("Whether an LSP requested recommendations must be true, false or unknown.")
        for candidate in result["candidate_ids"]:
            _record(state, "candidates", candidate)
        if result["roster_status"] in ("confirmed", "excluded") and (not result["roster_rationale"] or not result["evidence_refs"]):
            raise AssessmentError("A confirmed or excluded roster decision needs its actual rationale and source evidence.")
        if result["roster_status"] == "confirmed":
            for provider in state.get("providers", []):
                if provider["id"] != result["id"] and provider.get("roster_status") == "confirmed" and set(provider.get("candidate_ids", [])) & set(result["candidate_ids"]):
                    raise AssessmentError("A public candidate is already mapped to another confirmed assessment unit; resolve the roster relationship explicitly.")
        return result
    provider_id = raw.get("provider_id")
    if provider_id is not None:
        _provider(state, provider_id)
    if collection not in ("evidence", "recommendations", "permissions", "network_findings") and provider_id is None:
        raise AssessmentError("This record must belong to one independent LSP assessment.")
    if collection == "evidence":
        result.update({"provider_id": provider_id, "title": _text(raw.get("title"), "Evidence title", True, 300),
                       "kind": _choice(raw.get("kind"), ("public_document", "system_export", "interview", "survey", "observation", "meeting_notes", "consultation", "permission", "authored_example"), "Evidence kind"),
                       "classification": _choice(raw.get("classification"), ("public", "lsp_confidential", "restricted"), "Evidence classification", "lsp_confidential"),
                       "source_file_id": _text(raw.get("source_file_id"), "Original file ID", limit=300), "source_sha256": _text(raw.get("source_sha256"), "Original SHA-256", limit=64),
                       "source_url": _text(raw.get("source_url"), "Source URL", limit=4000), "locator": _text(raw.get("locator"), "Source page/row/section locator"),
                       "summary": _text(raw.get("summary"), "Evidence summary"), "limitations": _text(raw.get("limitations"), "Evidence limitations"),
                       "observed_at": _text(raw.get("observed_at"), "Observed at", limit=100), "version": _text(raw.get("version"), "Evidence version", limit=200)})
        if result["source_sha256"] and not re.fullmatch(r"[0-9a-f]{64}", result["source_sha256"]):
            raise AssessmentError("Original source SHA-256 must be a lowercase 64-character hex digest.")
        return result
    if collection in ("offices", "channels", "metric_definitions", "measurements", "workflows", "recommendations"):
        result["provider_id"] = provider_id
        result["evidence_refs"] = _references(state, raw.get("evidence_refs"), provider_id, collection == "recommendations" and provider_id is None)
    if collection == "offices":
        result.update({"name": _text(raw.get("name"), "Office name", True, 300), "status": _choice(raw.get("status"), ("observed", "reported", "proposed", "closed"), "Office status", "reported"),
                       "location": _text(raw.get("location"), "Office location", limit=1000), "notes": _text(raw.get("notes"), "Office notes")})
    elif collection == "channels":
        result.update({"name": _text(raw.get("name"), "Channel name", True, 300), "kind": _choice(raw.get("kind"), CHANNEL_KINDS, "Intake channel"),
                       "office_ids": _ids(raw.get("office_ids"), "Channel office IDs"), "status": _choice(raw.get("status"), ("observed", "reported", "proposed", "inactive"), "Channel status", "reported"),
                       "centralized": raw.get("centralized"), "availability": _text(raw.get("availability"), "Channel availability"), "notes": _text(raw.get("notes"), "Channel notes")})
        if result["centralized"] not in (None, True, False):
            raise AssessmentError("Centralized intake must be true, false or unknown.")
        for office_id in result["office_ids"]:
            if _record(state, "offices", office_id)["provider_id"] != provider_id:
                raise AssessmentError("An intake channel cannot assign a confidential office from another LSP.")
    elif collection == "metric_definitions":
        metric_type = _choice(raw.get("type"), METRIC_TYPES, "Metric type")
        catalog = next(item for item in METRIC_CATALOG if item["type"] == metric_type)
        result.update({"type": metric_type, "name": _text(raw.get("name") or catalog["name"], "Metric name", True, 300), "version": _text(raw.get("version") or "1", "Metric definition version", True, 100),
                       "unit": _text(raw.get("unit") or catalog["unit"], "Metric unit", True, 100), "counting_unit": _text(raw.get("counting_unit"), "Counting unit", limit=300),
                       "population": _text(raw.get("population"), "Eligible population"), "numerator_definition": _text(raw.get("numerator_definition"), "Numerator definition"),
                       "denominator_definition": _text(raw.get("denominator_definition"), "Denominator definition"), "exclusions": _text(raw.get("exclusions"), "Exclusion rules"),
                       "clock": _choice(raw.get("clock"), ("elapsed", "business", "reported"), "Metric clock", "elapsed"), "cohort_event": _choice(raw.get("cohort_event"), TIMESTAMP_FIELDS, "Cohort timestamp", {"call_wait": "queue_entered_at", "call_talk": "answered_at", "intake_decision_time": "first_contact_at", "abandonment": "queue_entered_at"}.get(metric_type, "occurred_at")),
                       "start_event": _choice(raw.get("start_event"), TIMESTAMP_FIELDS, "Duration start timestamp", {"call_wait": "queue_entered_at", "call_talk": "answered_at", "intake_decision_time": "first_contact_at"}.get(metric_type, "occurred_at")),
                       "end_event": _choice(raw.get("end_event"), TIMESTAMP_FIELDS, "Duration end timestamp", {"call_wait": "answered_at", "call_talk": "ended_at", "intake_decision_time": "decision_at"}.get(metric_type, "ended_at")),
                       "decision_kind": _choice(raw.get("decision_kind"), ("unspecified", "eligibility", "accepted", "rejected", "any_case_decision"), "Decision kind", "unspecified"),
                       "outcome_mapping": deepcopy(raw.get("outcome_mapping", {})), "short_abandon_rule": deepcopy(raw.get("short_abandon_rule")),
                       "business_calendar": deepcopy(raw.get("business_calendar")), "local_success_statement": _text(raw.get("local_success_statement"), "Local success statement"),
                       "target": deepcopy(raw.get("target")), "notes": _text(raw.get("notes"), "Metric notes")})
        if not isinstance(result["outcome_mapping"], dict) or any(not isinstance(key, str) or value not in ("answered", "abandoned", "pending", "ineligible", "other") for key, value in result["outcome_mapping"].items()):
            raise AssessmentError("Outcome mapping must map actual source labels to answered, abandoned, pending, ineligible or other.")
        if result["short_abandon_rule"] is not None:
            rule = result["short_abandon_rule"]
            if not isinstance(rule, dict) or rule.get("mode") not in ("include_all", "exclude_below"):
                raise AssessmentError("Short-abandon rule must explicitly include all or exclude below a declared number of seconds.")
            if rule["mode"] == "exclude_below":
                rule["seconds"] = _number(_decimal(rule.get("seconds"), "Short-abandon threshold"))
        if result["business_calendar"] is not None:
            result["business_calendar"] = _calendar(result["business_calendar"])
        if result["target"] is not None:
            target = result["target"]
            if not isinstance(target, dict):
                raise AssessmentError("A local metric target must state its value, direction and source basis.")
            result["target"] = {"value": _number(_decimal(target.get("value"), "Local target", False)), "direction": _choice(target.get("direction"), ("at_most", "at_least", "equal"), "Target direction"),
                                "basis": _text(target.get("basis"), "Target basis", True), "status": _choice(target.get("status"), ("proposed", "locally_agreed"), "Target status", "proposed")}
    elif collection == "measurements":
        definition = _record(state, "metric_definitions", raw.get("definition_id"))
        if definition["provider_id"] != provider_id:
            raise AssessmentError("A measurement must use its own LSP's metric definition.")
        result.update({"definition_id": definition["id"], "period": _period(raw.get("period")), "basis": _choice(raw.get("basis"), ("aggregate", "events", "reported"), "Measurement basis", "aggregate"),
                       "definition_digest": _text(raw.get("definition_digest", digest(definition)), "Bound metric definition digest", True, 64),
                       "source_import": deepcopy(raw.get("source_import")),
                       "values": deepcopy(raw.get("values", {})), "events": deepcopy(raw.get("events", [])), "office_ids": _ids(raw.get("office_ids"), "Measurement office IDs"),
                       "channel_ids": _ids(raw.get("channel_ids"), "Measurement channel IDs"), "numerator_channel_ids": _ids(raw.get("numerator_channel_ids"), "Numerator channel IDs"),
                       "sample_status": _choice(raw.get("sample_status"), ("complete_extract", "partial_extract", "sample", "reported", "unknown"), "Source coverage", "unknown"),
                       "identity_namespace": _text(raw.get("identity_namespace"), "Counting identity namespace", limit=300),
                       "aggregation": deepcopy(raw.get("aggregation", {"mode": "unknown", "basis": ""})), "notes": _text(raw.get("notes"), "Measurement notes")})
        if not isinstance(result["values"], dict) or not isinstance(result["events"], list) or len(result["events"]) > 100000:
            raise AssessmentError("Measurement values must be an object and events a list of at most 100,000 records.")
        if not re.fullmatch(r"[0-9a-f]{64}", result["definition_digest"]):
            raise AssessmentError("A measurement must bind the exact 64-character metric definition digest.")
        if result["source_import"] is not None:
            binding = result["source_import"]
            if not isinstance(binding, dict) or set(binding) != {"evidence_id", "source_file_id", "sha256", "format", "options", "field_map", "constants"}:
                raise AssessmentError("An imported event cohort must retain its exact source file, parsing options and field mapping.")
            if binding["evidence_id"] not in result["evidence_refs"] or not re.fullmatch(r"[0-9a-f]{64}", str(binding["sha256"])):
                raise AssessmentError("Imported events must reference their original evidence and SHA-256.")
            if len(canonical(binding)) > 20000:
                raise AssessmentError("Source mapping exceeds the supported 20,000-character metadata limit.")
        for key, value in result["values"].items():
            if key not in ("unit", "statistic", "assumption_basis", "staff_pool", "cohort_note"):
                if value is not None:
                    result["values"][key] = _number(_decimal(value, "Measurement " + key, key == "value" and definition["type"] != "local_success" or key != "value"))
        for field, target_collection in (("office_ids", "offices"), ("channel_ids", "channels"), ("numerator_channel_ids", "channels")):
            for record_id in result[field]:
                if _record(state, target_collection, record_id)["provider_id"] != provider_id:
                    raise AssessmentError("Measurement scope contains an office or channel from another LSP.")
        aggregation = result["aggregation"]
        if not isinstance(aggregation, dict):
            raise AssessmentError("Aggregation must state whether source populations are disjoint, overlapping or unknown.")
        result["aggregation"] = {"mode": _choice(aggregation.get("mode"), ("disjoint", "overlapping", "unknown"), "Population overlap", "unknown"), "basis": _text(aggregation.get("basis"), "Population-disjointness basis"),
                                 "evidence_refs": _references(state, aggregation.get("evidence_refs"), provider_id)}
        if result["aggregation"]["mode"] == "disjoint" and not result["aggregation"]["basis"]:
            raise AssessmentError("Declaring populations disjoint requires the source-specific basis.")
        allowed = {"unit_id", "office_id", "channel_ids", "outcome", "decision_kind", "source_row_ref", "exclusion_reason", *TIMESTAMP_FIELDS}
        events = []
        for event in result["events"]:
            if not isinstance(event, dict) or set(event) - allowed:
                raise AssessmentError("Map source events to unit_id, own office/channel IDs, declared timestamp/outcome fields and source_row_ref before assessment.")
            item = {key: deepcopy(value) for key, value in event.items()}
            item["unit_id"] = _text(event.get("unit_id"), "Source counting-unit ID", True, 500)
            item["channel_ids"] = _ids(event.get("channel_ids"), "Event channel IDs")
            for field in ("outcome", "source_row_ref", "exclusion_reason"):
                if field in item:
                    item[field] = _text(item[field], "Event " + field, limit=4000)
            if item.get("office_id"):
                item["office_id"] = _id(item["office_id"], "Event office ID")
            if item.get("office_id") and _record(state, "offices", item["office_id"])["provider_id"] != provider_id:
                raise AssessmentError("Event office belongs to another LSP.")
            for channel_id in item["channel_ids"]:
                if _record(state, "channels", channel_id)["provider_id"] != provider_id:
                    raise AssessmentError("Event channel belongs to another LSP.")
            for field in TIMESTAMP_FIELDS:
                if item.get(field):
                    _instant(item[field], field)
            if item.get("decision_kind") not in (None, "eligibility", "accepted", "rejected"):
                raise AssessmentError("Event decision_kind must retain eligibility, accepted or rejected as distinct outcomes.")
            events.append(item)
        result["events"] = events
    elif collection == "workflows":
        result.update({"name": _text(raw.get("name"), "Workflow name", True, 300), "status": _choice(raw.get("status"), ("draft", "reviewed"), "Workflow status", "draft"),
                       "office_ids": _ids(raw.get("office_ids"), "Workflow office IDs"), "channel_ids": _ids(raw.get("channel_ids"), "Workflow channel IDs"),
                       "nodes": deepcopy(raw.get("nodes", [])), "edges": deepcopy(raw.get("edges", [])), "notes": _text(raw.get("notes"), "Workflow notes"),
                       "review_basis": _text(raw.get("review_basis"), "Workflow review basis")})
        for field, target in (("office_ids", "offices"), ("channel_ids", "channels")):
            for record_id in result[field]:
                if _record(state, target, record_id)["provider_id"] != provider_id:
                    raise AssessmentError("Workflow scope must belong to this independent LSP.")
        _validate_flow(result)
        for part in result["nodes"] + result["edges"]:
            part["evidence_refs"] = _references(state, part["evidence_refs"], provider_id)
    elif collection == "recommendations":
        result.update({"title": _text(raw.get("title"), "Recommendation title", True, 300), "problem": _text(raw.get("problem"), "Source-specific problem"), "action": _text(raw.get("action"), "Recommended action", True),
                       "status": _choice(raw.get("status"), ("proposed", "accepted", "rejected", "completed"), "Recommendation decision", "proposed"), "decision_basis": _text(raw.get("decision_basis"), "Recommendation decision basis"),
                       "decision_actor": _text(raw.get("decision_actor"), "Recommendation decision actor", limit=300), "decision_at": _text(raw.get("decision_at"), "Recommendation decision time", limit=100),
                       "accepted_content_digest": _text(raw.get("accepted_content_digest"), "Accepted recommendation digest", limit=64),
                       "horizon": _choice(raw.get("horizon"), ("near_term", "longer_term"), "Recommendation horizon", "near_term"), "priority": _choice(raw.get("priority"), ("high", "medium", "low", "unranked"), "Recommendation priority", "unranked"),
                       "owner_role": _text(raw.get("owner_role"), "Accountable operating role", limit=500), "dependencies": _ids(raw.get("dependencies"), "Recommendation dependencies"),
                       "prerequisites": deepcopy(raw.get("prerequisites", [])), "duration_workdays": None, "effort_person_days": None, "cost": None,
                       "estimate_basis": _text(raw.get("estimate_basis"), "Estimate basis"), "governance": _text(raw.get("governance"), "Governance and sustainability"),
                       "accessibility": _text(raw.get("accessibility"), "Language/disability access implications"), "vendor_rfp_needed": bool(raw.get("vendor_rfp_needed", False)),
                       "deliverables": _text(raw.get("deliverables"), "Later-work deliverables"), "acceptance": _text(raw.get("acceptance"), "Later-work acceptance criteria")})
        if result["id"] in result["dependencies"]:
            raise AssessmentError("A recommendation cannot depend on itself.")
        for dependency in result["dependencies"]:
            other = _record(state, "recommendations", dependency)
            if provider_id is not None and other.get("provider_id") not in (None, provider_id):
                raise AssessmentError("A local dependency cannot expose another LSP's private recommendation. Use a separately documented network prerequisite.")
        for field in ("duration_workdays", "effort_person_days"):
            if raw.get(field) is not None and raw.get(field) != "":
                result[field] = _number(_decimal(raw[field], field))
        if raw.get("cost") is not None:
            cost = raw["cost"]
            if not isinstance(cost, dict) or not re.fullmatch(r"[A-Z]{3}", str(cost.get("currency", ""))):
                raise AssessmentError("Estimated cost requires an explicit currency code and amount.")
            result["cost"] = {"amount": _number(_decimal(cost.get("amount"), "Estimated cost")), "currency": cost["currency"]}
        if any(result[field] is not None for field in ("duration_workdays", "effort_person_days", "cost")) and not result["estimate_basis"]:
            raise AssessmentError("Proposed cost, elapsed workdays and person-effort estimates need their actual assumption basis.")
        if not isinstance(result["prerequisites"], list) or len(result["prerequisites"]) > 100:
            raise AssessmentError("Recommendation prerequisites must be a list of at most 100 records.")
        result["prerequisites"] = [{"name": _text(item.get("name"), "Prerequisite", True, 500), "owner_role": _text(item.get("owner_role"), "Prerequisite owner", limit=500),
                                    "status": _choice(item.get("status"), ("pending", "satisfied", "not_applicable"), "Prerequisite status", "pending"), "basis": _text(item.get("basis"), "Prerequisite status basis")} for item in result["prerequisites"]]
        if result["decision_at"]:
            _instant(result["decision_at"], "Recommendation decision time")
        if result["accepted_content_digest"] and not re.fullmatch(r"[0-9a-f]{64}", result["accepted_content_digest"]):
            raise AssessmentError("Accepted recommendation digest must be the exact 64-character content digest.")
    elif collection == "network_findings":
        result.update({"title": _text(raw.get("title"), "Network finding title", True, 300), "body": _text(raw.get("body"), "Network finding text", True, 40000),
                       "provider_ids": _ids(raw.get("provider_ids"), "Finding provider scope"), "measurement_ids": _ids(raw.get("measurement_ids"), "Finding measurements"),
                       "recommendation_ids": _ids(raw.get("recommendation_ids"), "Finding recommendations"), "evidence_refs": _references(state, raw.get("evidence_refs"), allow_cross_provider=True),
                       "presentation": _choice(raw.get("presentation"), ("attributed", "aggregate"), "Consolidated presentation", "aggregate"),
                       "aggregation": _choice(raw.get("aggregation"), ("none", "pooled"), "Measurement presentation", "none")})
        providers = set(result["provider_ids"])
        for provider in providers:
            _provider(state, provider)
        for target, ids in (("measurements", result["measurement_ids"]), ("recommendations", result["recommendation_ids"]), ("evidence", result["evidence_refs"])):
            for record_id in ids:
                dependency = _record(state, target, record_id)
                if dependency.get("provider_id") is not None:
                    providers.add(dependency["provider_id"])
        result["provider_ids"] = sorted(providers | _finding_providers(state, result))
        if result["presentation"] == "aggregate" and result["measurement_ids"] and result["aggregation"] != "pooled":
            raise AssessmentError("An aggregate finding cannot expose individual LSP metric rows; select pooled measurement output or omit metric rows.")
    elif collection == "permissions":
        target = _record(state, "network_findings", raw.get("finding_id"))
        authority = _choice(raw.get("authority"), ("plan", "lsp"), "Consolidated-use authority")
        if authority == "lsp" and provider_id not in _finding_providers(state, target):
            raise AssessmentError("This LSP is not in the consolidated finding's affected-provider scope.")
        if authority == "plan" and provider_id is not None:
            raise AssessmentError("A PLAN consolidation decision has provider_id null; affected LSP consultations are separate records.")
        result.update({"provider_id": provider_id, "finding_id": target["id"], "authority": authority,
                       "decision": _choice(raw.get("decision"), ("approved", "changes_requested", "withdrawn", "pending") if authority == "plan" else ("consulted", "pending"), "PLAN use decision or LSP consultation record", "pending"),
                       "position": _choice(raw.get("position"), ("supports", "objects", "mixed", "not_stated"), "Consulted party's recorded position", "not_stated"),
                       "target_digest": _text(raw.get("target_digest"), "Exact finding/dependency digest", True, 64), "basis": _text(raw.get("basis"), "PLAN decision or LSP consultation basis", True),
                       "recorded_by": _text(raw.get("recorded_by"), "Recorded decision maker", True, 300), "evidence_refs": _references(state, raw.get("evidence_refs"), provider_id, authority == "plan"),
                       "audience": "consolidated", "notes": _text(raw.get("notes"), "Decision notes")})
        if not re.fullmatch(r"[0-9a-f]{64}", result["target_digest"]):
            raise AssessmentError("A consolidation decision must bind the exact current 64-character finding/dependency digest.")
        if result["decision"] in ("approved", "consulted") and not result["evidence_refs"]:
            raise AssessmentError("Record the actual PLAN decision or applicable LSP consultation evidence for this exact consolidated use.")
        expected_versions = {key: digest(_record(state, "evidence", key)) for key in result["evidence_refs"]}
        versions = raw.get("evidence_versions", expected_versions)
        if not isinstance(versions, dict) or set(versions) != set(expected_versions) or any(not re.fullmatch(r"[0-9a-f]{64}", str(value)) for value in versions.values()):
            raise AssessmentError("Consultation evidence versions must bind each exact referenced source record.")
        result["evidence_versions"] = deepcopy(versions)
        consultations = raw.get("consultation_versions", _consultation_versions(state, target) if authority == "plan" else {})
        if not isinstance(consultations, dict) or any(not re.fullmatch(r"[0-9a-f]{64}", str(value)) for value in consultations.values()):
            raise AssessmentError("PLAN's use decision must retain exact consultation record versions.")
        for key in consultations:
            _id(key, "Consulted LSP identity")
        if authority == "lsp" and consultations:
            raise AssessmentError("An LSP records its own consultation; the consultation set is bound by PLAN's use decision.")
        result["consultation_versions"] = deepcopy(consultations)
        for permission in state.get("permissions", []):
            if permission["id"] != result["id"] and (permission["finding_id"], permission["authority"], permission.get("provider_id")) == (result["finding_id"], authority, provider_id):
                raise AssessmentError("Update the existing consolidation decision for this authority/finding so its history has one current disposition.")
    else:
        raise AssessmentError("Unhandled assessment collection.")
    return result


def _calendar(value):
    if not isinstance(value, dict):
        raise AssessmentError("A business clock requires an explicit timezone, weekday windows and holiday calendar.")
    zone = _text(value.get("timezone"), "Calendar timezone", True, 100)
    try:
        ZoneInfo(zone)
    except ZoneInfoNotFoundError as exc:
        raise AssessmentError("Business-calendar timezone is invalid.") from exc
    windows = value.get("windows")
    if not isinstance(windows, dict) or any(str(day) not in set(map(str, range(7))) for day in windows):
        raise AssessmentError("Calendar windows use weekday keys 0 (Monday) through 6 (Sunday).")
    def parse_windows(items):
        if not isinstance(items, list):
            raise AssessmentError("Each calendar day needs a list of [HH:MM, HH:MM] working windows.")
        parsed = []
        for item in items:
            if not isinstance(item, list) or len(item) != 2:
                raise AssessmentError("A business window has one opening and one closing time.")
            pair = []
            for offset, text in enumerate(item):
                if not isinstance(text, str) or not re.fullmatch(r"\d{2}:\d{2}", text):
                    raise AssessmentError("Business window times must use HH:MM.")
                hours, minutes = map(int, text.split(":"))
                if minutes > 59 or hours > 24 or hours == 24 and (minutes or not offset):
                    raise AssessmentError("Business windows may end at 24:00; other times must be valid same-day clock times.")
                pair.append(hours * 60 + minutes)
            if pair[1] <= pair[0] or any(pair[0] < b and pair[1] > a for a, b in parsed):
                raise AssessmentError("Business windows must be ordered and must not overlap within a day.")
            parsed.append(pair)
        return sorted(parsed)
    holidays = value.get("holidays", [])
    if not isinstance(holidays, list):
        raise AssessmentError("Calendar holidays must be explicit ISO dates.")
    try:
        holidays = sorted({date.fromisoformat(item).isoformat() for item in holidays})
    except (ValueError, TypeError) as exc:
        raise AssessmentError("Calendar holidays must be explicit ISO dates.") from exc
    # Store clock strings so normalized calendars can be validated again.
    normalized = {str(day): [[f"{a//60:02d}:{a%60:02d}", f"{b//60:02d}:{b%60:02d}"] for a, b in parse_windows(items)] for day, items in windows.items()}
    return {"timezone": zone, "windows": normalized, "holidays": holidays, "basis": _text(value.get("basis"), "Business-calendar source basis", True)}


def _elapsed_seconds(start, end):
    delta = end - start
    return Decimal(delta.days * 86400 + delta.seconds) + Decimal(delta.microseconds) / Decimal(1000000)


def _duration(start, end, definition):
    if end < start:
        raise AssessmentError("A completion timestamp precedes its defined starting event.")
    if definition["clock"] == "elapsed":
        seconds = _elapsed_seconds(start, end)
    elif definition["clock"] == "business":
        calendar = definition.get("business_calendar")
        if not calendar:
            raise AssessmentError("The business-time metric needs its actual local working calendar.")
        tz = ZoneInfo(calendar["timezone"])
        day, last = start.astimezone(tz).date(), end.astimezone(tz).date()
        if (last - day).days > 3660:
            raise AssessmentError("This assessment clock supports observation spans of at most ten years.")
        seconds = Decimal(0)
        while day <= last:
            if day.isoformat() not in calendar["holidays"]:
                for opens, closes in calendar["windows"].get(str(day.weekday()), []):
                    boundaries = []
                    for value in (opens, closes):
                        hours, minutes = map(int, value.split(":"))
                        local = datetime.combine(day, time(), tz) + timedelta(hours=hours, minutes=minutes)
                        if local.replace(fold=0).utcoffset() != local.replace(fold=1).utcoffset():
                            raise AssessmentError("A working-window boundary is ambiguous at a clock change; supply a source-resolved calendar window.")
                        utc = local.astimezone(timezone.utc)
                        if utc.astimezone(tz).replace(tzinfo=None) != local.replace(tzinfo=None):
                            raise AssessmentError("A working-window boundary falls in a nonexistent local clock time; resolve that calendar window.")
                        boundaries.append(utc)
                    a, b = max(start, boundaries[0]), min(end, boundaries[1])
                    if b > a:
                        seconds += _elapsed_seconds(a, b)
            day += timedelta(days=1)
    else:
        raise AssessmentError("A reported clock cannot be recomputed from timestamps; supply the source's aggregate result and clock definition.")
    divisor = {"seconds": Decimal(1), "minutes": Decimal(60), "hours": Decimal(3600), "days": Decimal(86400)}.get(definition["unit"])
    if divisor is None:
        raise AssessmentError("Timestamp-derived durations use seconds, minutes, hours or days.")
    return seconds / divisor


def _definition_gaps(definition):
    fields = ["counting_unit", "population"]
    if definition["type"] in ("channel_share", "abandonment"):
        fields += ["numerator_definition", "denominator_definition"]
    if definition["type"] in ("call_wait", "call_talk", "intake_decision_time"):
        fields += ["denominator_definition"]
    gaps = [field for field in fields if not definition.get(field)]
    if definition["type"] == "intake_decision_time" and definition["decision_kind"] == "unspecified":
        gaps.append("decision_kind")
    if definition["type"] == "abandonment" and definition.get("short_abandon_rule") is None:
        gaps.append("short_abandon_rule")
    if definition["clock"] == "business" and definition.get("business_calendar") is None:
        gaps.append("business_calendar")
    return gaps


def evaluate_measurement(state, measurement):
    """Calculate an exact declared cohort; preserve missing/pending denominators."""
    if isinstance(measurement, str):
        measurement = _record(state, "measurements", measurement)
    definition = _record(state, "metric_definitions", measurement["definition_id"])
    result = {"measurement_id": measurement["id"], "definition_id": definition["id"], "definition_version": definition["version"], "provider_id": measurement["provider_id"],
              "metric_type": definition["type"], "unit": definition["unit"], "period": deepcopy(measurement["period"]), "value": None, "evidence_refs": measurement["evidence_refs"],
              "source_coverage": measurement["sample_status"], "status": "not_measured", "qualifications": []}
    current_definition_digest = digest(definition)
    if measurement.get("definition_digest") != current_definition_digest:
        return result | {"status": "metric_definition_changed", "bound_definition_digest": measurement.get("definition_digest"), "current_definition_digest": current_definition_digest,
                         "required_input": "Reconcile this original cohort/aggregate with the changed definition before explicitly rebinding it; previous values are not relabeled automatically."}
    gaps = _definition_gaps(definition)
    if gaps:
        return result | {"status": "definition_incomplete", "required_definition_fields": gaps}
    if not measurement["evidence_refs"]:
        return result | {"status": "source_reference_required", "required_input": "Bind the actual source extract, workpaper or explicitly authored example."}
    values = measurement["values"]
    metric_type = definition["type"]
    if measurement["basis"] == "events":
        return _event_metric(definition, measurement, result)
    if metric_type == "capacity":
        available, observed = values.get("available_staff_time"), values.get("observed_work_time")
        if available is None or observed is None:
            return result | {"required_input": "available_staff_time and observed_work_time, in the same declared unit, period and staff_pool"}
        available, observed = _decimal(available, "Available staff time"), _decimal(observed, "Observed work time")
        result.update({"available_staff_time": _number(available), "observed_work_time": _number(observed), "staff_pool": values.get("staff_pool", "")})
        if not result["staff_pool"]:
            return result | {"status": "definition_incomplete", "required_definition_fields": ["staff_pool"]}
        if available == 0:
            return result | {"status": "zero_denominator"}
        result.update({"value": _number(observed / available * 100), "unit": "percent of declared available staff time", "status": "measured"})
        if values.get("assumed_time_per_contact") is not None and values.get("demand_count") is not None:
            if not values.get("assumption_basis"):
                raise AssessmentError("Assumed handling time needs its stated source/estimate basis.")
            demand, assumed = _count(values["demand_count"], "Demand count"), _decimal(values["assumed_time_per_contact"], "Assumed handling time")
            result["scenario"] = {"status": "design_assumption", "demand_count": demand, "assumed_time_per_contact": _number(assumed), "required_time": _number(demand * assumed), "available_time": _number(available), "basis": values["assumption_basis"]}
        return _qualify(result, measurement)
    if metric_type in ("channel_share", "abandonment"):
        if values.get("numerator") is None or values.get("denominator") is None:
            return result | {"required_input": "Both same-cohort numerator and denominator are required; a missing value is not zero."}
        numerator, denominator = _count(values["numerator"], "Numerator"), _count(values["denominator"], "Denominator")
        if numerator > denominator:
            raise AssessmentError("A proportion's numerator cannot exceed its same-population denominator.")
        result.update({"numerator": numerator, "denominator": denominator, "value": _number(Decimal(numerator) / denominator * 100) if denominator else None, "unit": "percent", "status": "measured" if denominator else "zero_denominator"})
    elif metric_type in ("call_wait", "call_talk", "intake_decision_time"):
        if values.get("duration_total") is not None and values.get("completed_count") is not None:
            count, total = _count(values["completed_count"], "Completed duration denominator"), _decimal(values["duration_total"], "Total observed duration")
            if count == 0 and total != 0:
                raise AssessmentError("A zero completed-record count cannot have nonzero observed duration.")
            result.update({"duration_total": _number(total), "completed_count": count, "value": _number(total / count) if count else None, "statistic": "mean", "status": "measured" if count else "zero_denominator"})
        elif measurement["basis"] == "reported" and values.get("value") is not None and values.get("statistic"):
            result.update({"value": _number(_decimal(values["value"], "Reported duration")), "statistic": _text(values["statistic"], "Reported statistic", True, 100), "status": "reported", "completed_count": _count(values["completed_count"], "Reported denominator") if values.get("completed_count") is not None else None})
            result["qualifications"].append("The source-reported statistic is retained; it is not reconstructed or pooled as a mean without its required totals and denominator.")
        else:
            return result | {"required_input": "Provide observed duration_total plus completed_count, or a labeled source-reported statistic."}
    else:
        key = "count" if metric_type == "channel_volume" else "value"
        if values.get(key) is None:
            return result | {"required_input": key}
        value = _count(values[key], "Channel count") if key == "count" else _decimal(values[key], "Locally defined value", False)
        result.update({"value": _number(value), "status": "measured" if measurement["basis"] != "reported" else "reported"})
    for key in ("pending_count", "missing_count", "excluded_count", "duplicate_count", "unassigned_count"):
        result[key] = _count(values[key], key) if values.get(key) is not None else None
    return _qualify(result, measurement)


def _qualify(result, measurement):
    if measurement["sample_status"] != "complete_extract":
        result["qualifications"].append("This value covers the declared " + measurement["sample_status"] + "; complete source coverage has not been substituted.")
    if any(result.get(key, 0) for key in ("missing_count", "unassigned_count")):
        result["qualifications"].append("Missing or unassigned records remain visible; the observed subset is not a complete population baseline.")
    if result.get("pending_count"):
        result["qualifications"].append("Pending interactions remain in the source cohort. Completed-record time statistics describe completed observations as of the cutoff, and terminal-outcome rates may change as pending interactions finish.")
    if measurement["period"]["cutoff"]:
        p = measurement["period"]
        if _instant(p["cutoff"], "Cutoff", p["timezone"]) < _instant(p["end"], "Period end", p["timezone"]):
            result["qualifications"].append("The observation cutoff precedes the planned period end; this is an interim cohort.")
    return result


def _event_metric(definition, measurement, result):
    period = measurement["period"]
    start, end, cutoff = [_instant(period[key], key, period["timezone"]) for key in ("start", "end", "cutoff")]
    events, excluded, missing_cohort, unassigned = [], 0, 0, 0
    for event in measurement["events"]:
        timestamp = event.get(definition["cohort_event"])
        if not timestamp:
            missing_cohort += 1
            continue
        moment = _instant(timestamp, definition["cohort_event"])
        if moment < start or moment >= end or moment > cutoff:
            excluded += 1
            continue
        if event.get("exclusion_reason"):
            excluded += 1
            continue
        if not event.get("office_id") or not event.get("channel_ids"):
            unassigned += 1
        if measurement["office_ids"] and event.get("office_id") not in measurement["office_ids"]:
            excluded += 1
            continue
        if measurement["channel_ids"] and not set(measurement["channel_ids"]) & set(event.get("channel_ids", [])):
            excluded += 1
            continue
        events.append(event)
    counts = Counter(event["unit_id"] for event in events)
    duplicates = sum(count - 1 for count in counts.values())
    result.update({"source_rows": len(measurement["events"]), "cohort_count": len(events), "excluded_count": excluded,
                   "missing_count": missing_cohort, "unassigned_count": unassigned, "duplicate_count": duplicates, "pending_count": 0})
    if duplicates:
        return result | {"status": "duplicate_units_need_resolution", "required_input": "Resolve repeated counting-unit records or define actual source call legs before computing this cohort."}
    metric_type = definition["type"]
    if metric_type == "channel_volume":
        return _qualify(result | {"value": str(len(events)), "status": "measured"}, measurement)
    if metric_type == "channel_share":
        selected = set(measurement["numerator_channel_ids"])
        if not selected:
            return result | {"status": "definition_incomplete", "required_definition_fields": ["numerator_channel_ids"]}
        numerator = sum(bool(selected & set(event.get("channel_ids", []))) for event in events)
        overlap = sum(len(event.get("channel_ids", [])) > 1 for event in events)
        result.update({"numerator": numerator, "denominator": len(events), "multi_touch_units": overlap,
                       "value": _number(Decimal(numerator) / len(events) * 100) if events else None, "unit": "percent", "status": "measured" if events else "zero_denominator"})
        if overlap:
            result["qualifications"].append("Some source units used several channels; channel percentages may overlap and must not be summed as exclusive shares.")
        return _qualify(result, measurement)
    if metric_type == "abandonment":
        mapping, rule = definition["outcome_mapping"], definition["short_abandon_rule"]
        numerator, denominator, unknown, short = 0, 0, 0, 0
        for event in events:
            outcome = mapping.get(event.get("outcome"))
            if outcome is None or outcome == "other":
                unknown += 1
                continue
            if outcome == "ineligible":
                continue
            if outcome in ("answered", "abandoned"):
                terminal = event.get("answered_at" if outcome == "answered" else "ended_at")
                if not terminal:
                    unknown += 1
                    continue
                terminal_instant = _instant(terminal, "Outcome timestamp")
                queue = event.get("queue_entered_at")
                if queue and terminal_instant < _instant(queue, "Queue entry"):
                    unknown += 1
                    continue
                if outcome == "abandoned" and event.get("answered_at") and _instant(event["answered_at"], "Answer time") <= terminal_instant:
                    unknown += 1
                    continue
                if terminal_instant > cutoff:
                    outcome = "pending"
            if outcome == "abandoned" and rule["mode"] == "exclude_below":
                a, b = event.get("queue_entered_at"), event.get("ended_at")
                if not a or not b:
                    unknown += 1
                    continue
                elapsed = _elapsed_seconds(_instant(a, "Queue entry"), _instant(b, "Abandonment end"))
                if elapsed < 0:
                    raise AssessmentError("An abandoned interaction ends before queue entry.")
                if elapsed < _decimal(rule["seconds"], "Short abandonment threshold"):
                    short += 1
                    continue
            denominator += 1
            numerator += outcome == "abandoned"
            result["pending_count"] += outcome == "pending"
        result.update({"numerator": numerator, "denominator": denominator, "short_abandon_excluded": short, "unresolved_outcomes": unknown,
                       "value": _number(Decimal(numerator) / denominator * 100) if denominator and not unknown else None,
                       "unit": "percent", "status": "outcome_definition_incomplete" if unknown else "measured" if denominator else "zero_denominator"})
        return _qualify(result, measurement)
    if metric_type not in ("call_wait", "call_talk", "intake_decision_time"):
        return result | {"required_input": "Use a source-defined aggregate for this capacity or local-success measure."}
    durations, abandoned, decision_excluded, invalid_intervals = [], 0, 0, 0
    for event in events:
        if metric_type == "call_wait" and definition["outcome_mapping"].get(event.get("outcome")) == "abandoned":
            terminal = event.get("ended_at")
            if not terminal:
                result["missing_count"] += 1
                continue
            terminal_instant = _instant(terminal, "Abandonment end")
            if terminal_instant > cutoff:
                result["pending_count"] += 1
                continue
            if event.get("answered_at") and _instant(event["answered_at"], "Answer time") <= cutoff:
                invalid_intervals += 1
                continue
            queue = event.get("queue_entered_at")
            if not queue:
                result["missing_count"] += 1
                continue
            if terminal_instant < _instant(queue, "Queue entry"):
                invalid_intervals += 1
                continue
            abandoned += 1
            continue
        if metric_type == "intake_decision_time":
            kind = definition["decision_kind"]
            if event.get("decision_kind") and not (event["decision_kind"] == kind or kind == "any_case_decision" and event["decision_kind"] in ("accepted", "rejected")):
                decision_excluded += 1
                continue
        a, b = event.get(definition["start_event"]), event.get(definition["end_event"])
        if not a:
            result["missing_count"] += 1
            continue
        if not b or _instant(b, "Completion") > cutoff:
            result["pending_count"] += 1
            continue
        if metric_type == "intake_decision_time" and not event.get("decision_kind"):
            result["missing_count"] += 1
            continue
        try:
            durations.append(_duration(_instant(a, "Starting event"), _instant(b, "Completion"), definition))
        except AssessmentError:
            invalid_intervals += 1
    durations.sort()
    total = sum(durations, Decimal(0))
    count = len(durations)
    result.update({"completed_count": count, "duration_total": _number(total), "abandoned_count": abandoned, "other_decision_count": decision_excluded,
                   "value": _number(total / count) if count and not invalid_intervals else None, "statistic": "mean", "status": "intervals_need_resolution" if invalid_intervals else "measured" if count else "zero_denominator", "invalid_intervals": invalid_intervals,
                   "median": _number(durations[count // 2] if count % 2 else (durations[count // 2 - 1] + durations[count // 2]) / 2) if count and not invalid_intervals else None,
                   "p90_nearest_rank": _number(durations[(9 * count + 9) // 10 - 1]) if count and not invalid_intervals else None,
                   "percentile_method": "nearest_rank for p90; midpoint of middle observations for even-count median"})
    return _qualify(result, measurement)


def _measurement_report(state, measurement):
    """Keep a source/definition problem local to its editable measurement."""
    try:
        return evaluate_measurement(state, measurement)
    except AssessmentError as exc:
        return {"measurement_id": measurement["id"], "definition_id": measurement["definition_id"], "provider_id": measurement["provider_id"],
                "period": deepcopy(measurement["period"]), "value": None, "status": "input_requires_resolution", "required_input": str(exc),
                "evidence_refs": deepcopy(measurement["evidence_refs"]), "qualifications": []}


def _comparison_signature(definition, measurement):
    fields = ("type", "version", "unit", "counting_unit", "population", "numerator_definition", "denominator_definition", "exclusions", "clock", "cohort_event", "start_event", "end_event", "decision_kind", "outcome_mapping", "short_abandon_rule", "business_calendar")
    return {"definition": {field: definition.get(field) for field in fields}, "period": measurement["period"], "sample_status": measurement["sample_status"]}


def aggregate_measurements(state, measurement_ids):
    """Produce a comparable pooled draft only with declared disjoint populations.

    No raw client identifier is used to assume cross-LSP identity. Overlapping or
    unknown populations remain independent metrics until a specific union source
    or non-overlap basis is supplied; ratio denominators are never averaged.
    """
    measurements = [_record(state, "measurements", record_id) for record_id in _ids(measurement_ids, "Pooled measurements")]
    if not measurements:
        return {"status": "no_measurements", "value": None}
    signatures = [_comparison_signature(_record(state, "metric_definitions", item["definition_id"]), item) for item in measurements]
    if any(signature != signatures[0] for signature in signatures[1:]):
        return {"status": "definitions_not_comparable", "value": None, "reason": "Metric version, cohort, clock, exclusion, unit or period differs; retain separate LSP results."}
    if len(measurements) > 1 and any(item["aggregation"]["mode"] != "disjoint" or not item["aggregation"]["basis"] for item in measurements):
        return {"status": "population_overlap_unresolved", "value": None, "reason": "Declare and source the non-overlap basis, or provide a separately deduplicated union measurement."}
    results = [_measurement_report(state, item) for item in measurements]
    def usable(item):
        if item.get("status") in ("measured", "reported"):
            return item.get("value") is not None
        if item.get("status") != "zero_denominator":
            return False
        if item.get("metric_type") in ("channel_share", "abandonment"):
            return item.get("numerator") == 0 and item.get("denominator") == 0
        if item.get("metric_type") in ("call_wait", "call_talk", "intake_decision_time"):
            return item.get("completed_count") == 0 and item.get("duration_total") is not None and _decimal(item["duration_total"], "Duration total") == 0
        return False
    if any(not usable(item) for item in results):
        return {"status": "incomplete_baselines", "value": None, "reason": "Every included baseline must have its declared value and denominator before pooling."}
    kind = signatures[0]["definition"]["type"]
    pooled = {"status": "computed", "metric_type": kind, "unit": results[0]["unit"], "measurement_count": len(results), "provider_count": len({item["provider_id"] for item in measurements}),
              "period": signatures[0]["period"], "definition": signatures[0]["definition"], "qualifications": sorted({text for item in results for text in item.get("qualifications", [])})}
    if kind in ("channel_share", "abandonment"):
        numerator, denominator = sum(item["numerator"] for item in results), sum(item["denominator"] for item in results)
        pooled.update({"numerator": numerator, "denominator": denominator, "value": _number(Decimal(numerator) / denominator * 100) if denominator else None,
                       "status": "computed" if denominator else "zero_denominator"})
    elif kind in ("call_wait", "call_talk", "intake_decision_time"):
        if any(item.get("duration_total") is None or item.get("completed_count") is None for item in results):
            return {"status": "duration_totals_required", "value": None, "reason": "Source-reported means or percentiles cannot be pooled without compatible totals and completed-record denominators."}
        total, count = sum((_decimal(item["duration_total"], "Duration total") for item in results), Decimal(0)), sum(item["completed_count"] for item in results)
        pooled.update({"duration_total": _number(total), "completed_count": count, "value": _number(total / count) if count else None, "statistic": "mean", "status": "computed" if count else "zero_denominator"})
    elif kind == "channel_volume":
        pooled["value"] = _number(sum((_decimal(item["value"], "Count") for item in results), Decimal(0)))
    elif len(results) == 1:
        pooled.update({key: value for key, value in results[0].items() if key in ("value", "unit", "statistic", "numerator", "denominator")})
    else:
        return {"status": "local_measure_requires_aggregation_definition", "value": None, "reason": "Capacity and locally defined success measures are not automatically pooled."}
    return pooled


def office_channel_overlap(total_offices, channel_counts):
    """Bounds for counts from one declared office universe, not invented IDs."""
    total = _count(total_offices, "Office universe")
    counts = {str(key): _count(value, "Channel office count") for key, value in channel_counts.items()}
    if any(value > total for value in counts.values()):
        raise AssessmentError("A channel count exceeds the stated office universe; resolve its source scope.")
    pairs = []
    names = list(counts)
    for index, a in enumerate(names):
        for b in names[index + 1:]:
            pairs.append({"channels": [a, b], "intersection_min": max(0, counts[a] + counts[b] - total), "intersection_max": min(counts[a], counts[b]),
                          "union_min": max(counts[a], counts[b]), "union_max": min(total, counts[a] + counts[b])})
    return {"office_universe": total, "channel_counts": counts, "sum_of_channel_memberships": sum(counts.values()),
            "distinct_offices_min": max(counts.values(), default=0), "distinct_offices_max": min(total, sum(counts.values())), "pairs": pairs,
            "meaning": "Source counts identify overlapping sets in one office universe; exact union/intersection needs actual office memberships."}


def _validate_flow(flow):
    if not isinstance(flow["nodes"], list) or not isinstance(flow["edges"], list) or len(flow["nodes"]) > 200 or len(flow["edges"]) > 1000:
        raise AssessmentError("An editable workflow supports at most 200 nodes and 1,000 edges.")
    normalized = []
    for node in flow["nodes"]:
        if not isinstance(node, dict):
            raise AssessmentError("Workflow nodes must be objects.")
        normalized.append({"id": _id(node.get("id"), "Workflow node ID"), "label": _text(node.get("label"), "Workflow node label", True, 500),
                           "kind": _choice(node.get("kind"), ("start", "action", "decision", "wait", "handoff", "end"), "Workflow node kind", "action"),
                           "role": _text(node.get("role"), "Workflow operating role", limit=500), "evidence_refs": _ids(node.get("evidence_refs"), "Workflow node evidence"),
                           "accessibility": _text(node.get("accessibility"), "Language/disability access observation"), "notes": _text(node.get("notes"), "Workflow node notes")})
    ids = {node["id"] for node in normalized}
    if len(ids) != len(normalized):
        raise AssessmentError("Workflow node IDs must be unique within the map.")
    edges = []
    for edge in flow["edges"]:
        if not isinstance(edge, dict) or edge.get("from") not in ids or edge.get("to") not in ids:
            raise AssessmentError("Every workflow edge must reference nodes in this LSP's editable map.")
        edges.append({"from": edge["from"], "to": edge["to"], "label": _text(edge.get("label"), "Workflow transition condition", limit=500), "evidence_refs": _ids(edge.get("evidence_refs"), "Workflow edge evidence")})
    flow["nodes"], flow["edges"] = normalized, edges


def workflow_map(flow):
    flow = deepcopy(flow)
    _validate_flow(flow)
    ids = {node["id"]: "n" + str(index) for index, node in enumerate(flow["nodes"])}
    def label(value):
        return json.dumps(str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", " "), ensure_ascii=False)
    lines = ["flowchart TD"]
    for node in flow["nodes"]:
        text = label(node["label"] + (" · " + node["role"] if node["role"] else ""))
        lines.append("  " + ids[node["id"]] + ("{" + text + "}" if node["kind"] == "decision" else "[" + text + "]"))
    for edge in flow["edges"]:
        lines.append("  " + ids[edge["from"]] + (" -- " + label(edge["label"]) + " --> " if edge["label"] else " --> ") + ids[edge["to"]])
    starts = [node["id"] for node in flow["nodes"] if node["kind"] == "start"]
    reached, queue = set(starts), deque(starts)
    outgoing = defaultdict(list)
    for edge in flow["edges"]:
        outgoing[edge["from"]].append(edge["to"])
    while queue:
        for target in outgoing[queue.popleft()]:
            if target not in reached:
                reached.add(target)
                queue.append(target)
    return {"schema": "plan.editable-workflow/v1", "provider_id": flow.get("provider_id"), "workflow_id": flow.get("id"), "nodes": flow["nodes"], "edges": flow["edges"],
            "mermaid": "\n".join(lines) + "\n", "review": {"start_nodes": len(starts), "end_nodes": sum(node["kind"] == "end" for node in flow["nodes"]),
            "unreachable_nodes": [node["id"] for node in flow["nodes"] if node["id"] not in reached],
            "unfinished_paths": [node["id"] for node in flow["nodes"] if node["kind"] != "end" and not outgoing[node["id"]]],
            "meaning": "Branches and return loops describe the observed local process; a draft map does not impose a shared statewide workflow."}}


def recommendation_digest(state, record):
    if isinstance(record, str):
        record = _record(state, "recommendations", record)
    decision_fields = {"status", "decision_basis", "decision_actor", "decision_at", "accepted_content_digest"}
    return digest({"recommendation": {key: value for key, value in record.items() if key not in decision_fields},
                   "evidence_versions": [_record(state, "evidence", key) for key in sorted(record["evidence_refs"])]})


def record_recommendation_decision(state, recommendation_id, decision, actor, basis, at):
    """Prepare an exact-current recommendation decision for native persistence."""
    record = deepcopy(_record(state, "recommendations", recommendation_id))
    record.update({"status": decision, "decision_actor": actor, "decision_basis": basis, "decision_at": at, "accepted_content_digest": ""})
    normalized = validate_record("recommendations", record, state)
    if decision in ("accepted", "completed"):
        _text(actor, "Actual decision actor", True, 300)
        _text(basis, "Actual acceptance basis", True)
        _instant(at, "Actual decision time")
        normalized["accepted_content_digest"] = recommendation_digest(state, normalized)
    return normalized


def recommendation_roadmap(state, provider_id=None):
    if provider_id is not None:
        _provider(state, provider_id)
        return _project_roadmap(state, recommendation_roadmap(state), provider_id)
    all_records = _index(state, "recommendations")
    records = list(all_records.values())
    recorded_accepted = [record for record in records if record["status"] in ("accepted", "completed")]
    accepted = {record["id"]: record for record in recorded_accepted if record.get("accepted_content_digest") == recommendation_digest(state, record) and record.get("decision_basis") and record.get("decision_actor") and record.get("decision_at")}
    acceptance_review = [{"recommendation_id": record["id"], "status": "acceptance_not_bound_to_current_content", "current_content_digest": recommendation_digest(state, record)} for record in recorded_accepted if record["id"] not in accepted]
    indegree, outgoing = {}, defaultdict(list)
    attention = []
    for record_id, record in accepted.items():
        dependencies = [dependency for dependency in record["dependencies"] if dependency in accepted]
        indegree[record_id] = len(dependencies)
        for dependency in dependencies:
            outgoing[dependency].append(record_id)
    queue = deque(sorted(key for key, value in indegree.items() if not value))
    order = []
    while queue:
        record_id = queue.popleft()
        order.append(record_id)
        for child in sorted(outgoing[record_id]):
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    cycle_affected = sorted(set(accepted) - set(order))
    schedule, cost_totals, unpriced, rfp_briefs = {}, defaultdict(Decimal), [], []
    for record_id in order + cycle_affected:
        record = accepted[record_id]
        reasons = []
        if not record["decision_basis"]:
            reasons.append("Record the actual recommendation acceptance basis.")
        if not record["owner_role"]:
            reasons.append("Assign an accountable operating role.")
        for dependency in record["dependencies"]:
            if dependency not in accepted:
                reasons.append("Dependency " + dependency + " is not accepted in this roadmap scope.")
            elif dependency not in schedule or schedule[dependency]["readiness"] != "ready":
                reasons.append("Dependency " + dependency + " has an unresolved readiness item.")
        reasons += ["Prerequisite: " + item["name"] for item in record["prerequisites"] if item["status"] == "pending" or item["status"] == "satisfied" and not item["basis"]]
        if record_id in cycle_affected:
            reasons.append("Resolve the recommendation dependency cycle or an upstream cycle.")
        duration = _decimal(record["duration_workdays"], "Estimated duration") if record["duration_workdays"] is not None else None
        parents = [schedule.get(dependency) for dependency in record["dependencies"]]
        start = max((_decimal(item["earliest_finish_workday"], "Finish") for item in parents), default=Decimal(0)) if all(item and item["earliest_finish_workday"] is not None for item in parents) else None
        finish = start + duration if start is not None and duration is not None else None
        schedule[record_id] = {"id": record_id, "provider_id": record.get("provider_id"), "title": record["title"], "horizon": record["horizon"], "priority": record["priority"],
                               "owner_role": record["owner_role"], "dependencies": record["dependencies"], "readiness": "ready" if not reasons else "attention_required", "attention": reasons,
                               "earliest_start_workday": _number(start) if start is not None else None, "earliest_finish_workday": _number(finish) if finish is not None else None,
                               "duration_workdays": record["duration_workdays"], "effort_person_days": record["effort_person_days"], "cost": record["cost"], "estimate_basis": record["estimate_basis"]}
        attention += [{"recommendation_id": record_id, "item": reason} for reason in reasons]
        if record["cost"] is None:
            unpriced.append(record_id)
        else:
            cost_totals[record["cost"]["currency"]] += _decimal(record["cost"]["amount"], "Estimated cost")
        if record["vendor_rfp_needed"]:
            rfp_briefs.append({"recommendation_id": record_id, "title": record["title"], "scope": record["action"], "deliverables": record["deliverables"], "acceptance": record["acceptance"],
                               "dependencies": record["dependencies"], "governance": record["governance"], "accessibility": record["accessibility"], "status": "later_phase_scope_draft"})
    return {"schema": "plan.accepted-recommendation-roadmap/v1", "accepted_count": len(accepted), "recorded_accepted_count": len(recorded_accepted), "acceptance_review": acceptance_review, "proposed_count": sum(record["status"] == "proposed" for record in records),
            "items": list(schedule.values()), "dependency_cycle_or_dependents": cycle_affected, "attention": attention, "estimated_cost_totals": {key: _number(value) for key, value in cost_totals.items()},
            "unpriced_recommendations": unpriced, "vendor_rfp_briefs": rfp_briefs,
            "schedule_basis": "Relative workday offsets from declared elapsed-duration estimates, not person-effort sums. Staffing/resource leveling and the actual start/calendar belong to the implementation plan.",
            "scope": "Accepted recommendations form planning inputs; this roadmap does not authorize procurement, a shared-system implementation or future award."}


def _project_roadmap(state, roadmap, provider_id):
    """Retain real dependency effects without exposing another scope's records."""
    own = {record["id"]: record for record in state["recommendations"] if record.get("provider_id") == provider_id}
    result = deepcopy(roadmap)
    items, totals = [], defaultdict(Decimal)
    for original in roadmap["items"]:
        if original["id"] not in own:
            continue
        item = deepcopy(original)
        external = set(item["dependencies"]) - set(own)
        item["dependencies"] = [key for key in item["dependencies"] if key in own]
        item["network_prerequisite_count"] = len(external)
        item["attention"] = ["A network prerequisite is not currently accepted or ready; its source record stays in the restricted PLAN workspace."
                             if any(reason.startswith("Dependency " + key + " ") for key in external) else reason for reason in item["attention"]]
        item["attention"] = list(dict.fromkeys(item["attention"]))
        item["dependency_projection"] = "Computed from the full accepted graph; network prerequisite identifiers are omitted while their readiness and timing effects remain."
        items.append(item)
        if item["cost"] is not None:
            totals[item["cost"]["currency"]] += _decimal(item["cost"]["amount"], "Estimated cost")
    result.update({"accepted_count": len(items), "recorded_accepted_count": sum(record["status"] in ("accepted", "completed") for record in own.values()),
                   "proposed_count": sum(record["status"] == "proposed" for record in own.values()), "items": items,
                   "acceptance_review": [item for item in result["acceptance_review"] if item["recommendation_id"] in own],
                   "dependency_cycle_or_dependents": [key for key in result["dependency_cycle_or_dependents"] if key in own],
                   "attention": [{"recommendation_id": item["id"], "item": reason} for item in items for reason in item["attention"]],
                   "estimated_cost_totals": {key: _number(value) for key, value in totals.items()},
                   "unpriced_recommendations": [key for key in result["unpriced_recommendations"] if key in own]})
    briefs = []
    for original in result["vendor_rfp_briefs"]:
        if original["recommendation_id"] not in own:
            continue
        brief = deepcopy(original)
        brief["network_prerequisite_count"] = sum(key not in own for key in brief["dependencies"])
        brief["dependencies"] = [key for key in brief["dependencies"] if key in own]
        briefs.append(brief)
    result["vendor_rfp_briefs"] = briefs
    return result


def _finding_dependencies(state, finding):
    evidence_ids = set(finding["evidence_refs"])
    measurements, recommendations, definitions = [], [], {}
    for record_id in finding["measurement_ids"]:
        measurement = _record(state, "measurements", record_id)
        measurements.append(measurement)
        evidence_ids.update(measurement["evidence_refs"])
        evidence_ids.update(measurement["aggregation"]["evidence_refs"])
        definition = _record(state, "metric_definitions", measurement["definition_id"])
        definitions[definition["id"]] = definition
        evidence_ids.update(definition["evidence_refs"])
    for record_id in finding["recommendation_ids"]:
        recommendation = _record(state, "recommendations", record_id)
        recommendations.append(recommendation)
        evidence_ids.update(recommendation["evidence_refs"])
    return {"measurements": measurements, "metric_definitions": [definitions[key] for key in sorted(definitions)], "recommendations": recommendations,
            "evidence_versions": [_record(state, "evidence", key) for key in sorted(evidence_ids)]}


def _finding_providers(state, finding):
    dependencies = _finding_dependencies(state, finding)
    providers = set(finding["provider_ids"])
    for records in dependencies.values():
        providers.update(record["provider_id"] for record in records if record.get("provider_id") is not None)
    return providers


def finding_digest(state, finding):
    if isinstance(finding, str):
        finding = _record(state, "network_findings", finding)
    provider_ids = sorted(_finding_providers(state, finding))
    public_names = [{"id": provider_id, "name": _provider(state, provider_id)["name"]} for provider_id in provider_ids] if finding["presentation"] == "attributed" else []
    return digest({"finding": finding, **_finding_dependencies(state, finding), "affected_provider_ids": provider_ids, "attributed_provider_names": public_names})


def _consultation_versions(state, finding):
    affected = _finding_providers(state, finding)
    return {record["provider_id"]: digest(record) for record in state.get("permissions", [])
            if record["finding_id"] == finding["id"] and record["authority"] == "lsp" and record.get("provider_id") in affected}


def finding_publication(state, finding):
    if isinstance(finding, str):
        finding = _record(state, "network_findings", finding)
    current = finding_digest(state, finding)
    consultations = _consultation_versions(state, finding)
    provider_ids = sorted(_finding_providers(state, finding))
    required = [("plan", None)] + [("lsp", provider_id) for provider_id in provider_ids]
    decisions, missing = [], []
    for authority, provider_id in required:
        permission = next((item for item in state.get("permissions", []) if item["finding_id"] == finding["id"] and item["authority"] == authority and item.get("provider_id") == provider_id), None)
        status = "not_recorded" if permission is None else "source_or_finding_changed" if permission["target_digest"] != current else permission["decision"]
        if permission is not None and status in ("approved", "consulted") and permission.get("evidence_versions") != {key: digest(_record(state, "evidence", key)) for key in permission["evidence_refs"]}:
            status = "consultation_evidence_changed"
        if authority == "plan" and permission is not None and status == "approved" and permission.get("consultation_versions") != consultations:
            status = "consultation_record_changed"
        decisions.append({"authority": authority, "provider_id": provider_id, "status": status, "position": permission.get("position", "not_stated") if permission else "not_stated"})
        if status != ("approved" if authority == "plan" else "consulted"):
            missing.append({"authority": authority, "provider_id": provider_id, "status": status})
    pooled = aggregate_measurements(state, finding["measurement_ids"]) if finding["aggregation"] == "pooled" else None
    if pooled is not None and pooled["status"] != "computed":
        missing.append({"authority": "measurement_definition", "provider_id": None, "status": pooled["status"]})
    return {"finding_id": finding["id"], "target_digest": current, "affected_provider_ids": provider_ids, "status": "ready_for_consolidated_use" if not missing else "specific_use_review_required",
            "decisions": decisions, "attention": missing, "pooled_measurement": pooled,
            "current_consultation_versions": consultations,
            "decision_rule": "PLAN determines internal consolidated use in consultation with each affected LSP. Recorded consultation can include disagreement; it is not an LSP approval or veto.",
            "audience": "consolidated", "third_party_release": "Separate prior written PLAN and applicable LSP consent is required by RFP section 11; this consolidation decision is not third-party consent."}


def assess(state):
    if state.get("schema") != SCHEMA:
        raise AssessmentError("Unsupported PLAN assessment schema.")
    confirmed = [item for item in state["providers"] if item["roster_status"] == "confirmed"]
    mapped = {candidate for item in state["providers"] for candidate in item["candidate_ids"]}
    public = Counter(item.get("group_published") for item in state["candidates"])
    provider_summaries = []
    for provider in state["providers"]:
        pid = provider["id"]
        offices = [item for item in state["offices"] if item["provider_id"] == pid and item["status"] in ("observed", "reported")]
        channels = [item for item in state["channels"] if item["provider_id"] == pid and item["status"] in ("observed", "reported")]
        known_office_ids = {item["id"] for item in offices}
        channel_sets = defaultdict(set)
        for channel in channels:
            channel_sets[channel["kind"]].update(set(channel["office_ids"]) & known_office_ids)
        workflow_rows = [item for item in state["workflows"] if item["provider_id"] == pid]
        provider_summaries.append({"provider_id": pid, "name": provider["name"], "roster_status": provider["roster_status"], "known_offices": len(offices), "known_channels": len(channels),
                                   "channel_office_memberships": {key: len(value) for key, value in channel_sets.items()}, "distinct_channel_offices": len(set().union(*channel_sets.values())) if channel_sets else 0,
                                   "unlocated_channels": sum(not item["office_ids"] for item in channels), "channel_location_review_count": sum(bool(set(item["office_ids"]) - known_office_ids) for item in channels),
                                   "proposed_offices": sum(item["provider_id"] == pid and item["status"] == "proposed" for item in state["offices"]),
                                   "proposed_channels": sum(item["provider_id"] == pid and item["status"] == "proposed" for item in state["channels"]),
                                   "workflow_count": len(workflow_rows), "reviewed_workflows": sum(item["status"] == "reviewed" for item in workflow_rows),
                                   "source_evidence_count": sum(item.get("provider_id") == pid for item in state["evidence"]), "local_success_defined": bool(provider["success_statement"]),
                                   "recommendations_requested": provider["recommendations_requested"]})
    known_counts = [item.get("program_offices_published") for item in state["candidates"] if item.get("program_offices_published") is not None]
    return {"schema": "plan.assessment-summary/v1", "roster": {"rfp_lsp_target": state["scope"]["lsp_count"], "confirmed_assessment_units": len(confirmed),
                "confirmed_regional": sum(item["category"] == "regional" for item in confirmed), "confirmed_specialized": sum(item["category"] == "specialized" for item in confirmed),
                "public_candidate_count": len(state["candidates"]), "public_regional_candidates": public["regional"], "public_specialized_candidates": public["specialized"],
                "unmapped_candidate_ids": [item["id"] for item in state["candidates"] if item["id"] not in mapped], "status": "roster_counts_match_source_scope" if len(confirmed) == state["scope"]["lsp_count"] and sum(item["category"] == "regional" for item in confirmed) == state["scope"]["regional_count"] and sum(item["category"] == "specialized" for item in confirmed) == state["scope"]["specialized_count"] else "roster_mapping_in_progress",
                "meaning": "Public provider-directory entries and contracted assessment units are separate; matching counts alone is not a source roster decision."},
            "reference_office_overlap": office_channel_overlap(state["scope"]["office_count"], {item["channel"]: item["count"] for item in state["scope"]["reported_office_channels"]}),
            "public_office_count_context": {"candidates_with_published_count": len(known_counts), "sum_of_those_program_counts": sum(known_counts), "meaning": "Only the named public program counts supplied by the directory; not the RFP's walk-in office count and not a complete contracted office registry."},
            "providers": provider_summaries, "measurements": [_measurement_report(state, item) for item in state["measurements"]],
            "workflow_reviews": [{"id": item["id"], "provider_id": item["provider_id"], **workflow_map(item)["review"]} for item in state["workflows"]],
            "roadmap": recommendation_roadmap(state), "network_findings": [finding_publication(state, item) for item in state["network_findings"]]}


def _public_evidence(record):
    return {key: deepcopy(record.get(key)) for key in ("id", "title", "source_sha256", "source_url", "locator", "version")}


def _export_metric(state, measurement):
    definition = _record(state, "metric_definitions", measurement["definition_id"])
    result = _measurement_report(state, measurement)
    return {"name": definition["name"], "definition": {key: definition[key] for key in ("version", "type", "unit", "counting_unit", "population", "numerator_definition", "denominator_definition", "exclusions", "clock", "decision_kind")},
            "result": {key: value for key, value in result.items() if key not in ("measurement_id", "definition_id", "provider_id", "evidence_refs")}}


def project_export(state, audience, provider_id=None):
    """Construct audience-specific content, never a blind filtered state dump.

    plan_restricted is the RFP's PLAN access to individual reports/workpapers.
    lsp contains one LSP's data. consolidated contains only exact-content approved
    findings and relevant public evidence. The caller must use included_evidence_ids
    when selecting raw files; it must not add every project attachment afterwards.
    """
    audience = _choice(audience, ("lsp", "plan_restricted", "consolidated"), "Report audience")
    base = {"schema": "plan.audience-projection/v1", "audience": audience, "name": state["name"], "scope": deepcopy(state["scope"]),
            "ownership": "RFP section 11: PLAN and the applicable LSP own engagement deliverables; this projection is not third-party release consent."}
    if audience == "plan_restricted":
        return base | {"assessment": deepcopy(state), "summary": assess(state), "included_evidence_ids": [item["id"] for item in state["evidence"]], "access_context": "Restricted PLAN recipient; individual organization reports and underlying workpapers remain organization-scoped."}
    if audience == "lsp":
        provider = _provider(state, provider_id)
        data = {"provider": deepcopy(provider), "candidates": [deepcopy(item) for item in state["candidates"] if item["id"] in provider["candidate_ids"]]}
        refs = set(provider["evidence_refs"] + provider["local_success_refs"])
        for collection in ("offices", "channels", "metric_definitions", "measurements", "workflows", "recommendations"):
            rows = [deepcopy(item) for item in state[collection] if item.get("provider_id") == provider_id]
            for item in rows:
                refs.update(item.get("evidence_refs", []))
                if collection == "measurements":
                    refs.update(item["aggregation"]["evidence_refs"])
                if collection == "workflows":
                    for part in item["nodes"] + item["edges"]:
                        refs.update(part.get("evidence_refs", []))
                if collection == "recommendations":
                    # Network dependency titles can be supplied in this LSP's own
                    # prerequisite narrative; do not leak another scope's IDs.
                    dependencies = item["dependencies"]
                    item["dependencies"] = [key for key in dependencies if _record(state, "recommendations", key).get("provider_id") == provider_id]
                    item["network_prerequisite_count"] = len(dependencies) - len(item["dependencies"])
                    item["dependency_projection"] = "Source dependencies are evaluated before audience projection; see the roadmap for retained readiness and timing effects."
            data[collection] = rows
        evidence = [deepcopy(item) for item in state["evidence"] if item.get("provider_id") == provider_id or item.get("provider_id") is None and item["id"] in refs and item["classification"] == "public"]
        allowed = {item["id"] for item in evidence}
        if refs - allowed:
            raise AssessmentError("This LSP export references confidential evidence from another scope; correct its source binding before export.")
        data["evidence"] = evidence
        return base | {"assessment": data, "measurements": [_export_metric(state, item) for item in data["measurements"]], "roadmap": recommendation_roadmap(state, provider_id),
                       "included_evidence_ids": sorted(allowed), "access_context": "Only this LSP's report and underlying workpapers; other LSP records, raw evidence and internal identifiers are omitted."}
    published, public_refs, omitted = [], set(), 0
    for finding in state["network_findings"]:
        publication = finding_publication(state, finding)
        if publication["status"] != "ready_for_consolidated_use":
            omitted += 1
            continue
        item = {"title": finding["title"], "body": finding["body"], "presentation": finding["presentation"], "approved_content_digest": publication["target_digest"]}
        if finding["presentation"] == "attributed":
            item["organizations"] = [_provider(state, key)["name"] for key in publication["affected_provider_ids"]]
        if finding["aggregation"] == "pooled":
            item["measurement"] = publication["pooled_measurement"]
        elif finding["measurement_ids"]:
            item["measurements"] = [{"organization": _provider(state, _record(state, "measurements", key)["provider_id"])["name"], **_export_metric(state, _record(state, "measurements", key))} for key in finding["measurement_ids"]]
        item["recommendations"] = [{key: record[key] for key in ("title", "action", "horizon", "priority", "governance", "accessibility", "status")} for record in (_record(state, "recommendations", key) for key in finding["recommendation_ids"])]
        published.append(item)
        public_refs.update(record["id"] for record in _finding_dependencies(state, finding)["evidence_versions"] if record["classification"] == "public")
    return base | {"findings": published, "public_sources": [_public_evidence(_record(state, "evidence", key)) for key in sorted(public_refs)],
                   "included_evidence_ids": sorted(public_refs), "publication_summary": {"included_findings": len(published), "other_findings_awaiting_their_specific_use_decision": omitted},
                   "access_context": "Consolidated summary only. No per-LSP raw records, evidence files, private source IDs, consultation workpapers or unapproved findings are embedded."}
