"""Durable PLAN operator projects with atomic revisions and original evidence.

The transaction/idempotency/archive envelope follows the existing NEKCV
workbench. Assessment semantics and recipient projections belong to engine.py.
"""
from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

if __package__:
    from . import engine
else:
    import engine

SCHEMA = "plan.assessment-workspace/v1"
MAX_SOURCE_BYTES = 32 * 1024 * 1024
MAX_PROJECT_SOURCE_BYTES = 128 * 1024 * 1024
MAX_STATE_BYTES = 48 * 1024 * 1024
MAX_COLLECTION_ROWS = 2000
canonical, digest = engine.canonical, engine.digest


class Conflict(ValueError):
    def __init__(self, message, current_revision=None):
        super().__init__(message)
        self.current_revision = current_revision


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def required(value, label, limit=20000):
    return engine._text(value, label, True, limit)


def _json(raw):
    def no_constant(value):
        raise ValueError("JSON cannot contain non-finite numeric constants.")
    return json.loads(raw, parse_constant=no_constant)


def _pointer(value, pointer):
    if pointer == "":
        return value
    if not isinstance(pointer, str) or not pointer.startswith("/"):
        raise ValueError("A JSON source selector must be an RFC 6901 pointer beginning with /, or empty for the root.")
    if any("~" in segment.replace("~1", "").replace("~0", "") for segment in pointer[1:].split("/")):
        raise ValueError("JSON pointer escapes must use ~0 for a tilde and ~1 for a slash.")
    current = value
    for segment in pointer[1:].split("/"):
        key = segment.replace("~1", "/").replace("~0", "~")
        if isinstance(current, dict) and key in current:
            current = current[key]
        elif isinstance(current, list) and key.isdigit() and (key == "0" or not key.startswith("0")) and int(key) < len(current):
            current = current[int(key)]
        else:
            raise ValueError("JSON source selector does not resolve: " + pointer)
    return current


def map_source_events(raw, file_record, specification):
    """Map original CSV/JSON records to the engine's explicit event vocabulary.

    No fuzzy column matching, clock conversion, outcome inference or deduplication
    occurs. Duplicate CSV headings require an explicit zero-based column index.
    """
    source_format = specification.get("format")
    if source_format not in ("csv", "json"):
        raise ValueError("Event import supports original CSV or JSON; choose the source format explicitly.")
    options = deepcopy(specification.get("options", {}))
    fields, constants = deepcopy(specification.get("field_map", {})), deepcopy(specification.get("constants", {}))
    allowed = {"unit_id", "office_id", "channel_ids", "outcome", "decision_kind", "exclusion_reason", *engine.TIMESTAMP_FIELDS}
    if not isinstance(fields, dict) or not isinstance(constants, dict) or set(fields) - allowed or set(constants) - allowed or set(fields) & set(constants):
        raise ValueError("Map each supported event field once, through either field_map or constants.")
    if "unit_id" not in fields and "unit_id" not in constants:
        raise ValueError("Map the actual source counting-unit identifier before importing events.")
    if not isinstance(options, dict) or set(options) - {"encoding", "delimiter", "records_path"}:
        raise ValueError("Supported source parsing options are encoding, delimiter and records_path.")
    encoding = options.get("encoding", "utf-8-sig")
    if encoding not in ("utf-8", "utf-8-sig", "utf-16", "cp1252", "latin-1"):
        raise ValueError("Select an explicit supported source encoding: utf-8, utf-8-sig, utf-16, cp1252 or latin-1.")
    try:
        text = raw.decode(encoding)
    except UnicodeError as exc:
        raise ValueError("Original bytes cannot be decoded with the selected encoding.") from exc
    rows = []
    if source_format == "csv":
        delimiter = options.get("delimiter", ",")
        if not isinstance(delimiter, str) or len(delimiter) != 1 or delimiter in "\r\n\x00\"":
            raise ValueError("CSV delimiter must be one explicit non-newline character.")
        reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter, strict=True)
        try:
            headers = next(reader)
        except StopIteration as exc:
            raise ValueError("CSV source is empty.") from exc
        selected = {}
        for field, selector in fields.items():
            if type(selector) is int and 0 <= selector < len(headers):
                selected[field] = selector
            elif isinstance(selector, str) and headers.count(selector) == 1:
                selected[field] = headers.index(selector)
            else:
                raise ValueError(f"CSV selector for {field} is missing or ambiguous; choose the exact header or zero-based column index.")
        for index, row in enumerate(reader):
            if len(row) != len(headers):
                raise ValueError(f"CSV data record {index + 1} has {len(row)} cells but its header has {len(headers)}; preserve and resolve that source structure.")
            rows.append(({field: row[column] for field, column in selected.items()}, {"format": "csv", "data_row_index": index, "physical_line_end": reader.line_num}))
            if len(rows) > 100000:
                raise ValueError("One event cohort supports at most 100,000 source records; import a declared period or source-defined aggregate.")
    else:
        try:
            document = json.loads(text, parse_float=Decimal, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Non-finite source JSON number.")))
        except json.JSONDecodeError as exc:
            raise ValueError("Original JSON source cannot be decoded.") from exc
        pointer = options.get("records_path", "")
        records = _pointer(document, pointer)
        if not isinstance(records, list) or len(records) > 100000:
            raise ValueError("The JSON records_path must select an array of at most 100,000 source records.")
        for index, record in enumerate(records):
            mapped = {}
            for field, selector in fields.items():
                if not isinstance(selector, str):
                    raise ValueError("A JSON event field selector must be an exact object key or JSON pointer.")
                if selector == "" or selector.startswith("/"):
                    mapped[field] = _pointer(record, selector)
                elif isinstance(record, dict) and selector in record:
                    mapped[field] = record[selector]
                else:
                    raise ValueError("JSON source field is missing: " + selector)
            rows.append((mapped, {"format": "json", "records_path": pointer, "row_index": index}))
    events = []
    for mapped, locator in rows:
        event = deepcopy(constants)
        for field, value in mapped.items():
            if value is None or value == "":
                continue
            if field == "channel_ids":
                if isinstance(value, str):
                    value = _json(value)
                if not isinstance(value, list):
                    raise ValueError("Mapped channel_ids must contain an explicit JSON array of this provider's channel IDs.")
                event[field] = value
            elif isinstance(value, (dict, list, bool)):
                raise ValueError("Mapped event text must be a scalar source cell, not an object, array or boolean.")
            else:
                event[field] = str(value)
        event["source_row_ref"] = canonical({"source_file_id": file_record["id"], "source_sha256": file_record["sha256"], **locator})
        events.append(event)
    return events, {"evidence_id": specification["evidence_id"], "source_file_id": file_record["id"], "sha256": file_record["sha256"],
                    "format": source_format, "options": options, "field_map": fields, "constants": constants}


class Workspace:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        created = not self.path.exists()
        with self.connect() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,revision INTEGER NOT NULL,state TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS raw_sources(sha256 TEXT PRIMARY KEY,data BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS events(project_id TEXT NOT NULL,revision INTEGER NOT NULL,record TEXT NOT NULL,PRIMARY KEY(project_id,revision));
            CREATE TABLE IF NOT EXISTS requests(project_id TEXT NOT NULL,request_id TEXT NOT NULL,digest TEXT NOT NULL,result TEXT NOT NULL,PRIMARY KEY(project_id,request_id));
            """)
        if created:
            os.chmod(self.path, 0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=20000")
        try:
            yield db
        finally:
            db.close()

    def _state(self, db, project_id):
        row = db.execute("SELECT state FROM projects WHERE id=?", (project_id,)).fetchone()
        if not row:
            raise KeyError("Project not found.")
        return _json(row[0])

    def _event(self, state, actor, kind, payload, previous, request_id=None, request_digest=None):
        record = {"project_id": state["id"], "revision": state["revision"], "at": state["updated_at"], "actor": required(actor, "Operator", 200),
                  "kind": kind, "payload": payload, "state_hash": digest(state), "previous_hash": previous,
                  "request_id": request_id, "request_digest": request_digest}
        record["hash"] = digest(record)
        return record

    def create(self, name, actor="Operator", project_id=None, candidates=None, source_refs=None):
        project_id = engine._id(project_id or "project-" + uuid.uuid4().hex, "Project ID")
        state = engine.new_assessment(required(name, "Project name", 200), candidates, source_refs)
        at = utc()
        state.update({"workspace_schema": SCHEMA, "id": project_id, "revision": 1, "created_at": at, "updated_at": at, "files": []})
        for record in state["candidates"]:
            engine.validate_record("candidates", record, state)
        event = self._event(state, actor, "project.created", {"name": name, "candidate_count": len(state["candidates"])}, "")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                if db.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
                    raise Conflict("That project ID already exists; open its current work.")
                db.execute("INSERT INTO projects VALUES(?,?,?)", (project_id, 1, canonical(state)))
                db.execute("INSERT INTO events VALUES(?,?,?)", (project_id, 1, canonical(event)))
                db.commit()
            except Exception:
                db.rollback()
                raise
        return self._preview(state)

    def list_projects(self):
        with self.connect() as db:
            states = [_json(row[0]) for row in db.execute("SELECT state FROM projects")]
        return [{key: state[key] for key in ("id", "name", "revision", "created_at", "updated_at")} | {"provider_count": len(state["providers"]), "candidate_count": len(state["candidates"]), "evidence_count": len(state["evidence"])}
                for state in sorted(states, key=lambda item: item["updated_at"], reverse=True)]

    def _preview(self, state):
        result = deepcopy(state)
        result["computed"] = engine.assess(state)
        result["collection_counts"] = {name: len(state[name]) for name in engine.COLLECTIONS}
        result["collection_limit"] = 200
        for collection in engine.COLLECTIONS:
            result[collection] = result[collection][:200]
        for measurement in result["measurements"]:
            measurement["event_count"] = len(measurement["events"])
            measurement["events"] = measurement["events"][:10]
            measurement["event_preview_limit"] = 10
        return result

    def get(self, project_id):
        with self.connect() as db:
            return self._preview(self._state(db, project_id))

    def record(self, project_id, collection, record_id):
        if collection not in engine.COLLECTIONS:
            raise ValueError("Unknown assessment collection.")
        with self.connect() as db:
            return deepcopy(engine._record(self._state(db, project_id), collection, record_id))

    def records(self, project_id, collection, offset=0, limit=100):
        if collection not in engine.COLLECTIONS:
            raise ValueError("Unknown assessment collection.")
        offset, limit = max(0, int(offset)), min(200, max(1, int(limit)))
        with self.connect() as db:
            state = self._state(db, project_id)
        rows = deepcopy(state[collection][offset:offset+limit])
        if collection == "measurements":
            for row in rows:
                row["event_count"] = len(row["events"])
                row["events"] = row["events"][:10]
                row["event_preview_limit"] = 10
        return {"collection": collection, "revision": state["revision"], "offset": offset, "total": len(state[collection]), "rows": rows}

    def measurement_events(self, project_id, measurement_id, offset=0, limit=100):
        offset, limit = max(0, int(offset)), min(500, max(1, int(limit)))
        with self.connect() as db:
            state = self._state(db, project_id)
        measurement = engine._record(state, "measurements", measurement_id)
        return {"measurement_id": measurement_id, "revision": state["revision"], "offset": offset, "total": len(measurement["events"]), "rows": measurement["events"][offset:offset+limit], "source_import": measurement["source_import"]}

    def history(self, project_id, offset=0, limit=100):
        offset, limit = max(0, int(offset)), min(500, max(1, int(limit)))
        with self.connect() as db:
            state = self._state(db, project_id)
            rows = [_json(row[0]) for row in db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision LIMIT ? OFFSET ?", (project_id, limit, offset))]
        return {"revision": state["revision"], "offset": offset, "total": state["revision"], "rows": rows}

    def original(self, project_id, file_id):
        with self.connect() as db:
            state = self._state(db, project_id)
            record = next((item for item in state["files"] if item["id"] == file_id), None)
            if record is None:
                raise KeyError("Original file is outside this project.")
            raw = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (record["sha256"],)).fetchone()
            if raw is None:
                raise ValueError("Referenced original bytes are missing from this workspace.")
            return bytes(raw[0]), record

    def _file_bindings(self, state):
        files = {item["id"]: item for item in state["files"]}
        if len(files) != len(state["files"]):
            raise ValueError("Project original file identities are repeated.")
        for evidence in state["evidence"]:
            if evidence["source_file_id"]:
                original = files.get(evidence["source_file_id"])
                if original is None or original["sha256"] != evidence["source_sha256"]:
                    raise ValueError("Evidence file identity and SHA-256 must match an attached project original.")
        for measurement in state["measurements"]:
            binding = measurement.get("source_import")
            if binding is not None:
                evidence = engine._record(state, "evidence", binding["evidence_id"])
                if evidence["source_file_id"] != binding["source_file_id"] or evidence["source_sha256"] != binding["sha256"]:
                    raise ValueError("Imported event mapping no longer matches its original evidence version.")

    def validate_state(self, state):
        if state.get("schema") != engine.SCHEMA or state.get("workspace_schema") != SCHEMA:
            raise ValueError("Unsupported PLAN project schema.")
        engine._id(state.get("id"), "Project ID")
        required(state.get("name"), "Project name", 200)
        if type(state.get("revision")) is not int or state["revision"] < 1:
            raise ValueError("Project revision must be a positive integer.")
        for key in ("created_at", "updated_at"):
            engine._instant(state.get(key), key)
        for collection in engine.COLLECTIONS:
            rows = state.get(collection)
            if not isinstance(rows, list) or len(rows) > MAX_COLLECTION_ROWS or len({record.get("id") for record in rows if isinstance(record, dict)}) != len(rows):
                raise ValueError("Assessment collection has malformed, repeated or excessive records: " + collection)
            for record in rows:
                normalized = engine.validate_record(collection, record, state)
                if canonical(normalized) != canonical(record):
                    raise ValueError("Assessment record is not normalized to its current schema: " + collection + "/" + record["id"])
        if not isinstance(state.get("files"), list):
            raise ValueError("Project originals must have a file inventory.")
        for record in state["files"]:
            filename = required(record.get("filename"), "Original filename", 240)
            if filename != Path(filename).name or "\\" in filename or any(ord(char) < 32 for char in filename):
                raise ValueError("Original filename must be a plain filename without a path or control characters.")
            expected_id = "file-" + digest({"sha256": record.get("sha256"), "filename": filename})[:32]
            if record.get("id") != expected_id or type(record.get("bytes")) is not int or not 0 <= record["bytes"] <= MAX_SOURCE_BYTES:
                raise ValueError("Original file identity or byte length is inconsistent.")
        self._file_bindings(state)
        for field in ("lsp_count", "regional_count", "specialized_count", "office_count"):
            if type(state.get("scope", {}).get(field)) is not int or state["scope"][field] < 0:
                raise ValueError("The source scope must preserve nonnegative whole counts.")
        if state["scope"]["lsp_count"] != state["scope"]["regional_count"] + state["scope"]["specialized_count"]:
            raise ValueError("The source roster total must equal its declared category counts.")
        scope = state["scope"]
        expected_scope = set(engine.new_assessment("Schema reference")["scope"])
        if set(scope) != expected_scope:
            raise ValueError("The source scope must retain its explicit RFP field schema.")
        for field in ("scope_source", "reference_count_meaning", "appendix_a", "phase"):
            required(scope.get(field), "Source scope " + field, 20000)
        months = scope.get("assessment_months")
        if not isinstance(months, list) or len(months) != 2 or any(type(value) is not int or value < 0 for value in months) or months[1] < months[0]:
            raise ValueError("Assessment months must be an explicit nonnegative lower/upper range.")
        if not isinstance(scope.get("reported_office_channels"), list):
            raise ValueError("Source-reported office channel counts must be an explicit list.")
        channel_names = []
        for row in scope["reported_office_channels"]:
            if not isinstance(row, dict) or set(row) != {"channel", "count"}:
                raise ValueError("Source office channel rows must contain channel and count only.")
            channel_names.append(required(row["channel"], "Source channel context", 200))
            if type(row["count"]) is not int or row["count"] < 0:
                raise ValueError("Source-reported channel counts must be nonnegative integers.")
        if len(set(channel_names)) != len(channel_names):
            raise ValueError("Source office channel count contexts must be distinct.")
        if len(canonical(state).encode()) > MAX_STATE_BYTES:
            raise ValueError("Project state exceeds 48 MiB; use declared source periods or aggregate extracts for this local assessment.")
        engine.assess(state)

    def apply(self, project_id, operation, payload, expected_revision, request_id, actor="Operator"):
        required(request_id, "Request ID", 200)
        required(actor, "Operator", 200)
        if not isinstance(payload, dict):
            raise ValueError("Operation payload must be an object.")
        request_hash = digest({"operation": operation, "payload": payload, "expected_revision": expected_revision, "actor": actor})
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                old = db.execute("SELECT digest,result FROM requests WHERE project_id=? AND request_id=?", (project_id, request_id)).fetchone()
                if old:
                    if old["digest"] != request_hash:
                        raise Conflict("This request ID already has different input. Keep its original result and use a new request ID for the new action.")
                    return _json(old["result"])
                state = self._state(db, project_id)
                if type(expected_revision) is not int or expected_revision != state["revision"]:
                    raise Conflict("The project changed. Reload its current revision; this submitted edit was not saved.", state["revision"])
                event_payload, resource = self._change(db, state, operation, payload, actor)
                self._file_bindings(state)
                if len(canonical(state).encode()) > MAX_STATE_BYTES:
                    raise ValueError("Project state exceeds the supported 48 MiB operating limit.")
                previous = _json(db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision DESC LIMIT 1", (project_id,)).fetchone()[0])["hash"]
                state["revision"] += 1
                state["updated_at"] = utc()
                event = self._event(state, actor, operation, event_payload, previous, request_id, request_hash)
                result = {"project_id": project_id, "revision": state["revision"], "operation": operation, "event_hash": event["hash"], "resource": resource}
                db.execute("UPDATE projects SET revision=?,state=? WHERE id=?", (state["revision"], canonical(state), project_id))
                db.execute("INSERT INTO events VALUES(?,?,?)", (project_id, state["revision"], canonical(event)))
                db.execute("INSERT INTO requests VALUES(?,?,?,?)", (project_id, request_id, request_hash, canonical(result)))
                db.commit()
                return result
            except Exception:
                db.rollback()
                raise

    def _save_record(self, state, collection, record):
        if collection not in engine.COLLECTIONS or not isinstance(record, dict):
            raise ValueError("Select an assessment collection and a complete record.")
        record = deepcopy(record)
        old = next((item for item in state[collection] if item["id"] == record.get("id")), None)
        if old is not None and old.get("provider_id") != record.get("provider_id"):
            raise ValueError("An existing record retains its provider ownership. Create a separately scoped record and explicit source decision for reassignment.")
        if collection == "measurements" and old is not None and "definition_digest" not in record:
            record["definition_digest"] = old["definition_digest"]
        if collection == "measurements" and old is not None and record.get("event_preview_limit"):
            raise ValueError("A project preview cannot replace the full source cohort. Open the complete measurement record before editing it.")
        normalized = engine.validate_record(collection, record, state)
        if old is None and len(state[collection]) >= MAX_COLLECTION_ROWS:
            raise ValueError("This assessment collection already contains 2,000 records.")
        state[collection] = [normalized if item["id"] == normalized["id"] else item for item in state[collection]] if old else state[collection] + [normalized]
        return {"collection": collection, "id": normalized["id"], "previous_content_hash": digest(old) if old else None, "content_hash": digest(normalized)}, normalized

    def _change(self, db, state, operation, payload, actor):
        if operation == "record.save":
            event, record = self._save_record(state, payload.get("collection"), payload.get("record"))
            return event, {"collection": event["collection"], "id": record["id"]}
        if operation == "record.delete":
            collection = payload.get("collection")
            if collection not in engine.COLLECTIONS:
                raise ValueError("Unknown assessment collection.")
            record = engine._record(state, collection, payload.get("id"))
            state[collection] = [item for item in state[collection] if item["id"] != record["id"]]
            self.validate_state(state)
            return {"collection": collection, "id": record["id"], "previous_content_hash": digest(record)}, {"collection": collection, "id": record["id"], "status": "deleted"}
        if operation == "project.rename":
            state["name"] = required(payload.get("name"), "Project name", 200)
            return {"name": state["name"]}, {"id": state["id"]}
        if operation == "scope.save":
            scope = deepcopy(payload.get("scope"))
            if not isinstance(scope, dict) or not payload.get("basis") or not payload.get("evidence_refs"):
                raise ValueError("A scope revision requires the actual addendum/decision basis and source evidence.")
            refs = engine._references(state, payload["evidence_refs"], allow_cross_provider=True)
            state["scope"] = scope
            self.validate_state(state)
            return {"scope": scope, "basis": required(payload["basis"], "Source scope revision basis"), "evidence_refs": refs}, {"id": state["id"], "scope_updated": True}
        if operation == "recommendation.decide":
            record = engine.record_recommendation_decision(state, payload.get("id"), payload.get("decision"), actor, payload.get("basis"), payload.get("at") or utc())
            event, saved = self._save_record(state, "recommendations", record)
            return event | {"decision": saved["status"], "basis": saved["decision_basis"]}, {"id": saved["id"], "status": saved["status"]}
        if operation == "measurement.rebind":
            record = deepcopy(engine._record(state, "measurements", payload.get("id")))
            basis = required(payload.get("basis"), "Source cohort/definition reconciliation basis")
            record["definition_digest"] = digest(engine._record(state, "metric_definitions", record["definition_id"]))
            record["notes"] = (record["notes"] + "\n\nDefinition reconciliation by " + actor + ": " + basis).strip()
            event, saved = self._save_record(state, "measurements", record)
            return event | {"basis": basis}, {"id": saved["id"], "definition_digest": saved["definition_digest"]}
        if operation == "evidence.add":
            filename = required(payload.get("filename"), "Original filename", 240)
            if filename != Path(filename).name or "\\" in filename or any(ord(char) < 32 for char in filename):
                raise ValueError("Use an original filename without a path or control characters.")
            encoded = payload.get("content_base64")
            if not isinstance(encoded, str) or len(encoded) > (MAX_SOURCE_BYTES + 2) // 3 * 4:
                raise ValueError("One original file may contain at most 32 MiB.")
            try:
                raw = base64.b64decode(encoded, validate=True)
            except (ValueError, TypeError) as exc:
                raise ValueError("Original file content must be valid base64.") from exc
            if len(raw) > MAX_SOURCE_BYTES:
                raise ValueError("One original file may contain at most 32 MiB.")
            sha = hashlib.sha256(raw).hexdigest()
            file_id = "file-" + digest({"sha256": sha, "filename": filename})[:32]
            original = {"id": file_id, "filename": filename, "sha256": sha, "bytes": len(raw), "media_type": required(payload.get("media_type") or "application/octet-stream", "Media type", 200)}
            unique = {item["sha256"]: item["bytes"] for item in state["files"]}
            unique[sha] = len(raw)
            if sum(unique.values()) > MAX_PROJECT_SOURCE_BYTES:
                raise ValueError("This project's original source files exceed 128 MiB; retain a separately scoped period or project.")
            prior_file = next((item for item in state["files"] if item["id"] == file_id), None)
            if prior_file is None:
                state["files"].append(original)
            else:
                original = prior_file
            metadata = deepcopy(payload.get("metadata", {}))
            if not isinstance(metadata, dict):
                raise ValueError("Evidence metadata must be an object.")
            metadata.update({"id": metadata.get("id") or "evidence-" + uuid.uuid4().hex, "title": metadata.get("title") or filename, "source_file_id": file_id, "source_sha256": sha})
            event, saved = self._save_record(state, "evidence", metadata)
            existing = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (sha,)).fetchone()
            if existing is not None and bytes(existing[0]) != raw:
                raise Conflict("This original byte identity already contains different data.")
            db.execute("INSERT OR IGNORE INTO raw_sources VALUES(?,?)", (sha, raw))
            return event | {"file": original}, {"collection": "evidence", "id": saved["id"], "source_file_id": file_id, "sha256": sha}
        if operation == "measurement.import":
            evidence = engine._record(state, "evidence", payload.get("evidence_id"))
            if not evidence["source_file_id"]:
                raise ValueError("Attach the original source bytes before mapping its event records.")
            file_record = next(item for item in state["files"] if item["id"] == evidence["source_file_id"])
            raw = bytes(db.execute("SELECT data FROM raw_sources WHERE sha256=?", (file_record["sha256"],)).fetchone()[0])
            events, binding = map_source_events(raw, file_record, payload)
            record = deepcopy(payload.get("measurement", {}))
            if not isinstance(record, dict) or record.get("provider_id") != evidence["provider_id"]:
                raise ValueError("Imported event records must belong to the source evidence's provider.")
            record.update({"basis": "events", "events": events, "source_import": binding})
            record["evidence_refs"] = list(dict.fromkeys(record.get("evidence_refs", []) + [evidence["id"]]))
            event, saved = self._save_record(state, "measurements", record)
            return event | {"source_import": binding, "source_rows": len(events)}, {"id": saved["id"], "event_count": len(events), "source_sha256": file_record["sha256"]}
        raise ValueError("Unknown PLAN operation: " + str(operation))

    def projection(self, project_id, audience, provider_id=None):
        with self.connect() as db:
            state = self._state(db, project_id)
        return engine.project_export(state, audience, provider_id)

    def snapshot(self, project_id):
        with self.connect() as db:
            db.execute("BEGIN")
            state = self._state(db, project_id)
            originals = {}
            for file in state["files"]:
                if file["sha256"] not in originals:
                    row = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (file["sha256"],)).fetchone()
                    if row is None:
                        raise ValueError("A project original is missing from this workspace.")
                    originals[file["sha256"]] = bytes(row[0])
            events = [_json(row[0]) for row in db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision", (project_id,))]
            requests = [dict(row) for row in db.execute("SELECT request_id,digest,result FROM requests WHERE project_id=? ORDER BY request_id", (project_id,))]
        return {"state": state, "raw": originals, "events": events, "requests": requests}

    def restore_snapshot(self, snapshot):
        state, events, requests = snapshot["state"], snapshot["events"], snapshot["requests"]
        self.validate_state(state)
        previous = ""
        if not isinstance(events, list) or len(events) != state["revision"]:
            raise ValueError("Project revision and retained event history disagree.")
        for revision, event in enumerate(events, 1):
            if event.get("project_id") != state["id"] or event.get("revision") != revision or event.get("previous_hash") != previous or digest({key: value for key, value in event.items() if key != "hash"}) != event.get("hash"):
                raise ValueError("Project event chain is incomplete or has different content.")
            previous = event["hash"]
        if events[-1].get("state_hash") != digest(state):
            raise ValueError("The archived current state is not the state bound to its final event.")
        if not isinstance(requests, list) or len({row.get("request_id") for row in requests}) != len(requests):
            raise ValueError("Saved request identities are repeated or malformed.")
        for request in requests:
            required(request.get("request_id"), "Saved request ID", 200)
            result = _json(request["result"])
            revision = result.get("revision")
            if type(revision) is not int or not 1 <= revision <= len(events) or result.get("project_id") != state["id"] or result.get("event_hash") != events[revision-1]["hash"] or result.get("operation") != events[revision-1]["kind"] or request["request_id"] != events[revision-1].get("request_id") or request.get("digest") != events[revision-1].get("request_digest"):
                raise ValueError("A saved request result is not bound to its original project event.")
        expected_originals = {item["sha256"] for item in state["files"]}
        if set(snapshot["raw"]) != expected_originals:
            raise ValueError("Private archive originals do not exactly match the project file inventory.")
        for file in state["files"]:
            raw = snapshot["raw"][file["sha256"]]
            if len(raw) != file["bytes"] or hashlib.sha256(raw).hexdigest() != file["sha256"]:
                raise ValueError("An original file differs from its declared SHA-256 or byte length.")
        if sum(len(raw) for raw in snapshot["raw"].values()) > MAX_PROJECT_SOURCE_BYTES:
            raise ValueError("Private archive original sources exceed 128 MiB.")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                existing = db.execute("SELECT state FROM projects WHERE id=?", (state["id"],)).fetchone()
                if existing:
                    current_events = [_json(row[0]) for row in db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision", (state["id"],))]
                    current_requests = [dict(row) for row in db.execute("SELECT request_id,digest,result FROM requests WHERE project_id=? ORDER BY request_id", (state["id"],))]
                    if existing[0] == canonical(state) and current_events == events and current_requests == requests:
                        for sha, raw in snapshot["raw"].items():
                            retained = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (sha,)).fetchone()
                            if retained is None or bytes(retained[0]) != raw:
                                raise Conflict("The existing project has missing or different original bytes; preserve its database and restore into a separate workspace.")
                        return {"id": state["id"], "revision": state["revision"], "status": "already_present"}
                    raise Conflict("This project ID already contains different work. Restore into a separate workspace database to preserve both branches.")
                for sha, raw in snapshot["raw"].items():
                    old = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (sha,)).fetchone()
                    if old is not None and bytes(old[0]) != raw:
                        raise Conflict("An existing original source hash has different bytes.")
                    db.execute("INSERT OR IGNORE INTO raw_sources VALUES(?,?)", (sha, raw))
                db.execute("INSERT INTO projects VALUES(?,?,?)", (state["id"], state["revision"], canonical(state)))
                for event in events:
                    db.execute("INSERT INTO events VALUES(?,?,?)", (state["id"], event["revision"], canonical(event)))
                for request in requests:
                    db.execute("INSERT INTO requests VALUES(?,?,?,?)", (state["id"], request["request_id"], request["digest"], request["result"]))
                db.commit()
                return {"id": state["id"], "revision": state["revision"], "status": "restored"}
            except Exception:
                db.rollback()
                raise
