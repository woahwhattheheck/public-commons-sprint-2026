"""Repeatable import of the actual public PLAN RFP and provider-directory bytes."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

if __package__:
    from .workspace import Conflict
else:
    from workspace import Conflict

ROOT = Path(__file__).resolve().parent / "demo" / "sources"
PROJECT_ID = "plan-public-discovery-20261011-v1"
ACTOR = "Public source import"


def seed_demo(workspace):
    manifest = json.loads((ROOT / "source_manifest.json").read_text())
    candidates = json.loads((ROOT / "public-provider-candidates.json").read_text())
    source_ref = {"kind": "public_source_seed", "id": PROJECT_ID, "manifest_sha256": hashlib.sha256((ROOT / "source_manifest.json").read_bytes()).hexdigest(),
                  "meaning": "Original public reference material and authored Phase 1 collection tasks. No supplied engagement roster, confidential provider baseline, consultation or client acceptance is implied."}
    try:
        current = workspace.get(PROJECT_ID)
        if source_ref not in current["source_refs"]:
            raise Conflict("This project ID belongs to different source work; preserve it and use another workspace for this public seed.")
    except KeyError:
        try:
            workspace.create("PLAN Phase 1 — public source discovery", ACTOR, PROJECT_ID, candidates, [source_ref])
        except Conflict:
            current = workspace.get(PROJECT_ID)
            if source_ref not in current["source_refs"]:
                raise
    operations = []
    evidence_ids = {}
    for entry in manifest["entries"]:
        if not entry.get("attach_to_project", True):
            continue
        filename = entry["file"]
        raw = (ROOT / filename).read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["sha256"] or len(raw) != entry["bytes"]:
            raise ValueError("The packaged public source differs from its frozen identity: " + filename)
        evidence_id = entry["evidence_id"]
        evidence_ids[filename] = evidence_id
        operations.append(("evidence.add", {"filename": filename, "content_base64": base64.b64encode(raw).decode(), "media_type": entry["media_type"],
                        "metadata": {"id": evidence_id, "provider_id": None, "title": entry["title"], "kind": "public_document", "classification": "public",
                                     "source_url": entry.get("source_url", ""), "locator": entry["locator"], "summary": entry["summary"], "limitations": entry["limitations"], "version": entry["version"]}}))
    rfp = evidence_ids["PLAN_Phase1_RFP_20260924.pdf"]
    regional = evidence_ids["plan-regional-programs.html"]
    specialty = evidence_ids["plan-specialty-programs.html"]
    collection_tasks = [
        {"id": "collection-roster-pathways", "title": "Reconcile assessment participants, offices and intake pathways", "problem": "The public directory contains 14 entries while the RFP specifies 13 assessment units. Its program-office counts and the RFP's channel-office counts describe different sets.",
         "action": "Obtain the supplied engagement roster and Appendix A profiles. Record each explicit candidate-to-assessment relationship. Build the actual named office/channel inventory for telephone, online, walk-in, referral, outreach, mail and hotline variants, retaining shared hosts and overlap.",
         "owner_role": "PLAN project lead and participating LSP representatives", "evidence_refs": [rfp, regional, specialty], "deliverables": "Source-bound participant decisions and individual office/channel inventories.", "acceptance": "Named roster decisions cite the supplied source; no directory entry is silently excluded and shared office/channel assignments remain visible."},
        {"id": "collection-systems-data", "title": "Inventory local technology and usable source extracts", "problem": "The RFP identifies LegalServer across LSPs and differing local telephony, form, scheduling and online-intake arrangements; actual installed versions and source completeness remain local discovery inputs.",
         "action": "Record each participating LSP's actual systems, modules, interfaces, intake fields and available export permissions. Attach representative original extracts and define their grain, missing fields, timezones and source identity before mapping metrics.",
         "owner_role": "Each LSP's operations/technology lead with the assessment analyst", "evidence_refs": [rfp], "deliverables": "Technology and data-quality inventory with original bytes and reproducible event mappings.", "acceptance": "Each reported capability or limitation is tied to source evidence, and missing baseline inputs produce a concrete collection or system-change recommendation."},
        {"id": "collection-local-metrics", "title": "Define local success and measure the supplied cohorts", "problem": "The RFP requests channel volumes, waiting/talking time, decision time and abandonment where available, but does not prescribe a common numeric SLA or supply public operational baselines.",
         "action": "Agree local success with each LSP and PLAN. Define source counting units, numerator/denominator, eligibility/accept/reject outcome, clock, cutoff and source coverage. Map actual records or retain labeled source aggregates; assess capacity with explicit staff-pool and handling-time assumptions.",
         "owner_role": "LSP intake and supervising-attorney leads with PLAN", "evidence_refs": [rfp], "dependencies": ["collection-systems-data"], "deliverables": "Versioned local metric definitions, source-bound baselines and actionable missing-data work.", "acceptance": "Pending, excluded, unmapped and duplicate records are retained; comparisons use matching definitions and compatible populations."},
        {"id": "collection-people-access", "title": "Collect staff and applicant access experience", "problem": "RFP section5 calls for staff, supervising-attorney and leadership input and applicant input where feasible and agreed, including language and disability access.",
         "action": "Adapt role-specific interviews and surveys to each LSP's pathways. Record participant role, source context and interpretation separately. Agree feasible applicant engagement with the LSP, then connect reported barriers to specific process steps and evidence.",
         "owner_role": "Assessment lead and each LSP's designated engagement/access lead", "evidence_refs": [rfp], "deliverables": "Local interview/survey workpapers and source-linked access observations.", "acceptance": "No interview, survey response or client experience is represented as collected until its actual source is attached or recorded."},
        {"id": "collection-individual-maps", "title": "Review individual process maps and recommendations", "problem": "The engagement requires independent assessments and editable process maps for13LSPs, with local recommendations when requested rather than a predetermined statewide system.",
         "action": "Build and review each LSP's actual pathways, roles, waits, branches, handoffs and access needs. Use the observed local process and metrics to distinguish immediate low-cost changes from longer-term technology dependencies; record the request for an individual recommendation package.",
         "owner_role": "Each LSP's accountable intake lead and assessment team", "evidence_refs": [rfp], "dependencies": ["collection-local-metrics", "collection-people-access"], "deliverables": "Editable individual maps, findings and requested recommendations.", "acceptance": "Local source evidence supports the map and findings, the review disposition is recorded, and future architecture is a recommendation rather than an assumed engagement outcome."},
        {"id": "collection-consolidation-roadmap", "title": "Prepare consulted consolidation and accepted-work implementation planning", "problem": "PLAN determines consolidated use in consultation with each relevant LSP; third-party release has a separate written-consent requirement. Later implementation planning follows accepted recommendations.",
         "action": "Prepare exact proposed consolidated findings. Record the relevant LSP consultation and PLAN's disposition for that content, preserving disagreement without an extra LSP veto. Translate accepted recommendations into owners, prerequisites, dependencies, estimated work and later-phase RFP scopes.",
         "owner_role": "PLAN project lead with relevant LSP consultation", "evidence_refs": [rfp], "dependencies": ["collection-individual-maps"], "deliverables": "Consolidated report and presentation; accepted-work implementation roadmap and requested later RFP drafts.", "acceptance": "Recipient bundles contain only the proper source scope; current consultation and PLAN decisions bind the exact use; effort, elapsed duration and estimated cost remain distinguishable."},
    ]
    for record in collection_tasks:
        record.update({"provider_id": None, "status": "proposed", "horizon": "near_term", "priority": "unranked", "governance": "Authored Phase 1 collection workstream based on the public RFP; not an observed LSP defect, a client acceptance or a commitment by a named person.",
                       "accessibility": "Retain language, disability access and alternate intake-pathway needs in local evidence and review."})
        operations.append(("record.save", {"collection": "recommendations", "record": record}))
    for index, (operation, payload) in enumerate(operations, 1):
        # The same exact inputs and base revision reproduce the original receipt;
        # a partial seed can resume without overwriting intervening operator edits.
        workspace.apply(PROJECT_ID, operation, payload, index, "public-seed-v1-" + str(index), ACTOR)
    current = workspace.get(PROJECT_ID)
    county_links = [county for candidate in candidates["records"] for county in candidate.get("counties_published") or []]
    return {"id": PROJECT_ID, "revision": current["revision"], "status": "public_sources_ready", "original_evidence_files": len(evidence_ids),
            "public_candidates": len(current["candidates"]), "confirmed_assessment_units": current["computed"]["roster"]["confirmed_assessment_units"],
            "public_county_links": len(county_links), "distinct_published_county_spellings": len(set(county_links)),
            "source_collection_workstreams": len(collection_tasks), "operational_measurements": len(current["measurements"]),
            "source_meaning": "Actual public publications and authored source collection tasks. The supplied participant roster and private operational baselines are still independent inputs."}
