# PLAN Phase 1 Intake Assessment Workbench

A local operating workspace for independent legal-aid intake assessments: retain original evidence, define local measures, map each provider's process, connect recommendations to dependencies, and produce individual or consolidated workpapers with the correct source scope.

The application includes a clean browser interface, a Python API, a SQLite workspace, editable report bundles, and a complete export/restore format. It runs on Python 3.10 or later using the standard library. No hosted account, model API, service subscription or JavaScript build step is required.

## Start the application

From the supplied source directory containing this README:

```bash
python server.py --workspace ./plan-workspace --demo
```

Open **http://127.0.0.1:8769**. The workspace directory contains `projects.sqlite3`; use the same directory when restarting to continue saved work.

For an installed wheel:

```bash
python -m pip install --no-index --no-deps ./plan_phase1_workbench-0.1.0-py3-none-any.whl
plan-workbench --workspace ./plan-workspace --demo
```

The equivalent module command is `python -m plan_operator`. The server prints its exact local URL and workspace path. Use `--port` to select another local port. Omit `--demo` for an empty workspace, or create another assessment project through the interface.

The public project is repeatable: opening it again preserves the existing project and its saved edits. Its fixed identity is `plan-public-discovery-20261011-v1`. A source package with a different public manifest requires a distinct seed identity instead of silently replacing those original records.

## Work through an assessment

1. **Reconcile the actual participants.** The public directory has fourteen candidates; the RFP scopes thirteen assessment units. Create each supplied unit and record its actual source-backed roster decision. Record offices and channels separately, including shared telephone hosts and multiple channel memberships.
2. **Retain source evidence.** Attach an original extract, document or workpaper. Identify its provider, source version, classification, location in the original and any limitations. The application retains the exact bytes and checksum.
3. **Define local success and measures.** Record the counting unit, population, exclusions, denominator, outcome, clock and observation cutoff. Define eligibility, acceptance and rejection time separately when the source describes different decisions.
4. **Map original events or a reported aggregate.** Import CSV or JSON with an explicit field map, or enter a source-reported aggregate with its denominator and period. Inspect original mapped rows and their source locators. Pending, missing, excluded and duplicate records stay visible.
5. **Review the individual pathway.** Build an editable process map from the local evidence. Steps, decisions, responsible roles, referrals, access needs and return loops remain specific to the provider. The collection template is an authored starting point.
6. **Record recommendations and their actual decisions.** Connect a problem to an action, source, accountable role, prerequisites, deliverable and acceptance condition. Accepted current content enters a dependency-aware relative workday plan. Editing that content makes the affected acceptance decision visible for review.
7. **Prepare the appropriate recipient output.** An individual provider receives its own assessment/workpapers. PLAN-restricted output includes the individual assessments. Consolidated use records PLAN's decision and consultation with each affected provider for the specific current finding and sources.
8. **Save a complete project for continuation.** Export the private restore ZIP, then restore it into a separate workspace to continue editing with the original records, files and revision history.

## Actual public demonstration

The supplied project retains seven original or explicitly derived publication files, fourteen public directory candidates, sixty-eight provider–county links across sixty-seven distinct published county spellings, and six authored collection workstreams. It includes no confidential operational baseline, completed interview, participant consent or invented roster selection.

The source RFP specifies thirteen LSPs, sixty-seven offices and independent assessments over an estimated nine to twelve months. Its forty-eight walk-in offices and twenty-two telephone-host/coordinator offices are overlapping memberships. The application shows the corresponding union bounds and preserves named office memberships when supplied. These facts and the request-only status of Appendix A come from the [September 24 RFP](https://www.lsntap.org/sites/default/files/2026-09/plan-statewide-intake-improvement-project-phase-1-assessment-and-planning-rfp-issue-2026-09-24-1.pdf). Public candidate records are derived from PLAN's [regional](https://palegalaid.net/plan-regional-legal-aid-programs) and [specialty](https://palegalaid.net/plan-specialty-legal-aid-program) directories.

Every retained input has an exact identity in `demo/sources/source_manifest.json`. The PDF is authoritative; its OCR is a reading aid. Authored source-contract records distinguish published requirements from proposed application behavior. See `SOURCE-NOTICES.md` for source ownership and derivation details.

## Measures and interpretation

| Measure | Required local meaning |
| --- | --- |
| Channel volume | A defined call attempt, contact, application, intake, person or other source unit; office/channel assignment and duplicate handling |
| Channel share | Same-population numerator and denominator; multi-touch overlap remains visible |
| Call wait | Queue entry to answer for completed answered interactions; abandonment and still-waiting records remain separate |
| Call talk | Answer to the declared completion event, including the stated call-leg and wrap-up treatment |
| Decision time | First contact to one specified eligibility, acceptance or rejection decision, with its cohort and cutoff |
| Abandonment | Explicit offered-interaction population, terminal outcomes and short-abandon rule |
| Capacity | Staffing time and observed work in one period and staff pool; handling-time assumptions are labeled |
| Local success | The provider/PLAN success statement, definition revision, baseline, target basis and local context |

No universal response-time target is imposed. A missing source field is an actionable collection need. Date-only reporting periods require an explicit timezone; event timestamps require offsets. Business-hour clocks require the actual working windows and holiday calendar. Definitions remain bound to the cohorts that used them: editing a definition does not relabel a previous baseline. Explicit reconciliation records the operator's basis before recomputation.

Network pooling uses compatible definitions, clocks, periods and source coverage. It sums matching numerators/denominators or duration totals/completed counts. It does not average percentages or invent pooled percentiles. Distinct provider cohorts require a recorded disjointness basis. A true zero-of-zero cohort contributes zero observations to a compatible positive-denominator pool; an all-zero denominator remains undefined.

## Reports, decisions and continuation

| Export | Contents and use |
| --- | --- |
| Complete project / `private_restore` | Full working state, original files, saved request results and revision history; suitable for continuing in another local workspace |
| Individual / `lsp` | One provider's records, source originals, process maps and dependency-aware roadmap |
| PLAN-restricted / `plan_restricted` | Individual assessments and underlying workpapers available to PLAN |
| Consolidated / `consolidated` | Findings with a current PLAN use decision and the required consultation records; selected public source material, without other providers' private source identifiers or workpapers |

The RFP's section 11 gives PLAN the consolidated-use decision **in consultation with** each affected LSP. A recorded LSP objection remains its position and does not become a veto. The application binds PLAN's use decision to the current finding, sources and consultation records, so a later material change identifies the specific decision needing review. The separate RFP rule for third-party distribution requires prior written PLAN and relevant LSP consent.

Recipient bundles contain editable JSON/CSV, printable HTML, process-map source and implementation workpapers. They are intentionally distinct from a complete continuation archive. For a command-line backup:

```bash
plan-workbench --workspace ./plan-workspace \
  --export plan-public-discovery-20261011-v1 \
  --audience private_restore --output ./plan-project.zip

plan-workbench --workspace ./restored-workspace --restore ./plan-project.zip
```

An identical private archive restores idempotently. A divergent project with the same identity must be opened in a separate workspace; existing work is not overwritten. Editing a restored project creates the next recorded revision.

## Developer interface

Use `/api/catalog` for the current record templates, source requirements, metric choices, operation names and consultation decision vocabulary. The browser and command line call the same workspace and export functions.

```python
from plan_operator.workspace import Workspace
from plan_operator.demo import seed_demo
from plan_operator.exports import export_project, import_project

workspace = Workspace("./developer-workspace/projects.sqlite3")
project = seed_demo(workspace)
archive, manifest = export_project(workspace, project["id"], "private_restore")
```

All changes use an expected project revision, request identity and operator name. Source bytes, state, event history and the saved request result commit atomically. An exact request replay returns its original result; a conflicting revision returns the current revision while the browser retains the editor input.

The project endpoint returns summaries and previews. Use the paginated record/event endpoints for full cohorts. Save a full fetched record when editing an existing measurement; a preview cannot overwrite a retained event cohort. `ENGINE.md` documents the exact records, source mapping, export rules and HTTP endpoints.

## Deployment and data size

The application is a local operator workspace. The HTTP server binds to loopback, validates its local host/origin, and stores files in the workspace database. Recipient sharing is explicit through exported bundles. It does not create remote user accounts, connect directly to LegalServer/telephony systems, or purchase hosting. Source extraction remains with the agreed system operator.

Current limits are 32 MiB per original file, 100,000 records per mapped event cohort, 128 MiB of original bytes per project and 48 MiB of structured project state. Larger operational histories can use source-defined reporting periods or declared aggregates. These are implementation limits, not assumptions about an LSP's intake volume. The source workbench can be adapted under a separately specified integration scope where larger or connected operation is needed.

## Verified operating behavior

The public-source seed completed repeatable import, private export, fresh restore and recipient report generation with its actual retained originals. A separate explicitly authored native HTTP workflow exercised original CSV mapping, event pagination, exact request replay, revision conflict handling, changed-definition reconciliation, weighted aggregation, consulted disagreement, audience-specific original-file selection, full restore and continued editing. The authored operational records are not included in the public seed.

The installable package contains the full source modules, browser assets, documentation and public demonstration input closure. The application code is MIT-licensed. Original publications retain their own terms as described in `LICENSE` and `SOURCE-NOTICES.md`.

