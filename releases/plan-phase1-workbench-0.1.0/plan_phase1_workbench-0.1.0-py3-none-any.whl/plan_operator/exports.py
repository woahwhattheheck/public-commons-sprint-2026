"""Distinct private continuation archives and source-scoped PLAN report bundles."""
from __future__ import annotations

import csv
import hashlib
import html
import io
import json
import re
import zipfile
from pathlib import PurePosixPath

if __package__:
    from . import engine
    from .workspace import _json
else:
    import engine
    from workspace import _json

PRIVATE_SCHEMA = "plan.assessment-private-restore/v1"
RECIPIENT_SCHEMA = "plan.assessment-recipient/v1"
MAX_ARCHIVE_BYTES = 192 * 1024 * 1024


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def safe_name(value):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value))[:140] or "item"


def csv_bytes(rows, columns):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore", lineterminator="\r\n")
    writer.writeheader()
    for row in rows:
        values = {}
        for key in columns:
            value = row.get(key)
            if isinstance(value, (list, dict)):
                value = engine.canonical(value)
            if isinstance(value, str) and value.startswith(("=", "+", "@", "\t", "\r")):
                value = "'" + value
            values[key] = value
        writer.writerow(values)
    return stream.getvalue().encode("utf-8")


def esc(value):
    return html.escape(str(value if value is not None else "Not measured"))


def table(headers, rows):
    return '<div class="table"><table><thead><tr>' + "".join('<th scope="col">' + esc(header) + "</th>" for header in headers) + "</tr></thead><tbody>" + "".join("<tr>" + "".join("<td>" + esc(cell) + "</td>" for cell in row) + "</tr>" for row in rows) + "</tbody></table></div>"


def report_html(projection):
    audience = projection["audience"]
    scope = projection["scope"]
    body = ['<header><div class="eyebrow">PLAN · INDEPENDENT INTAKE ASSESSMENT · PHASE 1</div><h1>' + esc(projection["name"]) + '</h1><p>' + esc(audience.replace("_", " ")) + '</p></header>',
            '<section><h2>Assessment and recipient scope</h2><p>' + esc(projection["access_context"]) + '</p><p>' + esc(scope["phase"]) + '</p>',
            table(["Source context", "Value"], [("RFP assessment units", scope["lsp_count"]), ("RFP office universe", scope["office_count"]), ("Scope source", scope["scope_source"]), ("Underlying profiles", scope["appendix_a"])]), '</section>']
    if audience == "consolidated":
        body.append('<section><h2>Consolidated findings</h2>')
        if not projection["findings"]:
            body.append('<p>No individual findings currently have a recorded decision for this exact consolidated use. The separate source-based collection plan remains available in the operator workspace.</p>')
        for finding in projection["findings"]:
            body.append('<article><h3>' + esc(finding["title"]) + '</h3><p>' + esc(finding["body"]) + '</p>')
            if finding.get("organizations"):
                body.append('<p>Attributed organizations: ' + esc(", ".join(finding["organizations"])) + '</p>')
            if finding.get("measurement"):
                metric = finding["measurement"]
                body.append(table(["Metric", "Value", "Unit", "Numerator / denominator", "Meaning"], [(metric.get("metric_type"), metric.get("value"), metric.get("unit"), f'{metric.get("numerator", "—")} / {metric.get("denominator", "—")}', " ".join(metric.get("qualifications", [])))]))
            for metric in finding.get("measurements", []):
                result = metric["result"]
                body.append(table(["Organization", "Metric", "Value", "Unit", "Source definition"], [(metric["organization"], metric["name"], result.get("value"), result.get("unit"), metric["definition"]["population"])]))
            body.append(table(["Recommendation", "Action", "Horizon", "Disposition"], [(item["title"], item["action"], item["horizon"], item["status"]) for item in finding["recommendations"]]))
            body.append('</article>')
        body.append('</section>')
        evidence = projection["public_sources"]
    else:
        data = projection["assessment"]
        providers = [data["provider"]] if audience == "lsp" else data["providers"]
        body.append('<section><h2>Participant roster</h2>')
        body.append(table(["Assessment unit", "Category", "Roster decision", "Source rationale", "Local success"], [(item["name"], item["category"], item["roster_status"], item["roster_rationale"], item["success_statement"]) for item in providers]))
        candidates = data.get("candidates", [])
        body.append(table(["Published candidate", "Published group", "Published office count", "Source locator"], [(item["name_published"], item["group_published"], item.get("program_offices_published"), item.get("locator", "")) for item in candidates]))
        body.append('<p>Public candidates and confirmed engagement units remain separate. A missing published office count is not zero.</p></section>')
        body.append('<section><h2>Office and channel inventory</h2>')
        body.append(table(["Office", "Source status", "Location", "Notes"], [(item["name"], item["status"], item["location"], item["notes"]) for item in data["offices"]]))
        body.append(table(["Channel", "Kind", "Source status", "Office assignments", "Availability"], [(item["name"], item["kind"], item["status"], ", ".join(item["office_ids"]), item["availability"]) for item in data["channels"]]))
        body.append('</section><section><h2>Metrics and measurement definitions</h2>')
        metrics = projection["measurements"] if audience == "lsp" else [engine._export_metric(data, item) for item in data["measurements"]]
        if not metrics:
            body.append('<p>No operational baselines have been entered. The public RFP and provider directory do not supply individual interaction, staffing or applicant records.</p>')
        for metric in metrics:
            definition, result = metric["definition"], metric["result"]
            body.append('<h3>' + esc(metric["name"]) + '</h3>')
            body.append(table(["Property", "Definition / value"], [("Counting unit", definition["counting_unit"]), ("Population", definition["population"]), ("Numerator", definition["numerator_definition"]), ("Denominator", definition["denominator_definition"]), ("Exclusions", definition["exclusions"]), ("Clock", definition["clock"]), ("Current value", result.get("value")), ("Unit", result.get("unit")), ("State", result["status"]), ("Pending", result.get("pending_count")), ("Missing", result.get("missing_count")), ("Qualifications", " ".join(result.get("qualifications", []))), ("Required input", result.get("required_input", ""))]))
        body.append('</section><section><h2>Editable process maps</h2>')
        for workflow in data["workflows"]:
            mapped = engine.workflow_map(workflow)
            body.append('<h3>' + esc(workflow["name"]) + '</h3><p>Review state: ' + esc(workflow["status"]) + '. ' + esc(workflow["review_basis"]) + '</p>')
            body.append(table(["Step", "Kind", "Role", "Language / disability access", "Source notes"], [(node["label"], node["kind"], node["role"], node["accessibility"], node["notes"]) for node in workflow["nodes"]]))
            labels = {node["id"]: node["label"] for node in workflow["nodes"]}
            body.append(table(["From", "To", "Condition"], [(labels[edge["from"]], labels[edge["to"]], edge["label"]) for edge in workflow["edges"]]))
            body.append('<p>Map review: ' + esc(engine.canonical(mapped["review"])) + '</p>')
        body.append('</section><section><h2>Recommendations and implementation planning</h2>')
        body.append(table(["Recommendation", "Problem / action", "Horizon", "Owner", "Disposition / basis"], [(item["title"], item["problem"] + "\n" + item["action"], item["horizon"], item["owner_role"], item["status"] + "\n" + item["decision_basis"]) for item in data["recommendations"]]))
        roadmap = projection["roadmap"] if audience == "lsp" else projection["summary"]["roadmap"]
        body.append(table(["Accepted work", "Readiness", "Elapsed start / finish", "Person effort", "Assumption / outstanding item"], [(item["title"], item["readiness"], f'{item["earliest_start_workday"]} / {item["earliest_finish_workday"]}', item["effort_person_days"], item["estimate_basis"] + "\n" + "\n".join(item["attention"])) for item in roadmap["items"]]))
        body.append('<p>' + esc(roadmap["schedule_basis"]) + '</p></section>')
        evidence = data["evidence"]
    body.append('<section><h2>Source references</h2>')
    body.append(table(["Evidence", "Original SHA-256", "URL", "Page / row locator"], [(item["title"], item.get("source_sha256"), item.get("source_url"), item.get("locator")) for item in evidence]))
    body.append('<p>' + esc(projection["ownership"]) + '</p><p>Editable JSON, CSV and Mermaid workpapers accompany this report. A source hash identifies retained bytes; it is not an external signature or institutional acceptance.</p></section>')
    style = "body{font:14px/1.55 system-ui,sans-serif;color:#202020;max-width:1160px;margin:30px auto;padding:0 26px}header{border-bottom:3px solid #333;padding-bottom:18px}.eyebrow{font-size:11px;letter-spacing:.09em}h1{font-size:30px;margin:8px 0}h2{font-size:21px;border-top:1px solid #bbb;padding-top:18px;margin-top:28px}h3{font-size:16px;margin-top:22px}p{white-space:pre-wrap;overflow-wrap:anywhere}.table{overflow:auto}table{border-collapse:collapse;width:100%;margin:12px 0}th,td{border:1px solid #aaa;padding:8px;text-align:left;vertical-align:top;white-space:pre-wrap;overflow-wrap:anywhere}th{background:#eee;font-size:12px}tr{break-inside:avoid}@media print{body{font-size:10px;margin:0;padding:0}h1{font-size:22px}h2{font-size:16px}.table{overflow:visible}th,td{padding:5px}thead{display:table-header-group}@page{size:A4 landscape;margin:12mm}}"
    return ('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(projection["name"]) + ' — Intake assessment</title><style>' + style + '</style><body>' + "\n".join(body) + '</body></html>').encode()


def _recipient_workpapers(files, projection):
    files["report.html"] = report_html(projection)
    files["projection.json"] = json_bytes(projection)
    if projection["audience"] == "consolidated":
        files["findings.json"] = json_bytes(projection["findings"])
        return
    data = projection["assessment"]
    columns = {
        "offices": ["id", "provider_id", "name", "status", "location", "notes", "evidence_refs"],
        "channels": ["id", "provider_id", "name", "kind", "status", "office_ids", "centralized", "availability", "evidence_refs"],
        "metric_definitions": ["id", "provider_id", "name", "version", "type", "unit", "counting_unit", "population", "numerator_definition", "denominator_definition", "exclusions", "clock", "evidence_refs"],
        "recommendations": ["id", "provider_id", "title", "problem", "action", "status", "decision_basis", "horizon", "owner_role", "dependencies", "duration_workdays", "effort_person_days", "cost", "estimate_basis", "governance", "accessibility", "evidence_refs"],
    }
    for collection, fields in columns.items():
        files["workpapers/" + collection + ".csv"] = csv_bytes(data[collection], fields)
    files["workpapers/measurements.json"] = json_bytes(data["measurements"])
    roadmap = projection.get("roadmap") or projection["summary"]["roadmap"]
    files["workpapers/accepted-roadmap.json"] = json_bytes(roadmap)
    files["workpapers/later-rfp-briefs.json"] = json_bytes(roadmap["vendor_rfp_briefs"])
    for workflow in data["workflows"]:
        name = safe_name(workflow["id"])
        mapped = engine.workflow_map(workflow)
        files["workpapers/maps/" + name + ".json"] = json_bytes(workflow)
        files["workpapers/maps/" + name + ".mmd"] = (mapped["mermaid"] + "\n").encode()


def export_project(workspace, project_id, audience="private_restore", provider_id=None):
    snapshot = workspace.snapshot(project_id)
    state = snapshot["state"]
    files, sources = {}, []
    if audience == "private_restore":
        schema = PRIVATE_SCHEMA
        files.update({"project.json": json_bytes(state), "history/events.json": json_bytes(snapshot["events"]), "history/requests.json": json_bytes(snapshot["requests"]), "assessment-summary.json": json_bytes(engine.assess(state))})
        included_files = state["files"]
        files["README.txt"] = b"PLAN private continuation archive\n\nThis archive contains the complete operator project, all retained original source files, full source event records, revision chain and saved request outcomes. Import it with the PLAN workbench to continue the same project. It is separate from a recipient report bundle. Generate a provider, restricted PLAN or consolidated report with the corresponding audience selector. Do not distribute this private backup as a consolidated report.\n"
    else:
        schema = RECIPIENT_SCHEMA
        projection = engine.project_export(state, audience, provider_id)
        _recipient_workpapers(files, projection)
        included_evidence = set(projection["included_evidence_ids"])
        evidence = [item for item in state["evidence"] if item["id"] in included_evidence]
        if len(evidence) != len(included_evidence):
            raise ValueError("Recipient projection references missing evidence.")
        file_ids = {item["source_file_id"] for item in evidence if item["source_file_id"]}
        included_files = [item for item in state["files"] if item["id"] in file_ids]
        files["README.txt"] = ("PLAN recipient assessment bundle\n\nAudience: " + audience + "\nOpen report.html. Editable source-bound JSON, CSV and process-map workpapers are included. Original source attachments are selected only from the projection's included_evidence_ids; other project attachments and private revision/request history are omitted.\nThis is a recipient projection, not a project restore archive. The consolidated-use decisions do not substitute for the separate prior written third-party consent specified by RFP section11.\n").encode()
        if audience == "plan_restricted":
            for provider in state["providers"]:
                own = engine.project_export(state, "lsp", provider["id"])
                prefix = "individual-reports/" + safe_name(provider["id"])
                files[prefix + ".html"] = report_html(own)
                files[prefix + ".json"] = json_bytes(own)
    for item in included_files:
        path = "originals/" + item["id"] + "/" + safe_name(item["filename"])
        raw = snapshot["raw"][item["sha256"]]
        if hashlib.sha256(raw).hexdigest() != item["sha256"] or len(raw) != item["bytes"]:
            raise ValueError("The retained original bytes do not match the project source identity.")
        files[path] = raw
        sources.append({"file_id": item["id"], "sha256": item["sha256"], "path": path, "filename": item["filename"], "bytes": item["bytes"]})
    manifest = {"schema": schema, "audience": audience, "project_id": state["id"], "revision": state["revision"], "sources": sources,
                "files": {path: {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)} for path, raw in sorted(files.items())}}
    if audience == "lsp":
        manifest["provider_id"] = provider_id
    files["manifest.json"] = json_bytes(manifest)
    if len(files) > 4096 or sum(len(raw) for raw in files.values()) > MAX_ARCHIVE_BYTES:
        raise ValueError("This report archive exceeds the 192 MiB or 4,096-file limit. Select a provider or a smaller declared source period.")
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, raw in sorted(files.items()):
            archive.writestr(path, raw)
    return output.getvalue(), manifest


def import_project(workspace, raw):
    if not raw or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError("Private archive is empty or exceeds 192 MiB.")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            if len(entries) > 4096 or sum(item.file_size for item in entries) > MAX_ARCHIVE_BYTES or len({item.filename for item in entries}) != len(entries):
                raise ValueError("Private archive expands beyond the supported limit or repeats a path.")
            for item in entries:
                path = PurePosixPath(item.filename)
                if path.is_absolute() or ".." in path.parts or "\\" in item.filename or item.is_dir() or str(path) != item.filename:
                    raise ValueError("Private archive contains an invalid file path.")
            files = {item.filename: archive.read(item) for item in entries}
    except (zipfile.BadZipFile, RuntimeError, OSError) as exc:
        raise ValueError("Unable to read the private project ZIP archive.") from exc
    try:
        manifest = _json(files["manifest.json"])
        if manifest.get("schema") != PRIVATE_SCHEMA or manifest.get("audience") != "private_restore":
            raise ValueError("Only a complete private continuation archive can be restored. Recipient projections intentionally omit project records.")
        if set(manifest["files"]) != set(files) - {"manifest.json"}:
            raise ValueError("Archive files do not exactly match the manifest.")
        for path, identity in manifest["files"].items():
            if len(files[path]) != identity["bytes"] or hashlib.sha256(files[path]).hexdigest() != identity["sha256"]:
                raise ValueError("Archive file hash or byte length differs: " + path)
        state = _json(files["project.json"])
        if state["id"] != manifest["project_id"] or state["revision"] != manifest["revision"]:
            raise ValueError("Project state and archive identity disagree.")
        state_files = {item["id"]: item for item in state["files"]}
        if len(manifest["sources"]) != len(state_files) or {item["file_id"] for item in manifest["sources"]} != set(state_files):
            raise ValueError("Private archive source inventory does not match the complete project.")
        originals = {}
        for source in manifest["sources"]:
            original = state_files[source["file_id"]]
            if any(source[key] != original[key] for key in ("sha256", "filename", "bytes")):
                raise ValueError("Archived original source metadata has a different identity.")
            data = files[source["path"]]
            if source["sha256"] in originals and originals[source["sha256"]] != data:
                raise ValueError("An original byte identity is repeated with different data.")
            originals[source["sha256"]] = data
        return workspace.restore_snapshot({"state": state, "raw": originals, "events": _json(files["history/events.json"]), "requests": _json(files["history/requests.json"])})
    except (KeyError, TypeError, json.JSONDecodeError, IndexError) as exc:
        raise ValueError("Private archive has malformed or missing required project records.") from exc
