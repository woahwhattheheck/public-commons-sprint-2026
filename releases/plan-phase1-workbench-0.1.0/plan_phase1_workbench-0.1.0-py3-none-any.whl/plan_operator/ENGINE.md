# PLAN Phase 1 assessment engine and operating API

This product supports the independent assessment, evidence collection, editable workpapers and implementation planning required by the [September 24, 2026 PLAN RFP](https://www.lsntap.org/sites/default/files/2026-09/plan-statewide-intake-improvement-project-phase-1-assessment-and-planning-rfp-issue-2026-09-24-1.pdf). It keeps the individual provider assessment, PLAN's restricted workpapers and the consulted consolidated report as separate outputs.

The public demonstration imports original published material. Its directory has 14 candidates, comprising eight regional and six specialty entries. The RFP specifies 13 assessment units, comprising seven regional and six specialty LSPs. No candidate is silently removed or designated a contracted participant. The six directory entries with office counts total 48 program offices; that is a different source context from the RFP's 48 walk-in offices. The RFP's 48 walk-in and 22 telephone-host offices occupy a universe of 67 offices, so the two sets overlap by at least three and at most 22. Actual office assignments are collected separately.

## Data and persistence contract

`engine.py` is pure Python standard library code. It does not own credentials, files, databases, messages or model calls. `workspace.py` owns the SQLite transaction, original bytes, revision history and request replay. The project contains the flat engine collections:

`candidates`, `providers`, `offices`, `channels`, `evidence`, `metric_definitions`, `measurements`, `workflows`, `recommendations`, `permissions`, and `network_findings`.

Every record has a stable `id`. LSP records also have `provider_id`; network evidence, network recommendations and PLAN decisions can use null. Common public material uses null provider scope. A local record cannot reference another LSP's evidence identity. Evidence includes original SHA-256, file identity, publisher URL, page/row locator, kind, classification, version, limitations and summary. The original bytes are retained independently of the operator's interpretation.

Call `validate_record(collection, record, state)` and persist its return value. Most records have an explicit schema; arbitrary extra payload fields are not retained. Public candidate records preserve acquired source fields. Confirming or excluding a roster unit requires a source-linked rationale. A directory candidate cannot simultaneously belong to two confirmed assessment units.

```python
state = engine.new_assessment("PLAN Phase 1", acquired_candidates)
provider = engine.validate_record("providers", {
    "id": "local-assessment-1",
    "name": "Name from the supplied engagement roster",
    "candidate_ids": [selected_public_candidate_id],
    "roster_status": "proposed"
}, state)
```

Create the proposed provider before attaching its private evidence. Confirm the roster relationship after the actual source decision is recorded. The public seed creates candidates and collection tasks, not confidential provider baselines.

## Metric definitions and source cohorts

The eight supported types correspond to the RFP's assessment needs. Numeric outputs are decimal strings; counts and index values remain integers. Missing inputs remain null or explicitly unmeasured.

| Type | Required source meaning | Computation |
|---|---|---|
| `channel_volume` | Counting unit, eligible population, period, channel/office assignment | Count of declared units; duplicate identities need resolution |
| `channel_share` | Same-population numerator and denominator | Sum of eligible numerator units divided by denominator; multi-touch overlap remains visible |
| `call_wait` | Queue entry to answer, completed-answer denominator | Mean/median/p90 for completed observations; abandonment, pending and missing retained |
| `call_talk` | Answer to declared end, with call-leg/wrap-up definition | Completed duration statistics; no inferred call-leg deduplication |
| `intake_decision_time` | First contact cohort and eligibility, accepted or rejected decision | Declared elapsed or business-clock duration; decision kinds remain separate |
| `abandonment` | Eligible offered interactions, actual outcome mapping and explicit short-abandon rule | Abandoned/eligible offered as of cutoff; unknown outcomes prevent a final rate |
| `capacity` | One staffing pool and period, observed work and available time in the same unit | Observed utilization; assumption-based demand scenarios separately labeled |
| `local_success` | LSP/PLAN success statement, exact definition, unit and target basis | Source value retained; no imposed network SLA |

Metric definitions include `version`, `counting_unit`, `population`, `numerator_definition`, `denominator_definition`, `exclusions`, `clock`, `cohort_event`, `start_event`, `end_event`, `decision_kind`, `outcome_mapping`, `short_abandon_rule`, and evidence references. A target has `value`, `direction`, `basis` and `status` (`proposed` or `locally_agreed`). Recording a proposed target does not make it an RFP requirement.

A measurement uses `basis: aggregate`, `events` or `reported`. Its period is `{start, end, cutoff, timezone}`. Start is inclusive; end is exclusive. Date-only boundaries require an IANA timezone. Individual event timestamps require explicit offsets, so ambiguous source-local timestamps must be resolved when mapping the source. A cutoff before period end creates an interim cohort. Completion after cutoff is pending even if the later extract already contains the final outcome.

```json
{
  "id": "monthly-channel-share",
  "provider_id": "local-assessment-1",
  "definition_id": "phone-share-definition",
  "basis": "aggregate",
  "period": {
    "start": "2026-10-01", "end": "2026-11-01",
    "cutoff": "2026-11-02T09:00:00-05:00",
    "timezone": "America/New_York"
  },
  "values": {"numerator": null, "denominator": null, "pending_count": null},
  "sample_status": "unknown",
  "evidence_refs": [],
  "aggregation": {"mode": "unknown", "basis": ""}
}
```

The example intentionally contains no invented operational values. Attach and map the actual source before computing it. Normalization binds a measurement to the exact `definition_digest`. A later definition change marks the old measurement `metric_definition_changed`; the prior aggregate is not silently relabeled with a new counting unit, clock or denominator. `measurement.rebind` requires a recorded reconciliation basis.

Event input permits `unit_id`, own `office_id`/`channel_ids`, source row reference, explicit exclusion reason, actual outcome, decision kind, and the documented timestamp fields. A source unit may use multiple channels. This does not establish the identity of a person across providers. Business-clock calculations use explicitly supplied weekday windows, holidays and timezone; they do not inherit another project's callback standard.

`evaluate_measurement(state, record_or_id)` computes one measurement. `assess(state)` provides the operator summary and keeps a problem local to its editable measurement. Missing denominator, contradictory timestamps, repeated units and unmapped outcomes produce actionable states rather than zero-filled results.

`aggregate_measurements(state, ids)` requires matching definition/version, units, clock, exclusions, period and source coverage. Multiple extracts also require a recorded disjoint-population basis. Proportions pool their numerators and denominators; duration means pool totals and completed counts. A source-confirmed zero/zero cohort contributes zero to a larger compatible population; it is not mistaken for a missing source. An all-zero denominator remains undefined. Percentiles and source-reported averages are not averaged. Capacity and local-success metrics do not acquire an aggregation meaning automatically.

### Import original CSV or JSON event records

First use `evidence.add` to attach the actual original file with its provider, classification, publisher/system context and source locator. Then send `measurement.import` with the evidence identity, explicit parser options and field mapping. The imported cohort retains `source_import` metadata and a source-file hash plus original row locator on every event.

```json
{
  "evidence_id": "retained-call-export",
  "format": "csv",
  "options": {"encoding": "utf-8", "delimiter": ","},
  "field_map": {
    "unit_id": "call_id",
    "queue_entered_at": "queue_entered",
    "answered_at": "answer_time",
    "ended_at": "end_time",
    "outcome": "source_disposition"
  },
  "constants": {
    "office_id": "mapped-local-office",
    "channel_ids": ["mapped-local-telephone"]
  },
  "measurement": {
    "id": "local-call-cohort",
    "provider_id": "local-assessment-1",
    "definition_id": "local-call-wait-definition",
    "period": {
      "start": "2026-10-01", "end": "2026-11-01",
      "cutoff": "2026-11-02T09:00:00-05:00",
      "timezone": "America/New_York"
    },
    "sample_status": "unknown"
  }
}
```

Replace the example identities and period with the supplied source context. CSV fields can be selected by exact unique header or zero-based column index; a duplicated heading requires the explicit index. Unequal row widths are reported, not silently padded or truncated. Multiline CSV records retain their data-row index and ending physical line. JSON `options.records_path` selects the record array with a JSON pointer; field selectors beginning with `/` are JSON pointers, and other selectors are exact object keys. No fuzzy matching, inferred timezone, terminal-outcome mapping or automatic person deduplication occurs. The metric definition supplies the actual outcome mapping.

One original file can contain up to 32 MiB; a mapped cohort supports 100,000 records, while a project retains up to 128 MiB of original source bytes and 48 MiB of structured state. Use actual reporting periods or source-defined aggregates for larger operational extracts. These are implementation limits of this local product, not RFP volume assumptions.

## Editable process maps and accepted implementation work

Each workflow belongs to one provider, with explicit office/channel scope. Nodes have `id`, `label`, `kind`, `role`, `evidence_refs`, `accessibility` and notes; edges have `from`, `to`, `label` and evidence references. Supported node kinds are start, action, decision, wait, handoff and end. Return loops are valid process behavior. `workflow_map(record)` returns the editable graph, a Mermaid representation and diagnostics for missing starts/ends, unreachable steps and unfinished paths. A draft map is not an observed or reviewed workflow.

Recommendations connect a source-specific problem to action, horizon, priority, operating owner, prerequisites, dependencies, accessibility, governance, deliverables and acceptance criteria. Cost, elapsed workdays and person-days retain their separate meanings and stated estimation basis. No fixed statewide technology architecture is selected by the engine.

`record_recommendation_decision(state, id, decision, actor, basis, at)` returns the normalized decision bound to the current recommendation and evidence digest. `recommendation_roadmap(state)` includes currently accepted work, surfaces stale acceptance and cycles, and derives relative timing from elapsed duration estimates. It does not sum person-effort as elapsed time. Later RFP briefs are generated only for recommendations marked as requiring that later scope.

`recommendation_roadmap(state, provider_id)` first computes the full dependency graph, then projects the provider's own work. A network prerequisite's identifiers and workpapers are omitted, while `network_prerequisite_count`, readiness and timing effects remain. Filtering dependencies before scheduling would incorrectly make some local work appear immediately ready; this implementation preserves their actual effect.

## Consolidated uses and recipient projections

RFP §11 gives PLAN and the applicable LSP access to individual reports and underlying workpapers. PLAN consults the relevant LSP before deciding whether and how its findings are used in the consolidated report. Third-party distribution requires separate prior written PLAN and applicable LSP consent. An app operator entry records the supplied decision; it is not itself that external consent.

A network finding identifies the proposed exact `title`, `body`, affected providers, measurements, recommendations and source evidence. Use `finding_digest(state, id)` to obtain the exact-content target. The digest includes referenced measurements, metric definitions, recommendation content and current evidence versions. Attributed output also binds displayed provider names. Newly affected providers are derived from the current dependencies.

Each current `permissions` record binds `finding_id`, `authority: plan|lsp`, applicable `provider_id`, `target_digest`, disposition, actual decision maker, basis and consultation evidence. PLAN records `decision: approved`; the LSP record uses `decision: consulted`, with its actual `position` (`supports`, `objects`, `mixed` or `not_stated`). **PLAN determines internal consolidated use in consultation with the LSP. An LSP's recorded disagreement is retained and does not create an additional approval requirement or veto.** Normalization also binds the precise evidence versions. PLAN's record additionally retains `consultation_versions`, the actual affected-LSP consultation records considered in that decision. Editing the finding, a metric, its definition, an evidence record or the consultation record reopens that specific use. An unrelated finding keeps its own current decision. This is a content-specific report workflow rather than a blanket project restriction.

For an explicit new **Record PLAN use decision** action, supply the current `target_digest` and omit `consultation_versions` so normalization captures the current consulted records. Preserve that field in ordinary stored records and private archives. PLAN approval recorded before the consultation cannot silently apply to consultation added afterward; it requires PLAN's updated decision on the current consultation. The same principle applies when an LSP changes its position or notes. The LSP's current objection remains a consulted position, not a veto.

`project_export(state, audience, provider_id=None)` returns an audience-specific projection:

| Audience | Content |
|---|---|
| `plan_restricted` | Complete individual assessment state and PLAN workpapers |
| `lsp` | One provider's report, records, evidence and projected roadmap; no other LSP's source identifiers or records |
| `consolidated` | Only findings with a current PLAN decision and recorded affected-LSP consultation, approved attributed or pooled metrics, and relevant public evidence |

**The exporter must select original files only through `included_evidence_ids`.** It must never append all project attachments to a recipient bundle. The private continuation ZIP is a separate archive type; recipient projections are not restorable project backups. Their omitted dependencies or private records must not be treated as deleted source work.

## HTTP interface

The local server exposes `GET/POST /api/projects`, project retrieval, record editing, paginated source events, history, recipient projection, recipient export and private restore. All mutations use:

```json
{
  "operation": "record.save",
  "payload": {"collection": "providers", "record": {}},
  "expected_revision": 1,
  "request_id": "one-stable-id-for-this-exact-save",
  "actor": "Actual operator"
}
```

Send this envelope to `POST /api/projects/:id/operations`. A revision conflict returns HTTP 409 and the current revision without saving a partial change. Replaying an identical request returns its original result; changing its input requires a new request ID. Source bytes, record change, project revision, event and request result commit in one transaction.

| Route | Result |
|---|---|
| `GET /api/catalog` | Record templates, eight metric types, source requirements, channel and decision enums, authored process-map template |
| `GET /api/projects` | Existing projects and current revisions |
| `POST /api/projects` | New project from `{name, actor}` |
| `GET /api/projects/:id` | Flat engine collections, file inventory, `computed` summary and collection counts; at most 200 records per collection and 10 event preview rows per measurement |
| `GET /api/projects/:id/records/:collection` | `{collection, revision, offset, total, rows}` with up to 200 rows per page |
| `GET /api/projects/:id/records/:collection/:record_id` | Complete editable record |
| `GET /api/projects/:id/events?measurement_id=...` | `{measurement_id, revision, offset, total, rows, source_import}` with up to 500 original mapped events per page |
| `POST /api/projects/:id/operations` | Atomic revisioned mutation using the envelope above |
| `GET /api/projects/:id/history` | Paginated revision/event history, up to 500 rows per page |
| `GET /api/projects/:id/files/:file_id` | Download an original file attached to this operator project |
| `GET /api/projects/:id/projection?audience=...` | Exact recipient JSON projection; `provider_id` is required for an LSP |
| `GET /api/projects/:id/report?audience=...` | Printable standalone HTML report |
| `GET /api/projects/:id/export?audience=...` | Private continuation or explicitly selected recipient ZIP |
| `POST /api/restore` | Restore a complete private ZIP supplied as `{content_base64}` |
| `POST /api/demo` | Repeatable source-only seed; no duplicate project or operational observations |

The operating mutations are `record.save`, `record.delete`, `evidence.add`, `measurement.import`, `measurement.rebind`, `recommendation.decide`, `project.rename`, and `scope.save`. `scope.save` requires the actual source-addendum/decision basis and evidence references; it preserves an explicit source-scope schema. Fetch the complete measurement record before editing it. A preview marked with `event_preview_limit` is rejected as a replacement for the full cohort.

Private archives retain the full state, original bytes, event chain and saved request outcomes. Each event binds the resulting state identity; saved request IDs and request-input digests bind to their specific events. Restoring an identical archive is idempotent; an existing divergent project ID is preserved. The importer checks archive structure, byte hashes, schema, entity/source bindings, final state identity and saved request/event correspondence before committing. Recipient archives are never accepted as restore archives.

The server binds only to 127.0.0.1 and accepts its displayed local host/origin. This is a local operator product; recipient sharing happens through explicit report bundles. Start it from the opportunity directory with `python operator/server.py --workspace /path/to/workspace --demo`. The CLI also supports `--restore FILE`, or `--export PROJECT_ID --audience lsp --provider-id ID --output FILE`.

## Native verification performed

One focused domain journey loaded the acquired public roster and checked its 14/13 distinction, observed office-count contexts and overlap bounds. Separately labeled authored fixtures exercised weighted 10/12 channel aggregation, provider-only projection, a three-workday network prerequisite followed by five local workdays, exact-content source/consultation changes, and a call outcome after cutoff. They produced the intended 83.333…% weighted share, retained local start/finish offsets of 3/8 workdays without network identifiers, and one pending call instead of premature abandonment. These fixtures are development inputs, not PLAN operational observations.

The original public seed leaves provider measurements and private operational records empty. The RFP's Appendix A says anonymized profiles are available on request; it does not contain those profiles. Actual assessment data can be attached and evaluated through the same native operating path when supplied.

The actual public-source project imported seven retained publication/derived files, 14 candidates, 68 provider–county links / 67 distinct published spellings and six authored collection workstreams at revision 14. Same-seed replay and full private export→fresh restore preserved that state. A separate authored native HTTP journey exercised original CSV import, source pagination, idempotent replay, stale-write HTTP 409, definition reconciliation, consulted disagreement without a veto, source-scoped recipient ZIPs and continued editing after restore. No authored operational fixtures are included in the public demo seed.
