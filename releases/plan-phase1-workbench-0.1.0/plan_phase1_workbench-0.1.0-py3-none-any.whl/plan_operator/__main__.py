"""Run the installed workbench with python -m plan_operator."""
from .server import main

if __name__ == "__main__":
    main()

