#!/usr/bin/env bash
set -euo pipefail
MPP_PACKET_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
MPP_RECEIVING_CACHE=${1:?Supply a new or original owned absolute cache directory}
MPP_ORIGINAL_DONOR=${2:?Supply the existing read-only Git repository}
MPP_RECEIVING_SOURCE=${3:?Supply a new absolute materialized source directory}
python3 "$MPP_PACKET_ROOT/git-object-receiving.py" --metadata "$MPP_PACKET_ROOT/9ef475-metadata.json.gz" --commit 9ef475062876557d6baf14e0e5414d7afbf3bc7f --directory "$MPP_RECEIVING_CACHE" --donor-repository "$MPP_ORIGINAL_DONOR" --incoming "$MPP_PACKET_ROOT/incoming" --additional-path operations/scf-mpp-merchant-mcp-native-20261012/run.sh --materialize "$MPP_RECEIVING_SOURCE"
