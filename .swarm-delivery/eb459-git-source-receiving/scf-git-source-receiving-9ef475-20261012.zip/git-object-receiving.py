#!/usr/bin/env python3
"""Receive an exact Git source cache from captured GitData and existing sources.
MIT. The maintained builder remains the package/profile/runtime authority.
"""
from __future__ import annotations
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import threading
import uuid
import zlib

SCHEMA = "stellar-forge.git-object-receiving.v1"
STATE_SCHEMA = "stellar-forge.git-object-cache.v1"
OID = re.compile(r"^[a-f0-9]{40}$")
FILE_LIMIT = 2 * 1024 * 1024
SOURCE_LIMIT = 64 * 1024 * 1024
METADATA_LIMIT = 8 * 1024 * 1024

class SourceError(Exception):
    pass

def need(value, message):
    if not value:
        raise SourceError(message)

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def object_id(kind, data):
    return hashlib.sha1(f"{kind} {len(data)}\0".encode("ascii") + data).hexdigest()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")

def regular(path, maximum=FILE_LIMIT):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, "Expected a bounded regular source file")
        with os.fdopen(fd, "rb", closefd=False) as handle:
            data = handle.read(maximum + 1)
        after = os.fstat(fd)
        need(len(data) == before.st_size and (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
             (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "Source file changed during reading")
        return data
    finally:
        os.close(fd)

def absolute_directory(value, exists=True):
    path = Path(value)
    need(path.is_absolute() and str(path) == str(path.absolute()), "Use an absolute source/cache directory")
    need(path.resolve(strict=exists) == path, "Source/cache directories must retain their canonical path")
    if exists:
        need(stat.S_ISDIR(path.lstat().st_mode), "Expected an existing source/cache directory")
    return path

def json_file(path, maximum=METADATA_LIMIT):
    data = regular(path, maximum)
    if data.startswith(b"\x1f\x8b"):
        decoder = zlib.decompressobj(31)
        data = decoder.decompress(data, maximum + 1)
        need(len(data) <= maximum and decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail,
             "Compressed source metadata exceeds its original bounded size")
    return json.loads(data)

def atomic_json(path, value):
    data = canonical(value)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".receiving-tmp")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        os.close(fd)
    os.replace(temporary, path)

def validate_metadata(value):
    need(isinstance(value, dict) and value.get("schema") == SCHEMA, "Unsupported Git source receiving schema")
    source = value.get("source")
    tree = value.get("tree")
    commit_text = value.get("commitText")
    need(isinstance(source, dict) and OID.fullmatch(source.get("commit", "")) and
         OID.fullmatch(source.get("tree", "")), "Exact original commit and root tree IDs are required")
    need(isinstance(tree, dict) and tree.get("sha") == source["tree"] and tree.get("truncated") is False and
         isinstance(tree.get("tree"), list), "The complete original recursive tree is required")
    need(isinstance(commit_text, str), "Original commit bytes are required as UTF-8 commitText")
    commit = commit_text.encode("utf-8")
    need(object_id("commit", commit) == source["commit"], "Original Git commit object hash does not match")
    need(commit_text.split("\n", 1)[0] == "tree " + source["tree"], "Commit and recursive root tree differ")
    entries = {}
    groups = {"": []}
    expected_trees = {"": source["tree"]}
    for row in tree["tree"]:
        need(isinstance(row, dict), "Invalid recursive tree row")
        path, mode, kind, oid = (row.get(k) for k in ("path", "mode", "type", "sha"))
        need(isinstance(path, str) and path and "\0" not in path and not path.startswith("/") and
             all(part not in ("", ".", "..") for part in path.split("/")), "Invalid original Git path")
        need(path not in entries and OID.fullmatch(oid or ""), "Duplicate path or invalid original object ID")
        need((kind, mode) in (("tree", "040000"), ("blob", "100644"), ("blob", "100755"),
                              ("blob", "120000"), ("commit", "160000")), "Unsupported original Git tree mode/type")
        entries[path] = row
        parent, _, name = path.rpartition("/")
        groups.setdefault(parent, []).append((name, row))
        if kind == "tree":
            expected_trees[path] = oid
            groups.setdefault(path, [])
    need(set(groups) == set(expected_trees), "Recursive tree omits an intermediate tree")
    objects = []
    for path, rows in groups.items():
        rows.sort(key=lambda item: (item[0] + ("/" if item[1]["type"] == "tree" else "")).encode("utf-8"))
        body = b"".join(
            (row["mode"].lstrip("0") + " " + name).encode("utf-8") + b"\0" + bytes.fromhex(row["sha"])
            for name, row in rows
        )
        need(object_id("tree", body) == expected_trees[path], "Original Git tree object hash does not match: " + path)
        objects.append((expected_trees[path], "tree", body))
    required = value.get("requiredPaths")
    need(isinstance(required, list) and required and len(required) == len(set(required)),
         "Original required source paths must be a nonempty unique list")
    selected = []
    for path in required:
        row = entries.get(path)
        need(row and row["type"] == "blob" and row["mode"] in ("100644", "100755"),
             "Only an original regular source path can be received: " + str(path))
        need(isinstance(row.get("size"), int) and 0 <= row["size"] <= FILE_LIMIT, "Source file exceeds its original limit")
        selected.append(row)
    need(sum(row["size"] for row in selected) <= SOURCE_LIMIT, "Required source exceeds the maintained 64 MiB budget")
    objects.append((source["commit"], "commit", commit))
    return source, entries, selected, objects

def git_command(git, repository, args, **options):
    environment = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    return subprocess.run(
        [git, "--no-replace-objects", "--no-lazy-fetch", "-C", str(repository), *args],
        shell=False, env=environment, **options
    )

class ObjectCache:
    def __init__(self, repository):
        self.repository = repository
        self.written = 0
        self.raw_bytes = 0

    def path(self, oid):
        need(OID.fullmatch(oid) is not None, "Invalid Git object ID")
        return self.repository / "objects" / oid[:2] / oid[2:]

    def read(self, oid, expected_kind=None):
        path = self.path(oid)
        if not path.exists():
            return None
        compressed = regular(path, FILE_LIMIT + 1024 * 1024)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(compressed, FILE_LIMIT + 1024 * 1024)
        need(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail, "Git object exceeds its bounded original size")
        head, body = raw.split(b"\0", 1)
        kind, size = head.decode("ascii").split(" ")
        need(size == str(len(body)) and object_id(kind, body) == oid, "Cached original Git object changed")
        need(expected_kind is None or kind == expected_kind, "Cached Git object has the wrong type")
        return body

    def write(self, oid, kind, body):
        need(object_id(kind, body) == oid, "Received bytes do not match the original Git object")
        path = self.path(oid)
        path.parent.mkdir(mode=0o700, exist_ok=True)
        if path.exists():
            need(self.read(oid, kind) == body, "Existing immutable Git object differs")
            return False
        raw = f"{kind} {len(body)}\0".encode("ascii") + body
        compressed = zlib.compress(raw)
        temporary = path.parent / ("tmp_obj_" + uuid.uuid4().hex + ".receiving")
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, "wb", closefd=False) as handle:
                handle.write(compressed)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary, path, follow_symlinks=False)
            except FileExistsError:
                need(self.read(oid, kind) == body, "Concurrent immutable Git object differs")
                return False
        finally:
            os.close(fd)
            temporary.unlink(missing_ok=True)
        self.written += 1
        self.raw_bytes += len(body)
        return True

def receive_git_donor(git, donor, cache, missing):
    """Read batches from an existing object database; never fetch or alter it."""
    ids = list(missing)
    if not ids:
        return 0
    inspected = git_command(git, donor, ["cat-file", "--batch-check"],
                            input=("\n".join(ids) + "\n").encode("ascii"),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    need(inspected.returncode == 0, "Existing Git donor metadata read failed (exit " + str(inspected.returncode) + ")")
    lines = inspected.stdout.decode("ascii").splitlines()
    need(len(lines) == len(ids), "Incomplete original Git donor metadata batch")
    available = []
    for oid, line in zip(ids, lines):
        fields = line.split(" ")
        need(fields[0] == oid, "Original Git donor metadata order changed")
        if fields[1:] == ["missing"]:
            continue
        need(len(fields) == 3 and fields[1] == "blob" and int(fields[2]) == missing[oid]["size"],
             "Original Git donor object metadata differs")
        available.append(oid)
    if not available:
        return 0
    environment = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    process = subprocess.Popen(
        [git, "--no-replace-objects", "--no-lazy-fetch", "-C", str(donor), "cat-file", "--batch"],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=environment, shell=False
    )
    send_error = []
    def send():
        try:
            process.stdin.write(("\n".join(available) + "\n").encode("ascii"))
            process.stdin.close()
        except BaseException as error:
            send_error.append(type(error).__name__)
    sender = threading.Thread(target=send, daemon=True)
    sender.start()
    received = 0
    try:
        for oid in available:
            header = process.stdout.readline(160).decode("ascii").rstrip("\n").split(" ")
            need(len(header) == 3 and header[0] == oid and header[1] == "blob" and
                 int(header[2]) == missing[oid]["size"], "Original donor content header changed")
            size = int(header[2])
            body = process.stdout.read(size)
            need(len(body) == size and process.stdout.read(1) == b"\n", "Original donor content was truncated")
            cache.write(oid, "blob", body)
            del missing[oid]
            received += 1
        need(process.stdout.read(1) == b"", "Unexpected extra original donor content")
        sender.join(timeout=10)
        need(not sender.is_alive() and not send_error and process.wait(timeout=10) == 0, "Original donor batch did not finish")
        return received
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
        process.stdout.close()
        if not process.stdin.closed:
            process.stdin.close()

def receive_files(directory, selected, cache, missing, flat=False):
    received = 0
    for row in selected:
        oid = row["sha"]
        if oid not in missing:
            continue
        path = directory / (oid + ".blob") if flat else directory / row["path"]
        compressed_path = directory / (oid + ".blob.gz") if flat else None
        try:
            if compressed_path is not None and compressed_path.exists():
                packed = regular(compressed_path, FILE_LIMIT + 65536)
                decoder = zlib.decompressobj(31)
                data = decoder.decompress(packed, FILE_LIMIT + 1)
                need(len(data) <= FILE_LIMIT and decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail,
                     "Received compressed blob exceeds its original source limit")
            else:
                data = regular(path)
        except FileNotFoundError:
            continue
        except OSError as error:
            if error.errno == 40:  # O_NOFOLLOW rejects source aliases.
                continue
            raise
        if len(data) != row["size"] or object_id("blob", data) != oid:
            continue
        cache.write(oid, "blob", data)
        del missing[oid]
        received += 1
    return received

def materialize(directory, selected, cache):
    directory = absolute_directory(directory, exists=False)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    materialized = 0
    for row in selected:
        data = cache.read(row["sha"], "blob")
        need(data is not None, "Receive the complete requested closure before materializing it")
        path = directory / row["path"]
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        need(path.parent.resolve() == path.parent, "Materialized source directory was redirected")
        if path.exists():
            need(regular(path) == data, "Existing source postimage differs: " + row["path"])
            continue
        temporary = path.with_name(".receiving-" + uuid.uuid4().hex)
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o755 if row["mode"] == "100755" else 0o644)
        try:
            with os.fdopen(fd, "wb", closefd=False) as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary, path, follow_symlinks=False)
            except FileExistsError:
                need(regular(path) == data, "Concurrent original source postimage differs")
        finally:
            os.close(fd)
            temporary.unlink(missing_ok=True)
        materialized += 1
    return materialized

def receive(args):
    metadata = json_file(Path(args.metadata))
    source, entries, selected, objects = validate_metadata(metadata)
    need(args.commit == source["commit"], "The explicit selected commit differs from the captured source")
    metadata_hash = hashlib.sha256(canonical(metadata)).hexdigest()
    directory = absolute_directory(args.directory, exists=False)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    lock = os.open(directory / "source-receiving.lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state_file = directory / "source-receiving.json"
        previous = json_file(state_file) if state_file.exists() else None
        if previous:
            need(previous.get("schema") == STATE_SCHEMA and previous.get("directory") == str(directory) and
                 previous.get("source") == source and previous.get("metadataSha256") == metadata_hash,
                 "Resume the original cache with its exact original source metadata")
        else:
            need(not any(p.name != "source-receiving.lock" for p in directory.iterdir()),
                 "Create an owned cache directory or resume its original receiving record")
            previous = {"schema": STATE_SCHEMA, "directory": str(directory), "source": source,
                        "metadataSha256": metadata_hash, "createdAt": now(), "phase": "RECEIVING"}
            atomic_json(state_file, previous)
        repository = directory / "repository.git"
        if not repository.exists():
            started = subprocess.run([args.git, "init", "--bare", "--quiet", str(repository)],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False, timeout=30)
            need(started.returncode == 0, "Could not initialize the owned Git object cache")
        additional = list(dict.fromkeys([*(previous.get("additionalPaths") or []), *args.additional_path]))
        selected_paths = {row["path"] for row in selected}
        for path in additional:
            row = entries.get(path)
            need(row and row["type"] == "blob" and row["mode"] in ("100644", "100755") and
                 isinstance(row.get("size"), int) and 0 <= row["size"] <= FILE_LIMIT,
                 "Additional closure path must be an original regular source file")
            if path not in selected_paths:
                selected.append(row)
                selected_paths.add(path)
        need(sum(row["size"] for row in selected) <= SOURCE_LIMIT, "Expanded source exceeds the maintained 64 MiB budget")
        cache = ObjectCache(repository)
        # Interrupted writes leave only our unreferenced temporary objects.
        for temporary in (repository / "objects").glob("??/tmp_obj_*.receiving"):
            need(stat.S_ISREG(temporary.lstat().st_mode), "Interrupted source temporary changed type")
            temporary.unlink()
        for oid, kind, body in objects:
            cache.write(oid, kind, body)
        # This is a shallow object cache for one immutable commit, with full tree
        # metadata and the requested native source blobs. Its parents remain exact.
        (repository / "shallow").write_text(source["commit"] + "\n", encoding="ascii")
        updated = git_command(args.git, repository, ["update-ref", "refs/heads/source", source["commit"]],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        need(updated.returncode == 0, "The owned Git cache requires Git with --no-lazy-fetch support")
        missing = {}
        for row in selected:
            if cache.read(row["sha"], "blob") is None:
                missing[row["sha"]] = {"sha": row["sha"], "size": row["size"], "paths": []}
        for row in selected:
            if row["sha"] in missing:
                missing[row["sha"]]["paths"].append(row["path"])
        donors = []
        for name in args.donor_repository:
            donor = absolute_directory(name)
            count = receive_git_donor(args.git, donor, cache, missing)
            donors.append({"kind": "original-git", "directory": str(donor), "objects": count})
        for name in args.donor_source:
            donor = absolute_directory(name)
            count = receive_files(donor, selected, cache, missing)
            donors.append({"kind": "original-source", "directory": str(donor), "objects": count})
        for name in args.incoming:
            donor = absolute_directory(name)
            count = receive_files(donor, selected, cache, missing, flat=True)
            donors.append({"kind": "received-blobs", "directory": str(donor), "objects": count})
        listed = git_command(args.git, repository, ["ls-tree", "-r", "-z", "--full-tree", source["commit"]],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        need(listed.returncode == 0, "Original Git could not enumerate the recovered source tree")
        actual = {}
        for line in listed.stdout.split(b"\0"):
            if not line:
                continue
            fields, path = line.split(b"\t", 1)
            mode, kind, oid = fields.decode("ascii").split(" ")
            actual[path.decode("utf-8")] = (mode, kind, oid)
        expected = {path: (row["mode"], row["type"], row["sha"])
                    for path, row in entries.items() if row["type"] != "tree"}
        need(actual == expected, "Git enumerated a different source tree")
        result = {**previous, "phase": "SOURCE_NEEDED" if missing else "OBJECTS_AVAILABLE",
                  "updatedAt": now(), "repository": str(repository), "gitTreeEntries": len(actual),
                  "verifiedTreeObjects": sum(kind == "tree" for _, kind, _ in objects),
                  "requiredPaths": len(selected), "requiredBytes": sum(row["size"] for row in selected),
                  "additionalPaths": additional,
                  "writtenObjects": cache.written, "writtenRawBytes": cache.raw_bytes, "donors": donors,
                  "missingObjects": len(missing), "missingBytes": sum(row["size"] for row in missing.values())}
        atomic_json(directory / "missing-objects.json", {"source": source, "objects": list(missing.values())})
        if args.materialize and not missing:
            result["materializedFiles"] = materialize(args.materialize, selected, cache)
            result["sourceDirectory"] = str(Path(args.materialize))
        atomic_json(state_file, result)
        print(json.dumps(result, separators=(",", ":")))
        return 2 if missing else 0
    finally:
        os.close(lock)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata", required=True, help="Complete captured GitData tree and exact commitText")
    parser.add_argument("--commit", required=True, help="Explicit immutable original Git commit")
    parser.add_argument("--directory", required=True, help="New or original owned source-cache directory")
    parser.add_argument("--git", default="git", help="Existing Git executable with --no-lazy-fetch support")
    parser.add_argument("--donor-repository", action="append", default=[], help="Existing Git database, read only")
    parser.add_argument("--donor-source", action="append", default=[], help="Existing native source root, read only")
    parser.add_argument("--incoming", action="append", default=[], help="Exact received blobs named OID.blob or OID.blob.gz")
    parser.add_argument("--materialize", help="New native source directory for the complete requested closure")
    parser.add_argument("--additional-path", action="append", default=[], help="Exact source path subsequently requested by the maintained builder")
    args = parser.parse_args()
    try:
        return receive(args)
    except (SourceError, OSError, ValueError, zlib.error, subprocess.SubprocessError) as error:
        print(json.dumps({"phase": "ERROR", "code": type(error).__name__, "message": str(error)[:1200]}),
              file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
