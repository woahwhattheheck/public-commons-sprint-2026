# Laboratory EDD receiving

Open report.html to review the complete original records, native profile observations, source lineage and explicit field decisions.
The report is a self-contained local editor. It reopens the original decision JSON, records keep/set/clear actions with reasons, and downloads a complete source-bound decision document.
Run that document with the same source file through the existing Request application or the supplied command. The original job runtime owns saved requests, sealed files, checkout, execution and result receiving.

## Native receiving files

prepared/receiving-files.zip contains every resulting native member under its original or profile-defined filename.
For a workbook profile, use its prepared native workbook. The selected DTS format emits an actual XLSX workbook.
Original inputs remain under original/. manifest.json binds their original names, hashes, selected source profile and result members.
The source/ description and rows retain every original field, worksheet representation and native identifier.
review.json records the computed before/after profile observations and every field decision. issues.csv and lineage.json retain the complete native report.
The editable CSV and TSV tables include a source-binding row. Keep their identity, before-value and reason fields when editing.

## Continue the same original source review

Use the installed Request application to select this same function and original source. Add the downloaded decision JSON or table in the decisions slot.
From a source-pinned installation:

    starforge lab-edd receive --source /absolute/original-source --profile equis-lab-4 --review mccampbell-cross-profile-source-receiving-01 --decisions /absolute/lab-edd-decisions.json --out /absolute/new-result.zip

Use a new result output path for a changed request; the original job entry retains its own execution and same-job recovery identity.

## Receiving scope

Each profile states its actual format and native field checks. The receiving organization supplies its selected format version, current reference values, and final native import result.
The application preserves source laboratory qualifiers, detection limits, reported blank results and units. It records explicit edits in a separate source-bound document.
Reissue comparison uses the selected profile’s complete identity. Every ambiguous duplicate remains available for review.

## Cross-profile receiving

Open reconciliation.html for the entire baseline/current comparison, exact source-key context, many-candidate groups and explicit correspondence decisions.
baseline/report.html opens the complete earlier source with its own field editor. Both original families, both field-decision documents and both native receiving archives are retained.
Pass the saved correspondence file in the reconciliation slot, baseline field decisions in baseline_decisions, and current field decisions in decisions. Select the exact baselineProfile and the same original files.
Candidate grouping uses uniquely resolved original laboratory sample IDs where available. Native method, fraction, test type, qualifiers, limits and units remain visible. Correspondence itself changes no native field.

Job: mccampbell-cross-profile-source-computation-20261012
Original source: 7ce006eade0db042557c7d69182feab9da294a9f49d1c318f852771e6d0e9015
Profile: equis-lab-4 / 1.0.0
Decision: f173da3e4fd12362f071e49e45e3eea254b318aacdac31820ad8e6994a970e91
Computed review: 0ce18086a5681aefd13e8f5aea4709f3456bc2719f2115b23ba61749418c26fd
Native preparation: PREPARED
