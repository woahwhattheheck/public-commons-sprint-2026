# Complete original laboratory receiving model

This packet contains both exact original published McCampbell ZIPs, every prepared native member, complete source/profile/preview records, source-bound JSON decisions and full editable CSV/TSV tables.

The same unchanged source model was run natively with Node 24 on every original row. The original source members were then decoded from the retained ZIP bytes with all CRC/SHA256 values matched; the unchanged model/profile/table modules reproduced both complete native source/preview identities and all four native table byte hashes. The full data in this packet therefore binds to that exact source edition and native result.

The original full native command result hash is retained in model-result.json. Each preview retains every original field and row, complete profile report, lineage and explicit Keep decision. The observations on the published examples remain receiving review items. Preserve all original versions, qualifiers, reported limits and scientific values when selecting a client receiving disposition.

Run the maintained lab-edd/receiving.mjs with the bundled original source configuration to continue the original sealed-file worker and browser receiving. The original compiler, file store and worker provide that operation.
