# Original public metadata source example

This source-only example contains the original OpenAlex query/edition/coverage and two exact response/request/page sets, their native manifest, mapped Dublin Core prepared metadata, one original HTTP OAI record, and a factual receiving summary. The original title query returned169 records on2026-10-11. Source metadata is CC0: https://help.openalex.org/data/how-its-built/ . The primary-location resource license remains a separate source field.

Run the adjacent oai_feed.py prepare with --source this.zip --prefix source-export --out prepared.json. The native manifest is preserved exactly; the adapter consumes its required source-member subset. Original raw source members are unchanged.
