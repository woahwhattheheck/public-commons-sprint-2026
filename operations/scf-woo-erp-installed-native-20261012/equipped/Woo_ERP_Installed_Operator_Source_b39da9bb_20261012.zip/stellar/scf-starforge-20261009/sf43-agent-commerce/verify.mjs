// MIT — SF-43. Independently inspect a real Stellar x402 receipt on its approved network.
// Read-only RPC calls; neither this module nor its caller may infer a paid sale
// from HTTP status 200 or a seller-generated PAYMENT-RESPONSE header alone.
import {createRequire} from 'node:module';
import {NETWORKS, LOCAL_RPC, networkProfile, resolveRpcEndpoint} from '../sf86-rpc-transfer-reconcile/terms.mjs';
/** Select the approved network's public observation provider. An operator's
 * private signer RPC keeps that network's default public observation path. */
export function selectStellarEvidenceEndpoint(network, preferred) {
  const profile=networkProfile(network);
  let preferredUrl;
  try { preferredUrl=new URL(preferred).href; } catch {}
  if (preferredUrl && Object.entries(NETWORKS).some(([key,value]) => key !== network &&
      value.rpcEndpoints.some(endpoint => new URL(endpoint).href === preferredUrl)))
    return resolveRpcEndpoint(network,preferred); // Refuse an explicitly wrong network.
  try { return resolveRpcEndpoint(network,preferred); }
  catch { return profile.defaultRpc; }
}
/** Existing testnet selection API retains its original default behavior. */
export function selectTestnetEvidenceEndpoint(preferred) {
  try { return resolveRpcEndpoint('stellar:testnet',preferred); }
  catch { return NETWORKS['stellar:testnet'].defaultRpc; }
}
const HASH = /^[0-9a-f]{64}$/;
const AMOUNT = /^[1-9][0-9]*$/;
// Soroban contract token amounts are signed i128, not arbitrary-precision
// positive integers. Keep comparisons in BigInt; never coerce to Number.
const SOROBAN_I128_MAX = 170141183460469231731687303715884105727n;
const sorobanAmount = value => typeof value === 'string' &&
  AMOUNT.test(value) && value.length <= 39 && BigInt(value) <= SOROBAN_I128_MAX;
const PAYER = /^[GC][A-Z2-7]{55}$/;
const BASE64 = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
const plain = x => x !== null && typeof x === 'object' && !Array.isArray(x);
const failure = (code, more = {}) => ({ status: 'NOT_VERIFIED', reason: code, ...more });

export function decodeX402Header(raw, name='PAYMENT-RESPONSE') {
  if (typeof raw !== 'string' || !raw || raw.length > 32768 || !BASE64.test(raw) || raw.length % 4)
    throw new TypeError(`${name}: invalid base64`);
  const decoded = Buffer.from(raw,'base64');
  if (decoded.toString('base64') !== raw) throw new TypeError(`${name}: noncanonical base64`);
  const value = JSON.parse(decoded.toString('utf8'));
  if (!plain(value)) throw new TypeError(`${name}: expected JSON object`);
  return value;
}

export function parseExactTestnetTerms(challenge, maxAtomic) {
  if (!plain(challenge) || challenge.x402Version !== 2 || !Array.isArray(challenge.accepts))
    throw new TypeError('PaymentRequired x402Version 2 required');
  // Bound operator policy text before regex and BigInt, preserving original
  // 39-digit policy ceilings even when higher than the Soroban i128 maximum.
  const maxText = typeof maxAtomic === 'string' ? maxAtomic :
    (typeof maxAtomic === 'number' && Number.isSafeInteger(maxAtomic) && maxAtomic > 0) ?
      String(maxAtomic) :
    (typeof maxAtomic === 'bigint' && maxAtomic > 0n && maxAtomic < 10n**39n) ?
      maxAtomic.toString() : '';
  if (maxText.length > 39 || !AMOUNT.test(maxText) || challenge.accepts.length !== 1)
    throw new TypeError('Explicit positive maximum and unambiguous one-offer quote required');
  const term = challenge.accepts[0];
  if (!plain(term) || term.scheme !== 'exact' || term.network !== 'stellar:testnet' ||
      typeof term.asset !== 'string' || !/^C[A-Z2-7]{55}$/.test(term.asset) ||
      typeof term.payTo !== 'string' || !/^G[A-Z2-7]{55}$/.test(term.payTo) ||
      !sorobanAmount(term.amount))
    throw new TypeError('Unexpected Stellar testnet scheme, recipient, asset contract or atomic amount');
  if (BigInt(term.amount) > BigInt(maxText)) throw new RangeError('Quoted atomic amount exceeds approved maximum');
  return structuredClone(term);
}

async function callRpc(method, params, fetchImpl, endpoint) {
  const response = await fetchImpl(endpoint, {
    method:'POST', headers:{'content-type':'application/json'}, redirect:'error',
    body:JSON.stringify({jsonrpc:'2.0',id:'sf43-'+method,method,params}),
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) throw new Error('STELLAR_RPC_HTTP_'+response.status);
  const body = await response.json();
  if (!plain(body) || body.error || !plain(body.result)) throw new Error('STELLAR_RPC_INVALID_'+method);
  return body.result;
}

/**
 * The actual RPC getTransaction is authoritative for tx inclusion/finality, NOT
 * a proof of a specific SEP-41 transfer amount. Token transfer proof is separately
 * derived from actual RPC contract events decoded with Stellar SDK.
 */
export async function checkStellarTransaction({ receipt, expected, fetchImpl = fetch,
  rpcEndpoint, decodeContractEvent, maxEventPages = 12 } = {}) {
  if (!plain(receipt) || !plain(expected) || !Object.hasOwn(NETWORKS, expected.network) ||
      receipt.network !== expected.network || receipt.success !== true ||
      typeof receipt.transaction !== 'string' || !HASH.test(receipt.transaction))
    return failure('RECEIPT_NETWORK_SUCCESS_OR_HASH_INVALID');
  if (typeof expected.asset !== 'string' || !/^C[A-Z2-7]{55}$/.test(expected.asset) ||
      typeof expected.payTo !== 'string' || !/^[GC][A-Z2-7]{55}$/.test(expected.payTo) ||
      !sorobanAmount(expected.amount))
    return failure('TERMS_INVALID');
  // The fee-paying transaction source is the facilitator; the actual token
  // payer comes from the client-signed transfer authorization and SEP-41 event.
  // A seller-reported payer alone is not proof, so bind it to that event below.
  // Caller-supplied pagination is a finite RPC work budget.
  if (!Number.isSafeInteger(maxEventPages) || maxEventPages < 1 || maxEventPages > 100)
    return failure('EVENT_PAGE_BUDGET_INVALID');
  if(typeof receipt.payer!=='string' || !PAYER.test(receipt.payer))
    return failure('RECEIPT_PAYER_MISSING_OR_INVALID');
  if(expected.payer!==undefined &&
      (typeof expected.payer!=='string' || !PAYER.test(expected.payer) || expected.payer!==receipt.payer))
    return failure('EXPECTED_PAYER_MISMATCH');
  const profile=networkProfile(expected.network);
  let tx;
  try {
    rpcEndpoint=resolveRpcEndpoint(expected.network,rpcEndpoint,{allowLocal:true});
    if (!LOCAL_RPC.test(rpcEndpoint)) {
      const network=await callRpc('getNetwork',{},fetchImpl,rpcEndpoint);
      if (network.passphrase !== profile.passphrase)
        return failure('RPC_NETWORK_PASSPHRASE_MISMATCH');
    }
    tx=await callRpc('getTransaction',{hash:receipt.transaction},fetchImpl,rpcEndpoint);
  }
  catch (error) { return failure('RPC_TRANSACTION_LOOKUP_FAILED',{detail:error.message}); }
  if (tx.status !== 'SUCCESS' || tx.txHash !== receipt.transaction ||
      !Number.isSafeInteger(tx.ledger) || tx.ledger <= 0) {
    return failure(tx.status === 'NOT_FOUND' ? 'RPC_TRANSACTION_NOT_FOUND' : 'RPC_TRANSACTION_NOT_SUCCESS',
      {reportedStatus:tx.status??null});
  }
  // getTransaction.createdAt is the included ledger's Unix close timestamp.
  // Keep the original provider fact when available. Temporal-recovery callers
  // require it explicitly; other existing receipt observers remain compatible.
  const createdAt=typeof tx.createdAt==='string'&&/^[1-9][0-9]{0,12}$/.test(tx.createdAt)&&
    Number.isSafeInteger(Number(tx.createdAt))?tx.createdAt:
    Number.isSafeInteger(tx.createdAt)&&tx.createdAt>0?String(tx.createdAt):null;
  const inclusion={ network:expected.network, transaction:tx.txHash, ledger:tx.ledger,
    ...(createdAt===null?{}:{createdAt}),
    proof:'INDEPENDENT_STELLAR_RPC_GET_TRANSACTION_SUCCESS' };
  if (typeof decodeContractEvent !== 'function')
    return {status:'TX_INCLUDED_TRANSFER_UNVERIFIED',...inclusion,reason:'NO_SOROBAN_EVENT_DECODER'};
  let page='', pages=0, sawTargetTx=false;
  try {
    while (pages++ < maxEventPages) {
      const result = await callRpc('getEvents',{
        // Stellar RPC requires startLedger omitted once a pagination cursor is sent.
        ...(page ? {} : {startLedger:tx.ledger}),
        filters:[{type:'contract',contractIds:[expected.asset]}],
        pagination:{limit:200,...(page?{cursor:page}:{})},
      },fetchImpl,rpcEndpoint);
      const events=Array.isArray(result.events)?result.events:[];
      for(const event of events) {
        if (event.txHash !== receipt.transaction || event.contractId !== expected.asset) continue;
        sawTargetTx=true;
        // Only the canonical Stellar SDK decoder, not a text search over XDR, can
        // derive the exact transfer event's source/recipient/atomic value.
        const decoded=await decodeContractEvent(event);
        if (decoded?.name === 'transfer' && decoded.from === receipt.payer &&
            decoded.to === expected.payTo && String(decoded.amount) === expected.amount) {
          return {status:profile.chainStatus,...inclusion,
            contractId:expected.asset,payer:receipt.payer,
            recipient:expected.payTo,amountAtomic:expected.amount,
            eventId:event.id??null,proof:'RPC_TX_AND_SEP41_TRANSFER_EVENT_MATCH'};
        }
      }
      const next=result.cursor ?? result.pagination?.cursor ?? null;
      if (!next || next === page) break;
      page=next;
    }
  } catch(error) {
    return {status:'TX_INCLUDED_TRANSFER_UNVERIFIED',...inclusion,
      reason:'TOKEN_EVENTS_UNAVAILABLE',detail:error.message};
  }
  return {status:'TX_INCLUDED_TRANSFER_UNVERIFIED',...inclusion,
    reason:sawTargetTx?'NO_MATCHING_SEP41_TRANSFER':'TOKEN_TRANSFER_NOT_INDEXED'};
}

/** Retain the original testnet-only API for callers that explicitly require it. */
export async function checkStellarTestnetTransaction(options = {}) {
  if (options.receipt?.network !== 'stellar:testnet' || options.expected?.network !== 'stellar:testnet')
    return failure('RECEIPT_NETWORK_SUCCESS_OR_HASH_INVALID');
  return checkStellarTransaction(options);
}

/** Parse official Stellar SDK scValToNative transfer data. Legacy SEP-41
 * carries scalar i128; modern SEP-41/SAC carries {amount:i128,to_muxed_id?:...}.
 * A muxed destination is not proven to match a base-G-address-only payTo.
 */
export function parseSep41TransferAmount(native) {
  let raw=native;
  if (native instanceof Map) {
    if (!native.has('amount') || [...native.keys()].some(k=>!['amount','to_muxed_id'].includes(k)) || native.get('to_muxed_id') != null) return null;
    raw=native.get('amount');
  } else if (native !== null && typeof native === 'object') {
    if (Array.isArray(native) || !Object.hasOwn(native,'amount') ||
      Object.keys(native).some(k=>!['amount','to_muxed_id'].includes(k)) ||
      native.to_muxed_id != null) return null;
    raw=native.amount;
  }
  if (typeof raw==='bigint') return raw>0n && raw<=SOROBAN_I128_MAX?raw.toString():null;
  if (typeof raw==='string') return sorobanAmount(raw)?raw:null;
  if (typeof raw==='number') return Number.isSafeInteger(raw)&&raw>0?String(raw):null;
  return null;
}

/** Prefer actual @stellar/stellar-sdk provided by @x402/stellar installation. */
export async function createOfficialEventDecoder() {
  let sdk;
  // The official base entry contains the same XDR and ScVal implementations
  // without loading the SDK's HTTP, Horizon, RPC and contract client graph.
  try { sdk=await import('@stellar/stellar-sdk/base'); }
  catch(error) {
    if (!['ERR_MODULE_NOT_FOUND','ERR_PACKAGE_PATH_NOT_EXPORTED'].includes(error.code)) throw error;
    try { sdk=await import('@stellar/stellar-sdk'); }
    catch(rootError) {
      if(rootError.code !== 'ERR_MODULE_NOT_FOUND') throw rootError;
      // Preserve the maintained buyer's package-local installation and older
      // SDKs that do not publish the base subpath.
      const require=createRequire(new URL('../sf88-operator-buyer-cli/package.json',import.meta.url));
      try { sdk=require('@stellar/stellar-sdk/base'); }
      catch(localError) {
        if (!['MODULE_NOT_FOUND','ERR_PACKAGE_PATH_NOT_EXPORTED'].includes(localError.code)) throw localError;
        sdk=require('@stellar/stellar-sdk');
      }
    }
  }
  const decode=value=>sdk.scValToNative(sdk.xdr.ScVal.fromXDR(value,'base64'));
  return async event=>{
    if (!Array.isArray(event.topic) || event.topic.length < 3 || !event.value) return null;
    const [name,from,to]=event.topic.slice(0,3).map(decode);
    if (typeof name !== 'string' || name !== 'transfer') return null;
    const amount=parseSep41TransferAmount(decode(event.value));
    if (amount===null) return null;
    return {name,from:String(from),to:String(to),amount};
  };
}
