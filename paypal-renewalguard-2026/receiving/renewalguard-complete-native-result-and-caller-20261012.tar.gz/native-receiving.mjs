import { makeServer } from './source/src/server.mjs';
import { runMerchantJourney } from './source/examples/merchant-journey.mjs';
import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const runCLI=promisify(execFile);
import { connect } from 'node:net';
import { once } from 'node:events';

const root=process.argv[2], output=join(root,'receiving');
const sourceManifest=JSON.parse(await readFile(join(root,'source','receiving-source-manifest.json'),'utf8'));
for(const [path,expected] of Object.entries(sourceManifest.blobs)){
 const bytes=await readFile(join(root,'source',path));
 const observed=createHash('sha1').update(Buffer.concat([Buffer.from('blob '+bytes.length+'\0'),bytes])).digest('hex');
 if(observed!==expected)throw new Error('Receiving source changed: '+path);
}

await mkdir(output,{recursive:true});
const hash=value=>createHash('sha256').update(typeof value==='string'?value:JSON.stringify(value)).digest('hex');
const save=async(name,value)=>writeFile(join(output,name),JSON.stringify(value,null,2)+'\n');
const servers=[];
async function start(dataDir){
  const server=makeServer({dataDir});server.listen(0,'127.0.0.1');await once(server,'listening');
  servers.push(server);return {server,base:'http://127.0.0.1:'+server.address().port};
}
const stop=server=>new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));
async function api(base,path,params={},body=null){
 const response=await fetch(base+path+(body?'':'?'+new URLSearchParams({mode:'demo',...params})),{
   method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined,
   signal:AbortSignal.timeout(120000)});
 const value=await response.json();if(!response.ok)throw new Error(JSON.stringify(value));return value;
}
let original;
try{
  original=await start(join(root,'original-data'));
  const portfolioBody={mode:'demo',request_id:'renewalguard-e9b2-native-batch-portfolio-20261012',action:'refresh_portfolio',input:{}};
  await api(original.base,'/api/command',{},portfolioBody);
  const workspace=await api(original.base,'/api/workspace');
  const batch=await api(original.base,'/api/command',{},{
    mode:'demo',request_id:'renewalguard-e9b2-native-batch-intake-20261012',action:'intake',
    input:{portfolio_sha:workspace.portfolio.sha,subscription_ids:workspace.portfolio.items.map(x=>x.id)},
  });
  if(batch.result.cases.length!==3)throw new Error('Original three-record demo intake did not complete');
  await save('batch-intake.json',batch);
  const result=await runMerchantJourney({base:original.base,mode:'demo',operation:'renewalguard-merchant-case-e9b2-20261012',
    output:join(output,'merchant-journey'),owner:'Demonstration renewal operator',reviewer:'Demonstration receiving operator',
    onProgress:entry=>process.stdout.write(JSON.stringify({journey:entry.step||entry.state,request_id:entry.request_id||null})+'\n')});
  const caseId=result.case_id, before=await api(original.base,'/api/case',{case_id:caseId});
  const lostId='renewalguard-e9b2-native-lost-plan-reply-20261012';
  const lostBody={mode:'demo',request_id:lostId,action:'save_plan',input:{case_id:caseId,expected_revision:before.revision,
    work:{...before.plan.work,work_status:'in_progress',next_action:'Continue the reopened renewal follow-up and retain its exact handover.',
      notes:before.plan.work.notes+'\nOriginal native lost-response receiving continuation.'}}};
  await save('original-lost-response-command.json',lostBody);
  const payload=JSON.stringify(lostBody),address=new URL(original.base);
  await new Promise((resolve,reject)=>{
    const socket=connect(Number(address.port),'127.0.0.1');
    socket.setTimeout(30000,()=>socket.destroy(new Error('Original response-discard operation timed out')));
    socket.on('error',reject);
    socket.once('connect',()=>socket.write('POST /api/command HTTP/1.1\r\nHost: '+address.host+
      '\r\nContent-Type: application/json\r\nContent-Length: '+Buffer.byteLength(payload)+'\r\nConnection: close\r\n\r\n'+payload));
    socket.once('data',()=>{socket.destroy();resolve();});
  });
  await stop(original.server);
  original=await start(join(root,'original-data'));
  const after=await api(original.base,'/api/case',{case_id:caseId});
  if(after.plan.number!==before.plan.number+1)throw new Error('Original lost-reply plan was not saved exactly once');
  const cliPath=join(root,'source','src','cli.mjs');
  const cliArgs=[cliPath,'resume','--mode','demo','--base',original.base,'--request-id',lostId,
    '--output',join(output,'original-cli-recovered-result.json')];
  const cli=await runCLI(process.execPath,cliArgs,{encoding:'utf8',timeout:30000});
  const recovered=JSON.parse(await readFile(join(output,'original-cli-recovered-result.json'),'utf8'));
  if(recovered.request_id!==lostId||recovered.result.state!=='plan_saved')throw new Error('CLI did not recover the original saved plan');
  const afterReplay=await api(original.base,'/api/case',{case_id:caseId});
  if(hash(after)!==hash(afterReplay))throw new Error('Original reply recovery altered the saved case');
  const exportPath=join(output,'original-cli-resolved-handover.json');
  const exported=await runCLI(process.execPath,[cliPath,'export','--mode','demo','--base',original.base,'--case',caseId,
    '--revision',String(result.resolved_revision),'--output',exportPath],{encoding:'utf8',timeout:30000});
  const cliHandover=JSON.parse(await readFile(exportPath,'utf8'));
  const handover=JSON.parse(await readFile(join(output,'merchant-journey','resolved-case-handover.json'),'utf8'));
  if(hash(cliHandover)!==hash(handover))throw new Error('Historical handover bytes changed after reopening and reply recovery');
  const receiving=await start(join(root,'received-data'));
  const receiveId='renewalguard-e9b2-native-original-portable-receive-20261012';
  const received=await api(receiving.base,'/api/command',{},{
    mode:'demo',request_id:receiveId,action:'restore',input:{handover},
  });
  const receiveReplay=await api(receiving.base,'/api/resume',{}, {mode:'demo',request_id:receiveId});
  if(received.result.journal_sha!==receiveReplay.result.journal_sha)throw new Error('Portable replay changed its original journal entry');
  const receivedCase=await api(receiving.base,'/api/case',{case_id:caseId});
  if(receivedCase.case.id!==caseId||receivedCase.case.stage!=='resolved'||
    receivedCase.plan.id!==handover.case.plans.at(-1).id||receivedCase.source.id!==handover.case.sources.at(-1).id)
    throw new Error('Original case/source/plan identity changed in portable receiving');
  await save('portable-original-receive.json',received);
  await save('portable-original-case.json',receivedCase);
  const receivingReopen=await api(receiving.base,'/api/command',{},{
    mode:'demo',request_id:'renewalguard-e9b2-native-portable-reopen-20261012',action:'reopen',
    input:{case_id:caseId,expected_revision:receivedCase.revision,reason:'Continue the received original renewal support handover.'},
  });
  await stop(receiving.server);
  const reopenedReceiver=await start(join(root,'received-data'));
  const reopenedCase=await api(reopenedReceiver.base,'/api/case',{case_id:caseId});
  if(reopenedCase.case.stage!=='open'||reopenedCase.case.resolutions.at(-1).id!==result.resolution_id)
    throw new Error('Original resolution did not survive receiving restart and reopening');
  const final={schema:'renewalguard-native-complete-receiving-v1',
    operation_id:'RENEWALGUARD-MERCHANT-CASE-DESK-E9B2-20261012',source_pin:process.env.RENEWALGUARD_SOURCE_PIN,
    provider:'renewalguard_demo',case_id:caseId,completed_case_intake:batch.result.cases.length,
    original_merchant_journey:result,original_lost_response_request:lostId,original_lost_response_case_revision:after.revision,
    same_uuid_case_unchanged_after_recovery:hash(after)===hash(afterReplay),original_handover_sha256:handover.sha256,
    cli_historical_handover_identical:true,portable_receive_request:receiveId,portable_case_id:reopenedCase.case.id,
    portable_final_revision:receivingReopen.result.revision,portable_final_stage:reopenedCase.case.stage,
    portable_original_resolution_id:reopenedCase.case.resolutions.at(-1).id,
    original_source_ids:handover.case.sources.map(x=>x.id),original_plan_ids:handover.case.plans.map(x=>x.id)};
  await save('native-result.json',final);
  process.stdout.write(JSON.stringify({native_result:final})+'\n');
}finally{
  for(const server of servers)if(server.listening)await stop(server).catch(()=>{});
}
