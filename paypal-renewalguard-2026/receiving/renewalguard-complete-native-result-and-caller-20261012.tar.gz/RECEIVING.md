# RenewalGuard completed native receiving

Source: woahwhattheheck/public-commons-sprint-2026, paypal-renewalguard-2026.
Merged PR1852: 805a8317d1e05ffbded23b3c0ffa1fc97ce15569.
Operated source: b029ef5800f18cd34b73c7b46fab77785871c44f.
Original operation: RENEWALGUARD-MERCHANT-CASE-DESK-E9B2-20261012.

The included native-result.json was returned by the actual Linux Node process, exit 0 with empty stderr. It retains all original case, source, plan, review, resolution and request identities. The run used the maintained demonstration subscription provider and its actual RULE_BASED_PREVIEW note.

The run completed portfolio/batch intake, original assigned plan and note, source-bound immutable review, resolution, historical handover and reopening. It discarded a real HTTP reply, restarted the original server and recovered the original request with the CLI; historical closed-revision CLI export was byte-identical. An empty scoped receiver restored/replayed the complete original handover and reopened it across restart.

## Files and retention

native-receiving.mjs is the complete actual executed caller. original-run-output-manifest.json is the original process's 29-file manifest and full-archive hash. The original process built a 64,572-byte full-state archive; its executor lifetime ended before an archive chunk could be retrieved. This package retains the complete returned result, original manifest and exact caller. The maintained product source and reusable configured operator are available at the merged source above.

## Existing configured sandbox operation

Run the maintained examples/merchant-journey.mjs against the original configured loopback server, selecting the original actual test subscription from that server's retained portfolio:

```sh
node examples/merchant-journey.mjs --base http://127.0.0.1:8787 --mode sandbox --subscription ORIGINAL_TEST_SUBSCRIPTION_ID --operation renewalguard-merchant-case-e9b2-20261012 --output RETAINED_OPERATION_DIRECTORY
```

The operator retains every exact original request before dispatch and reuses saved inputs on replay. Preserve its output directory and the configured server's RENEWALGUARD_DATA_DIR through completion. PayPal and AI credentials remain in that existing server environment.

The original five-app receiving thread is C0BVDDS04G2 / 1791572487.489949. Its configured continuation and merged complete source are already coordinated there.
