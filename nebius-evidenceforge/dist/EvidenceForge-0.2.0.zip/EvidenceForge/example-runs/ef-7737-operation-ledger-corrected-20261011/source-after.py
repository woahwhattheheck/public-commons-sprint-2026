import json
import hashlib

def apply_operation(ledger, operation_id, payload):
    if not isinstance(operation_id, str) or not operation_id.strip():
        raise ValueError("operation ID required")
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)
    fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    if operation_id in ledger:
        record = ledger[operation_id]
        if record["fingerprint"] != fingerprint:
            raise ValueError("operation ID conflicts with prior payload")
        return record["result"]
    result = {"sequence": len(ledger) + 1, "payload": payload}
    ledger[operation_id] = {"fingerprint": fingerprint, "result": result}
    return result
