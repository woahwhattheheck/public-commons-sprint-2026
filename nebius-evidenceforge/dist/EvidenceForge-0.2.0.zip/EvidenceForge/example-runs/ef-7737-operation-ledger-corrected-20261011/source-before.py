import json
import hashlib

def apply_operation(ledger, operation_id, payload):
    if operation_id in ledger:
        return ledger[operation_id]["result"]
    result = {"sequence": len(ledger) + 1, "payload": payload}
    ledger[operation_id] = {"result": result}
    return result
