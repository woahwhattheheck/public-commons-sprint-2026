import csv
import io
from decimal import Decimal, InvalidOperation

def parse_invoices(text):
    rows = []
    seen = set()
    clean = text.lstrip("\ufeff")
    reader = csv.DictReader(io.StringIO(clean))
    if reader.fieldnames != ["id", "amount"]:
        raise ValueError("expected id,amount columns")
    for row in reader:
        identity = (row.get("id") or "").strip()
        if not identity or identity in seen:
            raise ValueError("missing or duplicate invoice ID")
        try:
            amount = Decimal((row.get("amount") or "").strip())
        except InvalidOperation:
            raise ValueError("invalid amount")
        if not amount.is_finite() or amount < 0 or amount != amount.quantize(Decimal("0.01")):
            raise ValueError("amount must be nonnegative finite cents")
        seen.add(identity)
        rows.append({"id": identity, "cents": int(amount * 100)})
    return rows
