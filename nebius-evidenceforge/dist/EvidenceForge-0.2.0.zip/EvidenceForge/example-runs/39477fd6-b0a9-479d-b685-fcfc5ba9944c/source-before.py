import csv
import io
from decimal import Decimal, InvalidOperation

def parse_invoices(text):
    rows = []
    for row in csv.DictReader(io.StringIO(text)):
        amount = Decimal(row["amount"])
        rows.append({"id": row["id"], "cents": int(amount * 100)})
    return rows
