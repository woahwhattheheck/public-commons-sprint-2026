# Reopen this EvidenceForge operation

Extract into a new private directory, preserving the operation folder. Run the original EvidenceForge source with:

    python -B -m evidenceforge.web_runtime --runs /absolute/path/to/extracted-directory

Open the local interface and inspect operation `ef-7737-dependency-order-corrected-20261011`. Opening performs no inference or execution. The original source, receipt and API records remain distinct from provider account billing. No credential is included.
