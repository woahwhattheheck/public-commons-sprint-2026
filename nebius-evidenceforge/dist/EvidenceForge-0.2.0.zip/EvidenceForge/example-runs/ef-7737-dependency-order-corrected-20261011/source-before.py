def order_tasks(manifest):
    return [row["id"] for row in manifest]
