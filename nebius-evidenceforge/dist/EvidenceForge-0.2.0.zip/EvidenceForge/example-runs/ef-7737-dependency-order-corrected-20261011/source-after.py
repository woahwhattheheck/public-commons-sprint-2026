def order_tasks(manifest):
    identities = [row["id"] for row in manifest]
    if len(set(identities)) != len(identities):
        raise ValueError("duplicate task ID")
    known = set(identities)
    deps = {}
    for row in manifest:
        required = list(row.get("depends_on", []))
        if any(item not in known for item in required):
            raise ValueError("unknown dependency")
        deps[row["id"]] = set(required)
    pending = list(identities)
    result = []
    while pending:
        ready = [identity for identity in pending if deps[identity].issubset(set(result))]
        if not ready:
            raise ValueError("dependency cycle")
        identity = ready[0]
        result.append(identity)
        pending.remove(identity)
    return result
