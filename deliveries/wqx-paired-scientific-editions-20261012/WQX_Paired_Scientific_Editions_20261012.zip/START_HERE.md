# WQX Water Quality — Paired Scientific Editions

This complete application includes the original WQX acquisition, saved receiving decisions and concentration workflow, plus paired original/reporting-unit scientific editions and the 39-tool merchant operator.

Open [the scientific operating guide](source/stellar/scf-starforge-20261009/sf30-seller-sdk/wqx-water-quality/SCIENTIFIC.md) for the browser, tables, review periods and complete receiving bundles. [The merchant guide](source/stellar-forge/mcp-merchant-operator/WQX_SCIENTIFIC.md) covers the typed client and installed CLI. [The complete native receiving guide](source/stellar/scf-starforge-20261009/sf30-seller-sdk/wqx-water-quality/standardized-analysis/RECEIVING.md) runs the retained Potomac source through the original source, CLI, browser and two-workspace MCP phases.

## Start the application

Use Node 24, Python 3.11 or later and the original declared SDK dependencies in the included package manifests. Open a private project with the existing command from the source directory:

```bash
node stellar/scf-starforge-20261009/sf30-seller-sdk/wqx-water-quality/cli.mjs serve \
  --project /srv/water/potomac
```

The command prints the actual loopback URL. Create or receive a complete native decision review, then use **Scientific analysis** to select its exact saved identity. Preview the complete original and reporting quantities, choose a reporting period or earlier scientific edition, and save an immutable scientific review. Every saved review has seven complete downloadable formats.

## Complete original source

SOURCE_MANIFEST.json lists all 664 original source members, their UTF-8 lengths, SHA-256 values and native Git blob identities. The included original Potomac carrier contains the complete 1,035-result, 1,112-limit source graph. It is the same retained source used by the calculation; no new provider request is required for receiving.

The paired source calculation converted 749 selected results and 1,089 independently attached limits while retaining every original value and source reference. This source package includes the complete receiving program. Its native CLI/browser/MCP execution state is recorded separately in actual phase receipts; source publication alone does not claim that execution.

Keep the original configuration and operation ID when resuming an interrupted run. Do not replace retained incomplete outputs or create a second operation. The receiving guide explains source restoration, exact configuration hashing, original response recovery and complete final artifact retention.
