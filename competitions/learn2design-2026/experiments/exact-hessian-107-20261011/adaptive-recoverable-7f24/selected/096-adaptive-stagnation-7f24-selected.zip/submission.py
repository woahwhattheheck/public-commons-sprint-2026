"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{"armijo_c1": 0.0001, "curvature_eps": 1e-8, "early_polish_time_fraction": 0.25, "memory": 8, "min_remaining_polish_calls": 2, "min_stagnant_explore_calls": 8, "polish_enabled": true, "polish_quantum": 4, "polish_schedule": "stagnation", "polish_start_fraction": 0.8, "qn_grow": 2, "qn_max_radius": 0.3, "qn_min_radius": 0.000001, "qn_radius": 0.08, "qn_shrink": 0.5, "resume_explore_calls": 4, "stagnation_fraction": 0.12, "trace_limit": 4096}')
SOURCE_ID = '096-adaptive-stagnation-7f24'
ARM_SHA256 = '2ef2d33d1e894042dc3bd0304d8c51e77e096c31e7c4abf2fc77f1e3cca33deb'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.AdaptiveRecoverablePolish096.algorithm_str
    if hasattr(_original.AdaptiveRecoverablePolish096, 'algorithm_type'):
        algorithm_type = _original.AdaptiveRecoverablePolish096.algorithm_type

    def __init__(self):
        self._implementation = _original.AdaptiveRecoverablePolish096()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
