"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{"backtracking_state": "anchor", "prefeasible_budget_fraction": 0.5, "prefeasible_fraction": 0.1, "prefeasible_max_restarts": 4, "prefeasible_max_streak": 80, "prefeasible_min_streak": 12, "prefeasible_recovery": "restart"}')
SOURCE_ID = '099-prefeasible-restart-regional'
ARM_SHA256 = '6e131e2702403a31c241d53221f4abc8b4e74326a31e220267b0af5f578f3b0c'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.PreFeasibleRecoveryPortfolioRegional.algorithm_str
    if hasattr(_original.PreFeasibleRecoveryPortfolioRegional, 'algorithm_type'):
        algorithm_type = _original.PreFeasibleRecoveryPortfolioRegional.algorithm_type

    def __init__(self):
        self._implementation = _original.PreFeasibleRecoveryPortfolioRegional()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
