"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{}')
SOURCE_ID = '096'
ARM_SHA256 = '8f7e95f6fdc60327b0aca253328146c3ffe8bc7e77e059ad1cde81650745f6ce'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.StagedTrustPortfolio096.algorithm_str
    if hasattr(_original.StagedTrustPortfolio096, 'algorithm_type'):
        algorithm_type = _original.StagedTrustPortfolio096.algorithm_type

    def __init__(self):
        self._implementation = _original.StagedTrustPortfolio096()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
