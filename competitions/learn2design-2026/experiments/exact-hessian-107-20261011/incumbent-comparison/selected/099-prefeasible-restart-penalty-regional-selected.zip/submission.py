"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{"backtracking_state": "anchor", "prefeasible_budget_fraction": 0.5, "prefeasible_fraction": 0.1, "prefeasible_max_restarts": 4, "prefeasible_max_streak": 80, "prefeasible_min_streak": 12, "prefeasible_recovery": "restart_penalty"}')
SOURCE_ID = '099-prefeasible-restart-penalty-regional'
ARM_SHA256 = '5d8b4f63b54b96815348858c19f41ba73a9b2bbfc3522a8fef6185222b2cf205'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.PreFeasibleRecoveryPortfolioRegional.algorithm_str
    if hasattr(_original.PreFeasibleRecoveryPortfolioRegional, 'algorithm_type'):
        algorithm_type = _original.PreFeasibleRecoveryPortfolioRegional.algorithm_type

    def __init__(self):
        self._implementation = _original.PreFeasibleRecoveryPortfolioRegional()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
