"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{}')
SOURCE_ID = 'ffr130'
ARM_SHA256 = '31350dd3b65a8c87978bdff3e700054532e919787be8b8d19fd7e363d1c9cc81'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.FeasibleFilterRetention130.algorithm_str
    if hasattr(_original.FeasibleFilterRetention130, 'algorithm_type'):
        algorithm_type = _original.FeasibleFilterRetention130.algorithm_type

    def __init__(self):
        self._implementation = _original.FeasibleFilterRetention130()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
