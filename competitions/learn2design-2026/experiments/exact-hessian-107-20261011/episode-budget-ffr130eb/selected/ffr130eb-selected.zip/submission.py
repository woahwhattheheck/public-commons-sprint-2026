"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{}')
SOURCE_ID = 'ffr130eb'
ARM_SHA256 = 'cae7587a1a91cc0cda376454f40121a23369c213114136f5f942067228c1e53d'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.FeasibleFilterRetention130EB.algorithm_str
    if hasattr(_original.FeasibleFilterRetention130EB, 'algorithm_type'):
        algorithm_type = _original.FeasibleFilterRetention130EB.algorithm_type

    def __init__(self):
        self._implementation = _original.FeasibleFilterRetention130EB()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
