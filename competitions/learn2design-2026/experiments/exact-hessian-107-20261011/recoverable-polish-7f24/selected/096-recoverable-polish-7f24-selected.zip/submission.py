"""Exact selected Learn2Design arm; original implementation is retained alongside."""
from copy import deepcopy
import json
from dfbench import OptimizationAlgorithm
import retained_algorithm as _original

_OPTIONS = json.loads('{"armijo_c1": 0.0001, "curvature_eps": 1e-08, "memory": 8, "polish_enabled": true, "polish_quantum": 4, "polish_start_fraction": 0.8, "qn_grow": 2, "qn_max_radius": 0.3, "qn_min_radius": 1e-06, "qn_radius": 0.08, "qn_shrink": 0.5, "resume_explore_calls": 4, "trace_limit": 4096}')
SOURCE_ID = '096-recoverable-polish-7f24'
ARM_SHA256 = '1a8dca2d5b6a423499d624b5e6b585dc6e2e830a9a64d94186d6205ee59852f3'

class SelectedOptimizer(OptimizationAlgorithm):
    algorithm_str = _original.RecoverablePolish096.algorithm_str
    if hasattr(_original.RecoverablePolish096, 'algorithm_type'):
        algorithm_type = _original.RecoverablePolish096.algorithm_type

    def __init__(self):
        self._implementation = _original.RecoverablePolish096()
        self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})

    def optimize(self, objective, **kwargs):
        if set(kwargs).intersection(_OPTIONS):
            raise ValueError('Caller options conflict with the selected source arm')
        try:
            return self._implementation.optimize(objective, **kwargs, **deepcopy(_OPTIONS))
        finally:
            self.last_run_diagnostics = getattr(self._implementation, 'last_run_diagnostics', {})
