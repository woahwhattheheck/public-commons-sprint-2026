# Pedestrian/bicyclist-involved original crash cohort handover

Project: kea-fars-dc-2020-20261012

Case: Unassigned

Analysis: crash-analysis-2 · 2026-10-12T14:55:00Z

Review: Token Junkie Labs research engineering · ACCEPTED · Original personcode5/6 membership is traceable per crash. Related populations retain all selected crash records without multiplying vehicle and person rows.

## Original source files

| File | Rows | Columns | SHA-256 | Source |
| --- | ---: | ---: | --- | --- |
| fars-2020-dc-accident-original.json | 34 | 94 | fb402bff9bc99386016957daf7d0d105757b0b90512297c730e9f0e6e90150f0 | https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Accident&format=json&state=11 |
| fars-2020-dc-vehicle-original.csv | 50 | 252 | d2006fef129c8d9f29c3ea735ea636b585003d9c5d80bf644bafb3ab134695f3 | https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Vehicle&format=csv&state=11 |
| fars-2020-dc-person-original.csv | 83 | 159 | fa5c18fdfea837d3a8bd517afdead62d415d32a7270415a8a4e8cb716088ec0b | https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Person&format=csv&state=11 |

## Cohort and denominators

11 included crashes; 23 excluded; 0 indeterminate.

| Record family | Selected unique records |
| --- | ---: |
| crash | 11 |
| vehicle | 15 |
| person | 30 |

## Descriptive results

| Measure | Family | Group | Records | Observed | Declared denominator | Result |
| --- | --- | --- | ---: | ---: | ---: | --- |
| Selected fatal crash records | crash |  | 11 | 11 | 11 · all_records | 11 |
| Original in-transport vehicles | vehicle |  | 15 | 15 | 15 · all_records | 15 |
| Original person records | person |  | 30 | 30 | 30 · all_records | 30 |
| Source Fatal Injury(K) records | person |  | 30 | 29 | 30 · all_records | 11 / 30 = 0.366667 |
| Original person roles | person |  | 30 | 30 | 30 · all_records | 5: 10 [VALID]; 1: 14 [VALID]; 2: 4 [VALID]; 9: 1 [VALID]; 6: 1 [VALID] |
| Recorded age by person role | person | Person role=5 | 10 | 10 | 10 · observed_values | mean 37.8 years; SD 12.290918; median 37.5; numeric n 10 |
| Recorded age by person role | person | Person role=1 | 14 | 14 | 14 · observed_values | mean 33.785714 years; SD 12.747118; median 31.5; numeric n 14 |
| Recorded age by person role | person | Person role=2 | 4 | 4 | 4 · observed_values | mean 29.5 years; SD 6.244998; median 29.5; numeric n 4 |
| Recorded age by person role | person | Person role=9 | 1 | 0 | 0 · observed_values | mean — years; SD —; median —; numeric n 0 |
| Recorded age by person role | person | Person role=6 | 1 | 1 | 1 · observed_values | mean 43 years; SD —; median 43; numeric n 1 |
| Source lighting conditions | crash |  | 11 | 11 | 11 · all_records | 3: 9 [VALID]; 4: 1 [VALID]; 5: 1 [VALID] |

## Method

Numeric means, standard deviations and quantiles use the displayed numeric n: original observations with a valid numeric value after the saved missing-code and range rules. The declared denominator remains visible separately for the measure population.

All results describe the selected original records. A crash, vehicle, parked/working vehicle and person each have their own composite identity and denominator. Child records are never multiplied by another child family. Numeric summaries exclude only explicitly missing, nonnumeric and out-of-range values and retain those original values. Percentages use the selected denominator; no exposure denominator, causal effect or population crash risk is inferred.

Condition selects crashes; each measure then describes its declared original record family within those crashes.

## Complete receiving

The accompanying handover JSON preserves the original source texts, source mapping, each saved cohort and plan edition, row decisions, original operation identities, reviewed analyses and frozen context. Open it in the linked-cohort receiving panel to recompute the complete result. The full project JSON preserves the broader editable study.
