# FARS2020 DC complete linked cohort and research handover

Project: kea-fars-dc-2020-20261012

Case: Unassigned

Analysis: crash-analysis-1 · 2026-10-12T14:55:00Z

Review: Token Junkie Labs research engineering · ACCEPTED · The complete three source exports have34crashes,50vehicles and83people; every occupied-vehicle/person link resolves,11nonmotorists usevehicle0, and36person fatalities match the original crash-level FATALS sum. Original rows and unavailable values were retained.

## Original source files

| File | Rows | Columns | SHA-256 | Source |
| --- | ---: | ---: | --- | --- |
| fars-2020-dc-accident-original.json | 34 | 94 | fb402bff9bc99386016957daf7d0d105757b0b90512297c730e9f0e6e90150f0 | https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Accident&format=json&state=11 |
| fars-2020-dc-vehicle-original.csv | 50 | 252 | d2006fef129c8d9f29c3ea735ea636b585003d9c5d80bf644bafb3ab134695f3 | https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Vehicle&format=csv&state=11 |
| fars-2020-dc-person-original.csv | 83 | 159 | fa5c18fdfea837d3a8bd517afdead62d415d32a7270415a8a4e8cb716088ec0b | https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Person&format=csv&state=11 |

## Cohort and denominators

34 included crashes; 0 excluded; 0 indeterminate.

| Record family | Selected unique records |
| --- | ---: |
| crash | 34 |
| vehicle | 50 |
| person | 83 |

## Descriptive results

| Measure | Family | Group | Records | Observed | Declared denominator | Result |
| --- | --- | --- | ---: | ---: | ---: | --- |
| Selected fatal crash records | crash |  | 34 | 34 | 34 · all_records | 34 |
| Original in-transport vehicles | vehicle |  | 50 | 50 | 50 · all_records | 50 |
| Original person records | person |  | 83 | 83 | 83 · all_records | 83 |
| Source Fatal Injury(K) records | person |  | 83 | 82 | 83 · all_records | 36 / 83 = 0.433735 |
| Original person roles | person |  | 83 | 83 | 83 · all_records | 1: 49 [VALID]; 2: 22 [VALID]; 5: 10 [VALID]; 9: 1 [VALID]; 6: 1 [VALID] |
| Recorded age by person role | person | Person role=1 | 49 | 49 | 49 · observed_values | mean 37.265306 years; SD 14.085713; median 34; numeric n 49 |
| Recorded age by person role | person | Person role=2 | 22 | 22 | 22 · observed_values | mean 30.954545 years; SD 17.203204; median 32.5; numeric n 22 |
| Recorded age by person role | person | Person role=5 | 10 | 10 | 10 · observed_values | mean 37.8 years; SD 12.290918; median 37.5; numeric n 10 |
| Recorded age by person role | person | Person role=9 | 1 | 0 | 0 · observed_values | mean — years; SD —; median —; numeric n 0 |
| Recorded age by person role | person | Person role=6 | 1 | 1 | 1 · observed_values | mean 43 years; SD —; median 43; numeric n 1 |
| Source lighting conditions | crash |  | 34 | 34 | 34 · all_records | 1: 12 [VALID]; 3: 19 [VALID]; 4: 1 [VALID]; 5: 2 [VALID] |

## Method

Numeric means, standard deviations and quantiles use the displayed numeric n: original observations with a valid numeric value after the saved missing-code and range rules. The declared denominator remains visible separately for the measure population.

All results describe the selected original records. A crash, vehicle, parked/working vehicle and person each have their own composite identity and denominator. Child records are never multiplied by another child family. Numeric summaries exclude only explicitly missing, nonnumeric and out-of-range values and retain those original values. Percentages use the selected denominator; no exposure denominator, causal effect or population crash risk is inferred.

Counts preserve independent record-family denominators. Fatal Injury(K) uses sourcecode4; unknown injurycode9 remains unavailable. Agecodes998/999 are unavailable, following the2020 manual.

## Complete receiving

The accompanying handover JSON preserves the original source texts, source mapping, each saved cohort and plan edition, row decisions, original operation identities, reviewed analyses and frozen context. Open it in the linked-cohort receiving panel to recompute the complete result. The full project JSON preserves the broader editable study.
