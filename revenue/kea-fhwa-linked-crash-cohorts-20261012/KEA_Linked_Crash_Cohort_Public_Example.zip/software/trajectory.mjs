// Observed trajectory scenarios composed with the original Study Data Desk project.
import { reopenProject, summarize } from './core.mjs';

export const TRAJECTORY_SCHEMA = 'tjlabs.study-trajectory-workspace/v1';
const trjCopy = value => JSON.parse(JSON.stringify(value));
const trjCanonical = value => JSON.stringify(value, (_, item) => item && !Array.isArray(item) && typeof item === 'object' ? Object.fromEntries(Object.keys(item).sort().map(key => [key,item[key]])) : item);
const trjFail = (message, code='trajectory_arguments') => { throw Object.assign(new Error(message),{code}); };
const trjRequired = (value,label) => typeof value==='string' && value.trim() ? value.trim() : trjFail(label+' is required');
const trjFind = (values,id,label) => values.find(value=>value.id===id) || trjFail(label+' was not found');
const trjNumber = value => typeof value==='number' ? (Number.isFinite(value)?value:null) : /^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(String(value).trim()) && Number.isFinite(Number(value)) ? Number(value) : null;
const trjSame = (left,right) => trjCanonical(left)===trjCanonical(right);

// Portable SHA-256 keeps source and scenario bindings identical in browser and Node.
export function trajectoryDigest(value) {
  const text=typeof value==='string'?value:trjCanonical(value), raw=new Uint8Array(text.length*3);let used=0;
  for(const char of text) {
    let cp=char.codePointAt(0);if(cp>=0xd800&&cp<=0xdfff)cp=0xfffd;
    if(cp<0x80)raw[used++]=cp;
    else if(cp<0x800){raw[used++]=0xc0|(cp>>>6);raw[used++]=0x80|(cp&63);}
    else if(cp<0x10000){raw[used++]=0xe0|(cp>>>12);raw[used++]=0x80|((cp>>>6)&63);raw[used++]=0x80|(cp&63);}
    else{raw[used++]=0xf0|(cp>>>18);raw[used++]=0x80|((cp>>>12)&63);raw[used++]=0x80|((cp>>>6)&63);raw[used++]=0x80|(cp&63);}
  }
  const bytes=new Uint8Array(Math.ceil((used+9)/64)*64);bytes.set(raw.subarray(0,used));bytes[used]=0x80;
  const view=new DataView(bytes.buffer);view.setUint32(bytes.length-8,Math.floor(used/0x20000000));view.setUint32(bytes.length-4,(used*8)>>>0);
  const constants=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const state=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],words=new Uint32Array(64);
  const rotate=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let start=0;start<bytes.length;start+=64) {
    for(let i=0;i<16;i++)words[i]=view.getUint32(start+i*4);
    for(let i=16;i<64;i++){const x=words[i-15],y=words[i-2];words[i]=(words[i-16]+(rotate(x,7)^rotate(x,18)^(x>>>3))+words[i-7]+(rotate(y,17)^rotate(y,19)^(y>>>10)))>>>0;}
    let [a,b,c,d,e,f,g,h]=state;
    for(let i=0;i<64;i++){
      const one=(h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+constants[i]+words[i])>>>0;
      const two=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c)))>>>0;
      h=g;g=f;f=e;e=(d+one)>>>0;d=c;c=b;b=a;a=(one+two)>>>0;
    }
    const next=[a,b,c,d,e,f,g,h];for(let i=0;i<8;i++)state[i]=(state[i]+next[i])>>>0;
  }
  return state.map(value=>value.toString(16).padStart(8,'0')).join('');
}

function trjEmpty() {return {schema:TRAJECTORY_SCHEMA,mappings:[],scenarios:[],reviews:[],handovers:[]};}
function trjState(project) {return project.trajectory || trjEmpty();}
function trjTable(project,id) {return trjFind(project.tables,id,'Original source table');}
function trjSourceMetadata(table) {const {rows,original_text,...metadata}=table;return metadata;}
function trjProjectContext(project) {return {id:project.id,title:project.title,case_id:project.case_id,source_note:project.source_note,created_at:project.created_at};}
function trjBinding(project,tableId,runId=null) {
  const table=trjTable(project,tableId),run=runId?trjFind(project.runs,runId,'Saved source analysis'):null;
  if(run&&run.analysis.table_id!==table.id)trjFail('The selected analysis belongs to another source table');
  return {project_id:project.id,table_id:table.id,source_sha256:trajectoryDigest(table.original_text),
    records_sha256:trajectoryDigest({headers:table.headers,rows:table.rows}),source_metadata_sha256:trajectoryDigest(trjSourceMetadata(table)),source_rows:table.rows.length,
    run_id:run?.id||null,run_sha256:run?trajectoryDigest(run):null};
}
function trjCheckBinding(project,mapping) {
  if(!trjSame(trjBinding(project,mapping.table_id,mapping.run_id),mapping.source_binding))
    trjFail('The original table or saved analysis differs from this mapping edition. Reopen the retained original project or receive the changed source as a new table.','trajectory_source_changed');
}
export function reopenTrajectoryProject(value) {
  const project=reopenProject(value),state=trjState(project);
  if(state.schema!==TRAJECTORY_SCHEMA)trjFail('Unsupported trajectory workspace');
  for(const field of ['mappings','scenarios','reviews','handovers']){
    if(!Array.isArray(state[field])||state[field].some(item=>!item||typeof item.id!=='string'||!item.id)||new Set(state[field].map(item=>item.id)).size!==state[field].length)
      trjFail('Incomplete or repeated trajectory identity in '+field);
  }
  const bindings=new Set();
  for(const mapping of state.mappings){const key=mapping.table_id+'|'+(mapping.run_id||'');if(!bindings.has(key)){trjCheckBinding(project,mapping);bindings.add(key);}else if(!trjSame(state.mappings.find(m=>m.table_id===mapping.table_id&&m.run_id===mapping.run_id).source_binding,mapping.source_binding))trjFail('Inconsistent source binding');}
  for(const scenario of state.scenarios){
    const mapping=trjFind(state.mappings,scenario.mapping_id,'Scenario mapping');
    if(!trjSame(scenario.source_binding,mapping.source_binding)||!Array.isArray(scenario.tracks)||!scenario.tracks.some(t=>t.id===scenario.focus_track_id))
      trjFail('The saved scenario has a different source or focus track');
    if(scenario.previous_id){const previous=trjFind(state.scenarios,scenario.previous_id,'Previous scenario edition');if(previous.series_id!==scenario.series_id||previous.edition+1!==scenario.edition)trjFail('Invalid scenario edition chain');}
  }
  for(const review of state.reviews)if(trajectoryDigest(trjFind(state.scenarios,review.scenario_id,'Reviewed scenario'))!==review.scenario_sha256)trjFail('The reviewed scenario changed');
  for(const handover of state.handovers){
    const scenario=trjFind(state.scenarios,handover.scenario_id,'Handover scenario'),review=trjFind(state.reviews,handover.review_id,'Handover review');
    if(review.scenario_id!==scenario.id||review.status!=='ACCEPTED'||review.scenario_sha256!==trajectoryDigest(scenario))trjFail('Invalid frozen scenario handover');
  }
  return project;
}

const trjFactors={
  distance:{m:1,ft:0.3048},
  speed:{'m/s':1,'ft/s':0.3048,'km/h':1/3.6,mph:0.44704},
  acceleration:{'m/s2':1,'ft/s2':0.3048},
  timestamp:{ms:1,s:1000},
  headway:{s:1,ms:0.001}
};
const trjFieldNames=['time','frame','x','y','speed','acceleration','lane','length','width','leader','space_headway','time_headway'];
function trjNormalizeMapping(input,project) {
  const table=trjTable(project,input.table_id);
  const fields={};for(const role of trjFieldNames){
    const field=input.fields?.[role]||null;
    if(field!==null&&!table.headers.includes(field))trjFail('Choose an existing '+role+' column');
    fields[role]=field;
  }
  for(const role of ['time','x','y'])if(!fields[role])trjFail('Choose the '+role+' source column');
  const choose=(names,label,empty=false)=>{
    if(!Array.isArray(names)||(!empty&&!names.length)||new Set(names).size!==names.length||names.some(name=>!table.headers.includes(name)))trjFail('Choose existing '+label+' columns');
    return [...names];
  };
  const unit={};
  for(const [kind,allowed] of Object.entries(trjFactors)){unit[kind]=input.units?.[kind];if(!Object.hasOwn(allowed,unit[kind]))trjFail('Choose the published '+kind+' unit');}
  const step=Number(input.step_ms),tolerance=Number(input.tolerance_ms??0.01),frameStep=Number(input.frame_step??1);
  if(!Number.isFinite(step)||step<=0||!Number.isFinite(tolerance)||tolerance<0||tolerance>=step/2||!Number.isSafeInteger(frameStep)||frameStep<=0)trjFail('Choose a positive source interval and frame step with a smaller nonnegative timing tolerance');
  if(!['unix','elapsed'].includes(input.time_origin))trjFail('Choose Unix or elapsed source time');
  if(input.headway_requires_leader===true&&!fields.leader)trjFail('Choose the source leader column for headway availability');
  const rules=(input.rules||[]).map((rule,index)=>{
    if(!['lane_change','speed_below','acceleration_below','headway_below'].includes(rule.kind))trjFail('Choose a supported observed event rule');
    const role={lane_change:'lane',speed_below:'speed',acceleration_below:'acceleration',headway_below:'time_headway'}[rule.kind];
    if(!fields[role])trjFail('The '+rule.kind+' rule needs its source column');
    const threshold=rule.kind==='lane_change'?null:Number(rule.threshold),duration=Number(rule.minimum_duration_ms??0);
    const before=Number(rule.before_ms??5000),after=Number(rule.after_ms??5000);
    if((threshold!==null&&!Number.isFinite(threshold))||![duration,before,after].every(v=>Number.isFinite(v)&&v>=0))trjFail('Event thresholds, observed durations and context windows must be finite');
    return {id:'rule-'+(index+1),kind:rule.kind,threshold,minimum_duration_ms:duration,before_ms:before,after_ms:after};
  });
  return {title:trjRequired(input.title,'Mapping title'),table_id:table.id,run_id:input.run_id||null,
    entity_fields:choose(input.entity_fields,'vehicle identity'),site_fields:choose(input.site_fields||[],'site',true),
    recording_fields:choose(input.recording_fields||[],'recording identity',true),fields,units:unit,
    time_origin:input.time_origin,step_ms:step,tolerance_ms:tolerance,frame_step:frameStep,
    missing_values:[...new Set((input.missing_values||['','NA','N/A','NaN']).map(String))],
    headway_requires_leader:input.headway_requires_leader===true,zero_leader_values:(input.zero_leader_values||['0']).map(String),
    rules,note:String(input.note||''),source_binding:trjBinding(project,table.id,input.run_id||null)};
}
export function ngsimTrajectoryMapping(project,tableId,runId=null) {
  return trjNormalizeMapping({title:'Published NGSIM fields and observed event definitions',table_id:tableId,run_id:runId,
    entity_fields:['vehicle_id'],site_fields:['location'],recording_fields:[],
    fields:{time:'global_time',frame:'frame_id',x:'local_x',y:'local_y',speed:'v_vel',acceleration:'v_acc',lane:'lane_id',
      length:'v_length',width:'v_width',leader:'preceding',space_headway:'space_headway',time_headway:'time_headway'},
    units:{distance:'ft',speed:'ft/s',acceleration:'ft/s2',timestamp:'ms',headway:'s'},time_origin:'unix',
    step_ms:100,tolerance_ms:0.01,frame_step:1,missing_values:['','NA','N/A','NaN'],
    headway_requires_leader:true,zero_leader_values:['0'],
    rules:[{kind:'lane_change',before_ms:5000,after_ms:5000},
      {kind:'acceleration_below',threshold:-2,minimum_duration_ms:500,before_ms:5000,after_ms:5000},
      {kind:'speed_below',threshold:2,minimum_duration_ms:1000,before_ms:3000,after_ms:3000}],
    note:'Use the published source values and explicit SI conversions. Separate repeated vehicle identities whenever the actual timestamp or frame sequence breaks. Context tracks must overlap in original time and share the configured site and recording identity. Thresholds select observed windows for review.'},project);
}
function trjMetric(raw,missing) {return missing.includes(String(raw).trim())?null:trjNumber(raw);}
function trjTrackLabel(track) {return track.entity.join(' / ')+' · '+track.site.join(' / ')+' · segment '+track.segment;}
export function trajectoryIndex(project,mappingId) {
  const mapping=trjFind(trjState(project).mappings,mappingId,'Trajectory mapping');trjCheckBinding(project,mapping);
  const table=trjTable(project,mapping.table_id),columns=new Map(table.headers.map((field,index)=>[field,index]));
  const run=mapping.run_id?trjFind(project.runs,mapping.run_id,'Saved analysis'):null;
  const results=run?new Map(run.analysis.rows.map(row=>[row.row_id,row])):null;
  const groups=new Map(),findings=[];let eligible=0,excluded=0,unplotted=0;
  const raw=(row,field)=>field===null?'':String(row.cells[columns.get(field)]??'').trim();
  const factor=kind=>trjFactors[kind][mapping.units[kind]];
  for(const row of table.rows){
    const analysis=results?.get(row.id);
    if(results&&analysis?.status!=='INCLUDED'){excluded++;continue;}
    eligible++;
    const entity=mapping.entity_fields.map(field=>raw(row,field)),site=mapping.site_fields.map(field=>raw(row,field)),recording=mapping.recording_fields.map(field=>raw(row,field));
    const values={};for(const role of trjFieldNames){
      const field=mapping.fields[role];let value=field?trjMetric(raw(row,field),mapping.missing_values):null;
      if(analysis?.measures?.[field]&&analysis.measures[field].status!=='VALID')value=null;
      values[role]=value;
    }
    const time=values.time===null?null:values.time*factor('timestamp'),x=values.x===null?null:values.x*factor('distance'),y=values.y===null?null:values.y*factor('distance');
    if([...entity,...site,...recording].some(value=>!value)||time===null||!Number.isFinite(time)||Math.abs(time)>Number.MAX_SAFE_INTEGER||x===null||y===null||!Number.isFinite(x)||!Number.isFinite(y)||mapping.fields.frame&&(values.frame===null||!Number.isSafeInteger(values.frame))){
      unplotted++;findings.push({kind:'UNPLOTTED_SOURCE_ROW',row_id:row.id,record:row.record,detail:'The configured identity, time, coordinate or frame is unavailable.'});continue;
    }
    const leader=raw(row,mapping.fields.leader),hasLeader=!mapping.headway_requires_leader||mapping.fields.leader!==null&&leader!==''&&!mapping.zero_leader_values.includes(leader)&&!mapping.missing_values.includes(leader);
    const metric=(role,kind)=>values[role]===null?null:values[role]*factor(kind);
    const point={row_id:row.id,record:row.record,time_ms:time,frame:values.frame,x_m:x,y_m:y,
      speed_m_s:metric('speed','speed'),acceleration_m_s2:metric('acceleration','acceleration'),
      lane:raw(row,mapping.fields.lane)||null,length_m:metric('length','distance'),width_m:metric('width','distance'),leader:leader||null,
      space_headway_m:hasLeader?metric('space_headway','distance'):null,time_headway_s:hasLeader?metric('time_headway','headway'):null,
      headway_available:hasLeader,analysis_row_status:analysis?.status||'ORIGINAL_SOURCE'};
    for(const field of ['speed_m_s','acceleration_m_s2','length_m','width_m','space_headway_m','time_headway_s'])if(point[field]!==null&&!Number.isFinite(point[field])){point[field]=null;findings.push({kind:'NONFINITE_CONVERSION',row_id:row.id,field});}
    const key=trjCanonical([site,recording,entity]);if(!groups.has(key))groups.set(key,{entity,site,recording,points:[]});
    groups.get(key).points.push(point);
  }
  const tracks=[];
  for(const group of groups.values()){
    group.points.sort((a,b)=>a.time_ms-b.time_ms||(a.frame??0)-(b.frame??0)||a.record-b.record);
    let current=null,segment=0;
    for(const point of group.points){
      const previous=current?.points.at(-1);let reason=null;
      if(previous){
        const delta=point.time_ms-previous.time_ms;
        if(delta<=0)reason='REPEATED_TIME';
        else if(Math.abs(delta-mapping.step_ms)>mapping.tolerance_ms)reason='TIME_SEQUENCE_BREAK';
        else if(mapping.fields.frame&&point.frame-previous.frame!==mapping.frame_step)reason='FRAME_SEQUENCE_BREAK';
      }
      if(!current||reason){
        if(reason)findings.push({kind:reason,row_id:point.row_id,previous_row_id:previous.row_id,delta_ms:point.time_ms-previous.time_ms,frame_delta:mapping.fields.frame?point.frame-previous.frame:null});
        current={id:'track-'+mapping.id+'-'+encodeURIComponent(point.row_id),entity:group.entity,site:group.site,recording:group.recording,segment:++segment,points:[]};tracks.push(current);
      }
      current.points.push(point);
    }
  }
  tracks.forEach(track=>{
    track.first_time_ms=track.points[0].time_ms;track.last_time_ms=track.points.at(-1).time_ms;track.samples=track.points.length;
    track.duration_ms=track.last_time_ms-track.first_time_ms;track.label=trjTrackLabel(track);
  });
  tracks.sort((a,b)=>a.first_time_ms-b.first_time_ms||a.label.localeCompare(b.label));
  return {schema:'tjlabs.observed-trajectory-index/v1',mapping_id:mapping.id,source_binding:mapping.source_binding,
    source_rows:table.rows.length,eligible_rows:eligible,analysis_excluded_rows:excluded,unplotted_rows:unplotted,
    plotted_rows:tracks.reduce((sum,track)=>sum+track.samples,0),tracks,findings,
    conversion:{coordinates:'m',speed:'m/s',acceleration:'m/s²',headway:'s',time:'original timestamp in ms'},
    time_origin:mapping.time_origin,step_ms:mapping.step_ms};
}
export function trajectoryIndexSummary(index) {
  return {...index,tracks:index.tracks.map(({points,...track})=>track)};
}
export function trajectoryCandidates(project,mappingId,index=trajectoryIndex(project,mappingId)) {
  const mapping=trjFind(trjState(project).mappings,mappingId,'Mapping'),candidates=[];
  const push=(rule,track,start,end,detail)=>{
    const first=track.points[start],last=track.points[end];
    if(last.time_ms-first.time_ms+mapping.tolerance_ms<rule.minimum_duration_ms)return;
    candidates.push({id:'event-'+trajectoryDigest([mapping.id,rule.id,track.id,first.row_id,last.row_id]).slice(0,32),
      mapping_id:mapping.id,rule_id:rule.id,kind:rule.kind,title:detail,focus_track_id:track.id,
      anchor_row_id:first.row_id,last_event_row_id:last.row_id,event_start_ms:first.time_ms,event_end_ms:last.time_ms,
      start_ms:Math.max(track.first_time_ms,first.time_ms-rule.before_ms),end_ms:Math.min(track.last_time_ms,last.time_ms+rule.after_ms),
      event_samples:end-start+1,observed_duration_ms:last.time_ms-first.time_ms,threshold:rule.threshold,entity:track.entity,site:track.site});
  };
  for(const track of index.tracks)for(const rule of mapping.rules){
    if(rule.kind==='lane_change'){
      for(let i=1;i<track.points.length;i++)if(track.points[i-1].lane!==null&&track.points[i].lane!==null&&track.points[i-1].lane!==track.points[i].lane)
        push(rule,track,i,i,'Published lane '+track.points[i-1].lane+' → '+track.points[i].lane);
      continue;
    }
    const metric={speed_below:'speed_m_s',acceleration_below:'acceleration_m_s2',headway_below:'time_headway_s'}[rule.kind];
    const label={speed_below:'Speed',acceleration_below:'Acceleration',headway_below:'Time headway'}[rule.kind];
    let first=null;
    for(let i=0;i<=track.points.length;i++){
      const value=track.points[i]?.[metric],match=value!==undefined&&value!==null&&value<=rule.threshold;
      if(match&&first===null)first=i;
      if(!match&&first!==null){push(rule,track,first,i-1,label+' ≤ '+rule.threshold);first=null;}
    }
  }
  return candidates.sort((a,b)=>a.event_start_ms-b.event_start_ms||a.id.localeCompare(b.id));
}
function trjObservedTracks(index,input) {
  const focus=trjFind(index.tracks,input.focus_track_id,'Original focus track'),start=Number(input.start_ms),end=Number(input.end_ms);
  if(!Number.isFinite(start)||!Number.isFinite(end)||start>end||start<focus.first_time_ms||end>focus.last_time_ms)trjFail('Choose a window inside the selected original track');
  const focusPoints=focus.points.filter(point=>point.time_ms>=start&&point.time_ms<=end);
  if(!focusPoints.length)trjFail('The window contains no original focus samples');
  const sameContext=track=>trjSame(track.site,focus.site)&&trjSame(track.recording,focus.recording)&&track.first_time_ms<=end&&track.last_time_ms>=start;
  let ids;
  if(input.context_track_ids!==undefined){
    if(!Array.isArray(input.context_track_ids)||new Set(input.context_track_ids).size!==input.context_track_ids.length)trjFail('Choose distinct original context tracks');
    ids=[...new Set([focus.id,...input.context_track_ids])];
    for(const id of ids){const track=trjFind(index.tracks,id,'Context track');if(!sameContext(track))trjFail('Context tracks must overlap the original time and share the configured site and recording identity');}
  }else ids=index.tracks.filter(sameContext).map(track=>track.id);
  return {focus,start,end,tracks:ids.map(id=>{
    const track=trjFind(index.tracks,id,'Track'),points=track.points.filter(point=>point.time_ms>=start&&point.time_ms<=end);
    return {id,entity:track.entity,site:track.site,recording:track.recording,segment:track.segment,
      row_ids:points.map(point=>point.row_id),first_time_ms:points[0]?.time_ms??null,last_time_ms:points.at(-1)?.time_ms??null,
      samples:points.length,metrics:Object.fromEntries(['speed_m_s','acceleration_m_s2','time_headway_s'].map(field=>[field,summarize(points.map(point=>point[field]).filter(value=>value!==null))]))};
  }).filter(track=>track.samples)};
}
function trjScenario(project,state,input,at,operationId,index=null,previousId=null) {
  const mapping=trjFind(state.mappings,input.mapping_id,'Mapping');index=index||trajectoryIndex(project,mapping.id);
  const observed=trjObservedTracks(index,input);
  let previous=null;if(previousId){
    previous=trjFind(state.scenarios,previousId,'Previous scenario');
    if(state.scenarios.some(item=>item.series_id===previous.series_id&&item.edition>previous.edition))trjFail('This scenario has a later saved edition. Reopen it and compare your draft before saving.','trajectory_conflict');
    const oldMapping=trjFind(state.mappings,previous.mapping_id,'Previous mapping');if(oldMapping.table_id!==mapping.table_id||oldMapping.source_binding.source_sha256!==mapping.source_binding.source_sha256)trjFail('Continue a scenario only with its original source table');
  }
  const id='trajectory-scenario-'+(state.scenarios.length+1),candidate=input.candidate_id?trajectoryCandidates(project,mapping.id,index).find(item=>item.id===input.candidate_id):null;
  if(input.candidate_id&&!candidate)trjFail('The selected event does not belong to this mapping edition');
  if(candidate&&(candidate.focus_track_id!==input.focus_track_id||candidate.start_ms!==observed.start||candidate.end_ms!==observed.end))trjFail('An event-bound scenario must retain its original event window; save a manually selected window for an edited interval');
  return {id,series_id:previous?.series_id||id,edition:previous?previous.edition+1:1,previous_id:previous?.id||null,
    mapping_id:mapping.id,source_binding:trjCopy(mapping.source_binding),title:trjRequired(input.title,'Scenario title'),
    focus_track_id:observed.focus.id,requested_start_ms:observed.start,requested_end_ms:observed.end,
    first_focus_time_ms:observed.tracks.find(track=>track.id===observed.focus.id).first_time_ms,
    last_focus_time_ms:observed.tracks.find(track=>track.id===observed.focus.id).last_time_ms,
    tracks:observed.tracks,candidate:trjCopy(candidate),note:String(input.note||''),at,operation_id:operationId};
}
export function previewTrajectoryScenario(project,input,index=null) {
  return trjScenario(project,trjState(project),input,project.updated_at||project.created_at,'trajectory-preview',index,null);
}
export function trajectoryScenarioRows(project,scenarioId,index=null) {
  const state=trjState(project),scenario=trjFind(state.scenarios,scenarioId,'Saved scenario');
  index=index||trajectoryIndex(project,scenario.mapping_id);
  return scenario.tracks.flatMap(saved=>{
    const track=trjFind(index.tracks,saved.id,'Original scenario track'),ids=new Set(saved.row_ids);
    const rows=track.points.filter(point=>ids.has(point.row_id));
    if(rows.length!==saved.row_ids.length)trjFail('A saved scenario source row is unavailable','trajectory_source_changed');
    return rows.map(point=>({...point,track_id:track.id,entity:track.entity,site:track.site,recording:track.recording,focus:track.id===scenario.focus_track_id}));
  }).sort((a,b)=>a.time_ms-b.time_ms||a.track_id.localeCompare(b.track_id));
}
export function trajectoryFrame(index,scenario,timeMs) {
  return scenario.tracks.map(saved=>{
    const track=trjFind(index.tracks,saved.id,'Original track'),ids=new Set(saved.row_ids);
    let low=0,high=track.points.length-1,found=null;
    while(low<=high){const middle=(low+high)>>>1,point=track.points[middle];if(point.time_ms===timeMs){found=point;break;}if(point.time_ms<timeMs)low=middle+1;else high=middle-1;}
    return {track_id:track.id,label:track.label,focus:track.id===scenario.focus_track_id,available:!!found&&ids.has(found.row_id),
      point:found&&ids.has(found.row_id)?found:null};
  });
}
export function applyTrajectoryCommand(project,command) {
  const p=reopenTrajectoryProject(project),c=trjCopy(command),operationId=trjRequired(c.operation_id,'Original operation ID');
  const payload=trjCanonical({...c,at:undefined}),existing=p.operations.find(item=>item.id===operationId);
  if(existing){if(existing.payload!==payload)trjFail('The original operation ID has different input','trajectory_request_changed');return {project,output:trjCopy(existing.output),reused:true};}
  const at=trjRequired(c.at,'Operation time');p.trajectory=p.trajectory||trjEmpty();const state=p.trajectory;let output;
  if(c.type==='TRAJECTORY_MAP'){
    const mapping=trjNormalizeMapping(c.mapping,p);
    if(c.previous_id){const previous=trjFind(state.mappings,c.previous_id,'Previous mapping');if(previous.table_id!==mapping.table_id)trjFail('Continue this mapping with its original source table');}
    const id='trajectory-map-'+(state.mappings.length+1);state.mappings.push({...mapping,id,at,previous_id:c.previous_id||null});output={mapping_id:id};
  }else if(c.type==='TRAJECTORY_SCENARIO'){
    const scenario=trjScenario(p,state,c.scenario,at,operationId,null,c.previous_id||null);state.scenarios.push(scenario);output={scenario_id:scenario.id,series_id:scenario.series_id,edition:scenario.edition};
  }else if(c.type==='TRAJECTORY_BATCH'){
    const mapping=trjFind(state.mappings,c.mapping_id,'Mapping'),index=trajectoryIndex(p,mapping.id),candidates=trajectoryCandidates(p,mapping.id,index);
    if(!Array.isArray(c.candidate_ids)||!c.candidate_ids.length||new Set(c.candidate_ids).size!==c.candidate_ids.length)trjFail('Select distinct observed event candidates');
    const chosen=c.candidate_ids.map(id=>candidates.find(candidate=>candidate.id===id)||trjFail('An event candidate belongs to another mapping edition'));
    const ids=[];for(const candidate of chosen){
      const scenario=trjScenario(p,state,{mapping_id:mapping.id,title:(c.title_prefix?String(c.title_prefix)+' · ':'')+candidate.entity.join(' / ')+' · '+candidate.title,
        focus_track_id:candidate.focus_track_id,start_ms:candidate.start_ms,end_ms:candidate.end_ms,candidate_id:candidate.id,note:String(c.note||'')},at,operationId,index);
      state.scenarios.push(scenario);ids.push(scenario.id);
    }
    output={scenario_ids:ids,count:ids.length,mapping_id:mapping.id};
  }else if(c.type==='TRAJECTORY_REVIEW'){
    const scenario=trjFind(state.scenarios,c.scenario_id,'Saved scenario');
    if(!['ACCEPTED','CORRECTIONS_REQUESTED'].includes(c.status))trjFail('Choose a scenario review decision');
    const id='trajectory-review-'+(state.reviews.length+1);
    state.reviews.push({id,scenario_id:scenario.id,scenario_sha256:trajectoryDigest(scenario),status:c.status,reviewer:trjRequired(c.reviewer,'Reviewer'),note:trjRequired(c.note,'Review note'),at});
    output={review_id:id,scenario_id:scenario.id};
  }else if(c.type==='TRAJECTORY_HANDOVER'){
    const scenario=trjFind(state.scenarios,c.scenario_id,'Saved scenario'),review=[...state.reviews].reverse().find(item=>item.scenario_id===scenario.id);
    if(!review||review.status!=='ACCEPTED')trjFail('Accept this exact scenario edition before freezing its handover','trajectory_review');
    const id='trajectory-handover-'+(state.handovers.length+1);state.handovers.push({id,scenario_id:scenario.id,review_id:review.id,title:trjRequired(c.title,'Handover title'),at,project_revision:p.revision,project_context:trjCopy(trjProjectContext(p))});output={handover_id:id,scenario_id:scenario.id};
  }else trjFail('Unknown trajectory operation');
  p.revision++;p.updated_at=at;p.operations.push({id:operationId,type:c.type,at,payload,output:trjCopy(output)});
  return {project:p,output,reused:false};
}
export function materializeTrajectoryHandover(project,handoverId) {
  reopenTrajectoryProject(project);
  const state=trjState(project),handover=trjFind(state.handovers,handoverId,'Trajectory handover'),scenario=trjFind(state.scenarios,handover.scenario_id,'Saved scenario'),mapping=trjFind(state.mappings,scenario.mapping_id,'Mapping');
  const review=trjFind(state.reviews,handover.review_id,'Scenario review'),table=trjTable(project,mapping.table_id);
  const value={schema:'tjlabs.observed-scenario-handover/v1',...trjCopy(handover),project_context:trjCopy(handover.project_context||trjProjectContext(project)),
    scenario:trjCopy(scenario),mapping:trjCopy(mapping),review:trjCopy(review),table:trjCopy(table),
    analysis_run:mapping.run_id?trjCopy(trjFind(project.runs,mapping.run_id,'Saved source analysis')):null,
    observed_rows:trajectoryScenarioRows(project,scenario.id),
    method:'Only original source observations are replayed. Vehicle identities are segmented at configured time or frame breaks. Context uses matching site/recording fields and original overlapping times. Threshold candidates use published measures with explicit unit conversion. No intervening positions are interpolated.'};
  return {...value,sha256:trajectoryDigest(value)};
}
export function inspectTrajectoryHandover(input) {
  const value=typeof input==='string'?JSON.parse(input):trjCopy(input),sha=value.sha256;delete value.sha256;
  if(value.schema!=='tjlabs.observed-scenario-handover/v1'||trajectoryDigest(value)!==sha)trjFail('The complete scenario handover bytes do not match its saved digest');
  if(value.review.status!=='ACCEPTED'||value.review.scenario_id!==value.scenario.id||value.review.scenario_sha256!==trajectoryDigest(value.scenario))trjFail('The handover review belongs to a different scenario edition');
  const source=value.mapping.source_binding;
  if(source.table_id!==value.table.id||source.project_id!==value.project_context.id||trajectoryDigest(value.table.original_text)!==source.source_sha256||
    trajectoryDigest({headers:value.table.headers,rows:value.table.rows})!==source.records_sha256||trajectoryDigest(trjSourceMetadata(value.table))!==source.source_metadata_sha256||(value.analysis_run?trajectoryDigest(value.analysis_run):null)!==source.run_sha256)
    trjFail('The retained source or saved analysis differs from the handover mapping');
  if(!trjSame(value.scenario.source_binding,source))trjFail('The scenario and mapping have different source bindings');
  const retained=trjHandoverContext(value),index=trajectoryIndex(retained,value.mapping.id);
  const observed=trjObservedTracks(index,{focus_track_id:value.scenario.focus_track_id,start_ms:value.scenario.requested_start_ms,end_ms:value.scenario.requested_end_ms,context_track_ids:value.scenario.tracks.map(track=>track.id)});
  const trackOrder=(a,b)=>a.id.localeCompare(b.id);
  if(!trjSame([...observed.tracks].sort(trackOrder),[...value.scenario.tracks].sort(trackOrder))||!trjSame(trajectoryScenarioRows(retained,value.scenario.id,index),value.observed_rows))
    trjFail('The selected observations or descriptive metrics differ from the retained original source');
  return {...value,sha256:sha};
}
function trjHandoverContext(h) {
  return {...trjCopy(h.project_context),tables:[h.table],runs:h.analysis_run?[h.analysis_run]:[],
    trajectory:{schema:TRAJECTORY_SCHEMA,mappings:[h.mapping],scenarios:[h.scenario],reviews:[h.review],
      handovers:[{id:h.id,scenario_id:h.scenario.id,review_id:h.review.id,title:h.title,at:h.at,project_revision:h.project_revision,project_context:trjCopy(h.project_context)}]}};
}
export function trajectoryHandoverContext(input) {return trjHandoverContext(inspectTrajectoryHandover(input));}
function trjCSV(headers,rows) {
  const cell=value=>{let text=value===null||value===undefined?'':typeof value==='object'?trjCanonical(value):String(value);
    if(typeof value==='string'&&/^[\t\r\n ]*[=+@-]/.test(text)&&trjNumber(text)===null)text="'"+text;
    return '"'+text.replace(/"/g,'""')+'"';};
  return [headers,...rows].map(row=>row.map(cell).join(',')).join('\r\n')+'\r\n';
}
export function trajectoryRowsCSV(project,scenarioId) {
  const names=['row_id','record','track_id','focus','entity','site','recording','time_ms','frame','x_m','y_m','speed_m_s','acceleration_m_s2','lane','leader','space_headway_m','time_headway_s','headway_available'];
  return trjCSV(names,trajectoryScenarioRows(project,scenarioId).map(row=>names.map(name=>row[name])));
}
export function trajectorySourceCSV(project,scenarioId) {
  const scenario=trjFind(trjState(project).scenarios,scenarioId,'Scenario'),mapping=trjFind(trjState(project).mappings,scenario.mapping_id,'Mapping'),table=trjTable(project,mapping.table_id),ids=new Set(scenario.tracks.flatMap(track=>track.row_ids));
  return trjCSV(['original_row_id','original_record',...table.headers],table.rows.filter(row=>ids.has(row.id)).map(row=>[row.id,row.record,...row.cells]));
}
export function trajectoryReport(input) {
  const h=inspectTrajectoryHandover(input),clean=value=>String(value??'').replace(/[|\r\n]+/g,' '),fmt=value=>value===null?'—':Number(value).toFixed(4);
  const time=value=>h.mapping.time_origin==='unix'?new Date(value).toISOString():String(value)+' ms';
  return '# '+h.title+'\n\nStudy: '+h.project_context.title+'\n\nOriginal case: '+(h.project_context.case_id||'Unassigned')+'\n\nSource: '+h.table.filename+'\n\n'+h.table.source_url+'\n\n'+h.table.source_note+'\n\nLicense: '+h.table.license+
    '\n\n## Reviewed scenario\n\n'+h.scenario.title+'; edition '+h.scenario.edition+'.\n\nOriginal window: '+time(h.scenario.requested_start_ms)+' to '+time(h.scenario.requested_end_ms)+'.\n\n'+h.scenario.note+
    '\n\nFocus track: '+h.scenario.focus_track_id+'\n\nReviewed by '+h.review.reviewer+' at '+h.review.at+': '+h.review.note+
    '\n\n## Original observed tracks\n\n| Vehicle | Site | Samples | First original time | Last original time | Mean speed (m/s) | Mean acceleration (m/s²) |\n| --- | --- | ---: | --- | --- | ---: | ---: |\n'+
    h.scenario.tracks.map(track=>'| '+[track.entity.join(' / '),track.site.join(' / '),track.samples,time(track.first_time_ms),time(track.last_time_ms),fmt(track.metrics.speed_m_s.mean),fmt(track.metrics.acceleration_m_s2.mean)].map(clean).join(' | ')+' |').join('\n')+
    '\n\n## Mapping and source\n\n'+h.mapping.note+'\n\n'+h.method+'\n\nSource SHA256: '+h.mapping.source_binding.source_sha256+
    '\n\nOriginal table: '+h.table.id+'; original analysis: '+(h.analysis_run?.id||'All source rows')+'.\n\nScenario digest: '+h.review.scenario_sha256+
    '\n\nComplete handover digest: '+h.sha256+'\n\nThe full study backup retains all mapping and scenario editions for continued work. This handover retains the selected reviewed scenario and complete original source table.\n';
}
export function trajectoryExport(project,command) {
  const kind=command.kind;
  if(kind==='trajectory_index')return JSON.stringify(trajectoryIndexSummary(trajectoryIndex(project,command.mapping_id)),null,2)+'\n';
  if(kind==='trajectory_candidates')return JSON.stringify(trajectoryCandidates(project,command.mapping_id),null,2)+'\n';
  if(kind==='trajectory_rows')return trajectoryRowsCSV(project,command.scenario_id);
  if(kind==='trajectory_source')return trajectorySourceCSV(project,command.scenario_id);
  if(kind==='trajectory_handover')return JSON.stringify(materializeTrajectoryHandover(project,command.handover_id),null,2)+'\n';
  if(kind==='trajectory_report')return trajectoryReport(materializeTrajectoryHandover(project,command.handover_id));
  trjFail('Choose a supported trajectory export');
}
