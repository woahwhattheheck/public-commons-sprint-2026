
(() => {
  const node=id=>document.getElementById('trj-'+id), esc=escape;
  const state={
    contextKey:null,actualProjectId:null,mappingId:'',scenarioId:'',candidateId:null,draftParentId:null,
    index:null,indexKey:null,events:[],selectedEvents:new Set(),preview:null,previewSaved:false,
    points:[],allPoints:[],frame:0,playing:false,animation:null,pages:{tracks:0,events:0,findings:0},
    rules:[],received:null,formDirty:false,restoring:false
  };
  const kinds={lane_change:'Published lane change',speed_below:'Speed at or below threshold',acceleration_below:'Acceleration at or below threshold',headway_below:'Time headway at or below threshold'};
  const roles={time:'Timestamp',frame:'Frame ID',x:'Lateral x',y:'Longitudinal y',speed:'Speed',acceleration:'Acceleration',lane:'Published lane ID',length:'Vehicle length',width:'Vehicle width',leader:'Published leader ID',space_headway:'Space headway',time_headway:'Time headway'};
  const metricLabels={speed_m_s:'Speed (m/s)',acceleration_m_s2:'Acceleration (m/s²)',time_headway_s:'Time headway (s)',space_headway_m:'Space headway (m)'};
  const doc=()=>state.received?.context||project;
  const work=()=>doc()?.trajectory||{mappings:[],scenarios:[],reviews:[],handovers:[]};
  const mapping=()=>work().mappings.find(item=>item.id===state.mappingId);
  const savedScenario=()=>work().scenarios.find(item=>item.id===state.scenarioId);
  const copy=value=>JSON.parse(JSON.stringify(value));
  const multi=id=>[...node(id).selectedOptions].map(option=>option.value);
  const choose=(id,values)=>{for(const option of node(id).options)option.selected=values.includes(option.value);};
  const format=(value,digits=3)=>value===null||value===undefined?'—':Number(value).toLocaleString(undefined,{maximumFractionDigits:digits});
  const timeLabel=value=>mapping()?.time_origin==='unix'?new Date(value).toISOString():format(value,3)+' ms from the source origin';
  const options=(items,label,empty)=> (empty===undefined?'':'<option value="">'+esc(empty)+'</option>')+items.map(item=>'<option value="'+esc(item.id)+'">'+esc(label(item))+'</option>').join('');
  const setOptions=(id,items,label,empty,selectedValue=node(id).value)=>{node(id).innerHTML=options(items,label,empty);if([...node(id).options].some(option=>option.value===selectedValue))node(id).value=selectedValue;};
  const key=kind=>'tjlabs.study-trajectory.'+kind+'.'+encodeURIComponent(project?.id||'');
  const status=(message,error=false)=>{node('status').textContent=message||'';node('status').dataset.kind=error?'error':'info';};
  const pending=()=>{const raw=project&&localStorage.getItem(key('pending'));return raw?JSON.parse(raw):null;};
  const tableHtml=(headers,rows)=>'<table><thead><tr>'+headers.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody></table>';
  const cell=value=>'<td>'+esc(value)+'</td>';
  function page(items,kind){
    const size=60,count=Math.max(1,Math.ceil(items.length/size));
    state.pages[kind]=Math.max(0,Math.min(state.pages[kind],count-1));
    node(kind+'-page').textContent=items.length?(state.pages[kind]*size+1)+'–'+Math.min(items.length,(state.pages[kind]+1)*size)+' of '+items.length:'0 records';
    node(kind+'-prev').disabled=operationRunning||state.pages[kind]===0;
    node(kind+'-next').disabled=operationRunning||state.pages[kind]+1>=count;
    return items.slice(state.pages[kind]*size,(state.pages[kind]+1)*size);
  }
  function view(name){stop();showStudyWorkspace(name);if(name==='trajectory')sync();}
  document.addEventListener('study-view-changed',event=>{if(event.detail!=='trajectory')stop();});
  function bind(id,fn){wire('trj-'+id,async()=>{stop();status('');try{await fn();}catch(error){if(node('status').dataset.kind!=='error')status(error.message,true);throw error;}});}
  function readRules(){
    return [...node('rules').querySelectorAll('[data-trj-rule]')].map(row=>{
      const value=field=>row.querySelector('[data-rule-field="'+field+'"]').value;
      return {kind:value('kind'),threshold:Number(value('threshold')),minimum_duration_ms:Number(value('duration'))*1000,before_ms:Number(value('before'))*1000,after_ms:Number(value('after'))*1000};
    });
  }
  function renderRules(rules){
    state.rules=copy(rules);
    node('rules').innerHTML=rules.map((rule,index)=>'<div class="trj-rule" data-trj-rule="'+index+'"><div class="trj-field-grid"><label>Event<select data-rule-field="kind">'+Object.entries(kinds).map(([value,label])=>'<option value="'+value+'"'+(value===rule.kind?' selected':'')+'>'+esc(label)+'</option>').join('')+'</select></label><label>Threshold (SI)<input type="number" step="any" data-rule-field="threshold" value="'+esc(rule.threshold??0)+'"></label><label>Minimum observed span (s)<input type="number" min="0" step="any" data-rule-field="duration" value="'+esc((rule.minimum_duration_ms||0)/1000)+'"></label><label>Context before (s)<input type="number" min="0" step="any" data-rule-field="before" value="'+esc((rule.before_ms??5000)/1000)+'"></label><label>Context after (s)<input type="number" min="0" step="any" data-rule-field="after" value="'+esc((rule.after_ms??5000)/1000)+'"></label><div class="actions"><button type="button" data-rule-remove="'+index+'">Remove event</button></div></div></div>').join('');
  }
  function sourceColumns(tableId){
    const table=doc()?.tables.find(item=>item.id===tableId),headers=table?.headers||[];
    for(const id of ['entity','site','recording'])node(id).innerHTML=headers.map(header=>'<option value="'+esc(header)+'">'+esc(header)+'</option>').join('');
    node('columns').innerHTML=Object.entries(roles).map(([role,label])=>'<label>'+esc(label)+'<select id="trj-column-'+role+'"><option value="">Choose a source column</option>'+headers.map(header=>'<option value="'+esc(header)+'">'+esc(header)+'</option>').join('')+'</select></label>').join('');
    setOptions('run',(doc()?.runs||[]).filter(run=>run.analysis.table_id===tableId),run=>run.id+' · '+run.at,'All original source records','');
  }
  function emptyMapping(tableId){
    return {title:'Observed source trajectories',table_id:tableId,run_id:null,entity_fields:[],site_fields:[],recording_fields:[],
      fields:{},units:{distance:'m',speed:'m/s',acceleration:'m/s2',timestamp:'ms',headway:'s'},time_origin:'elapsed',
      step_ms:100,tolerance_ms:0.01,frame_step:1,missing_values:['','NA','N/A','NaN'],zero_leader_values:['0'],
      headway_requires_leader:false,rules:[],note:''};
  }
  function fillMapping(value){
    sourceColumns(value.table_id);node('table').value=value.table_id;node('run').value=value.run_id||'';
    node('map-title').value=value.title;choose('entity',value.entity_fields);choose('site',value.site_fields);choose('recording',value.recording_fields);
    for(const role of Object.keys(roles))node('column-'+role).value=value.fields[role]||'';
    for(const [kind,unit] of Object.entries(value.units))node('unit-'+kind).value=unit;
    node('time-origin').value=value.time_origin;node('step').value=value.step_ms;node('tolerance').value=value.tolerance_ms;node('frame-step').value=value.frame_step;
    node('missing').value=value.missing_values.filter(Boolean).join(',');node('zero-leader').value=value.zero_leader_values.join(',');
    node('leader-required').checked=value.headway_requires_leader;node('map-note').value=value.note;renderRules(value.rules);
  }
  function readMapping(){
    return {title:node('map-title').value,table_id:node('table').value,run_id:node('run').value||null,
      entity_fields:multi('entity'),site_fields:multi('site'),recording_fields:multi('recording'),
      fields:Object.fromEntries(Object.keys(roles).map(role=>[role,node('column-'+role).value||null])),
      units:Object.fromEntries(['distance','speed','acceleration','timestamp','headway'].map(kind=>[kind,node('unit-'+kind).value])),
      time_origin:node('time-origin').value,step_ms:Number(node('step').value),tolerance_ms:Number(node('tolerance').value),frame_step:Number(node('frame-step').value),
      missing_values:['',...node('missing').value.split(',').map(value=>value.trim()).filter(Boolean)],zero_leader_values:node('zero-leader').value.split(',').map(value=>value.trim()),
      headway_requires_leader:node('leader-required').checked,rules:readRules(),note:node('map-note').value};
  }
  function getIndex(){
    const m=mapping();if(!m){state.index=null;state.indexKey=null;state.events=[];return null;}
    const cache=doc().id+'|'+m.id+'|'+m.source_binding.records_sha256+'|'+m.source_binding.run_sha256;
    if(cache!==state.indexKey){state.index=trajectoryIndex(doc(),m.id);state.events=trajectoryCandidates(doc(),m.id,state.index);state.indexKey=cache;state.selectedEvents.clear();state.pages={tracks:0,events:0,findings:0};}
    return state.index;
  }
  function filteredTracks(){
    const query=node('track-filter').value.toLowerCase().trim();
    return (state.index?.tracks||[]).filter(track=>!query||[track.label,...track.recording,track.id].join(' ').toLowerCase().includes(query));
  }
  function filteredEvents(){return state.events.filter(event=>!node('event-filter').value||event.kind===node('event-filter').value);}
  function renderInventory(){
    const index=getIndex();
    node('coverage').innerHTML=index?[['Source rows',index.source_rows],['Plotted rows',index.plotted_rows],['Analysis exclusions',index.analysis_excluded_rows],['Unavailable coordinates',index.unplotted_rows],['Continuous tracks',index.tracks.length],['Observed events',state.events.length]].map(([label,value])=>'<div><strong>'+format(value,0)+'</strong><span>'+esc(label)+'</span></div>').join(''):'';
    node('track-table').innerHTML=tableHtml(['Original track','Samples','Source interval'],page(filteredTracks(),'tracks').map(track=>'<tr class="trj-inventory-row" aria-current="'+String(node('focus').value===track.id)+'"><td><button data-trj-track="'+esc(track.id)+'">'+esc(track.label)+'</button></td>'+cell(track.samples)+'<td class="trj-code">'+esc(timeLabel(track.first_time_ms))+'<br>'+esc(timeLabel(track.last_time_ms))+'</td></tr>'));
    node('event-table').innerHTML=tableHtml(['Select','Observed event','Vehicle','Observed span'],page(filteredEvents(),'events').map(event=>'<tr><td><input type="checkbox" data-trj-event-select="'+esc(event.id)+'" aria-label="Select '+esc(event.title)+'"'+(state.selectedEvents.has(event.id)?' checked':'')+'></td><td><button data-trj-event="'+esc(event.id)+'">'+esc(event.title)+'</button><div class="trj-code">'+esc(timeLabel(event.event_start_ms))+'</div></td>'+cell(event.entity.join(' / '))+cell(format(event.observed_duration_ms/1000)+' s · '+event.event_samples+' samples')+'</tr>'));
    node('event-selection').textContent=state.selectedEvents.size+' selected';
    node('findings').innerHTML=tableHtml(['Finding','Original row','Detail'],page(index?.findings||[],'findings').map(finding=>'<tr>'+cell(finding.kind)+cell(finding.row_id||'')+cell(JSON.stringify(finding))+'</tr>'));
  }
  function validContext(focus,start,end){return (state.index?.tracks||[]).filter(track=>track.id!==focus.id&&JSON.stringify(track.site)===JSON.stringify(focus.site)&&JSON.stringify(track.recording)===JSON.stringify(focus.recording)&&track.first_time_ms<=end&&track.last_time_ms>=start);}
  function windowValues(){
    const focus=state.index?.tracks.find(track=>track.id===node('focus').value);
    if(!focus)throw new Error('Choose a source mapping and focus track');
    return {focus,start:focus.first_time_ms+Number(node('start').value)*1000,end:focus.first_time_ms+Number(node('end').value)*1000};
  }
  function renderWindow(keepContext=true){
    if(!state.index||!node('focus').value){node('focus-origin').textContent='';node('window-time').textContent='';node('context').innerHTML='';return;}
    const {focus,start,end}=windowValues(),old=multi('context');
    node('focus-origin').textContent='Original track begins '+timeLabel(focus.first_time_ms)+' · '+format(focus.duration_ms/1000)+' seconds · '+focus.samples+' observations';
    node('window-time').textContent=Number.isFinite(start)&&Number.isFinite(end)?timeLabel(start)+' → '+timeLabel(end):'Enter the source interval';
    const eligible=validContext(focus,start,end);setOptions('context',eligible,track=>track.label,undefined,'');choose('context',keepContext?old:eligible.map(track=>track.id));
  }
  function readScenario(){
    const {focus,start,end}=windowValues();
    const result={mapping_id:state.mappingId,title:node('scenario-title').value,focus_track_id:focus.id,start_ms:start,end_ms:end,context_track_ids:multi('context'),note:node('scenario-note').value};
    const candidate=state.events.find(event=>event.id===state.candidateId);
    if(candidate&&candidate.focus_track_id===focus.id&&candidate.start_ms===start&&candidate.end_ms===end)result.candidate_id=candidate.id;
    return result;
  }
  function fillScenario(scenario){
    stop();state.scenarioId=scenario?.id||'';state.draftParentId=null;node('draft-comparison').innerHTML='';state.candidateId=scenario?.candidate?.id||null;node('scenario').value=state.scenarioId;
    const index=getIndex(),focus=index?.tracks.find(track=>track.id===(scenario?.focus_track_id||node('focus').value))||index?.tracks[0];
    setOptions('focus',index?.tracks||[],track=>track.label,undefined,focus?.id||'');
    node('scenario-title').value=scenario?.title||(focus?focus.label+' observations':'');
    node('start').value=scenario&&focus?(scenario.requested_start_ms-focus.first_time_ms)/1000:0;
    node('end').value=scenario&&focus?(scenario.requested_end_ms-focus.first_time_ms)/1000:(focus?.duration_ms||0)/1000;
    node('scenario-note').value=scenario?.note||'';renderWindow(false);
    if(scenario)choose('context',scenario.tracks.filter(track=>track.id!==scenario.focus_track_id).map(track=>track.id));
    state.formDirty=false;
    node('edition-status').textContent=scenario?scenario.series_id+' · edition '+scenario.edition+' · saved '+scenario.at:'A new scenario will retain its exact source interval and observations.';
    if(scenario)showPreview(scenario,true);else {state.preview=null;state.points=[];state.allPoints=[];renderPreview();}
    renderReviews();
  }
  function draftRecord(){
    return {schema:'tjlabs.trajectory-form-draft/v1',project_id:project?.id,mapping_id:state.mappingId,scenario_id:state.scenarioId,parent_id:state.draftParentId||state.scenarioId,candidate_id:state.candidateId,at:stamp(),
      mapping:node('columns').children.length?readMapping():null,scenario_form:{title:node('scenario-title').value,focus_track_id:node('focus').value,start:node('start').value,end:node('end').value,context_track_ids:multi('context'),note:node('scenario-note').value}};
  }
  function retainDraft(){
    if(!project||state.received||state.restoring)return;
    try{localStorage.setItem(key('draft'),JSON.stringify(draftRecord()));}catch(error){status('The edited form could not be retained in browser storage: '+error.message,true);}
  }
  async function commit(command,recover=false){
    if(!project||state.received)throw new Error('Open the editable saved study to record an operation');
    let record;
    if(recover){record=pending();if(!record||record.project_id!==project.id)throw new Error('No original pending operation belongs to this study');}
    else{
      if(pending())throw new Error('Recover the retained original operation before recording another change');
      retainDraft();record={schema:'tjlabs.trajectory-pending/v1',project_id:project.id,expected_revision:project.revision,command:{...command,operation_id:uid(),at:stamp()}};
      localStorage.setItem(key('pending'),JSON.stringify(record));
    }
    try{
      const current=recover?reopenTrajectoryProject(await request(db.transaction('projects').objectStore('projects').get(project.id))):project;
      const result=applyTrajectoryCommand(current,record.command);
      if(!result.reused)await save(result.project,current.revision);
      project=result.project;
      localStorage.removeItem(key('pending'));
      if(result.output.mapping_id&&record.command.type==='TRAJECTORY_MAP'){state.mappingId=result.output.mapping_id;state.scenarioId='';state.indexKey=null;fillMapping(project.trajectory.mappings.find(item=>item.id===state.mappingId));}
      if(result.output.scenario_id&&(record.command.type==='TRAJECTORY_SCENARIO'))state.scenarioId=result.output.scenario_id;
      if(result.output.scenario_ids)state.scenarioId=result.output.scenario_ids[0];
      await listProjects();render();sync(true);
      if(result.output.handover_id)node('handover').value=result.output.handover_id;
      status((result.reused?'Recovered the original saved operation. ':'Saved. ')+record.command.type+' · '+record.command.operation_id+' · study edition '+project.revision);
      return result.output;
    }catch(error){
      if(['trajectory_arguments','trajectory_conflict','trajectory_source_changed','trajectory_review','trajectory_request_changed','study_changed'].includes(error.code)){
        localStorage.removeItem(key('pending'));
        status(error.message+' Your edited form is retained. Reopen the current study and restore its draft to reconcile the change.',true);
      }
      throw error;
    }finally{syncControls();}
  }
  function selectedRows(scenario=state.preview){
    if(!scenario||!state.index)return [];
    if(scenario===state.preview&&state.allPoints!==null)return state.allPoints;
    return scenario.tracks.flatMap(saved=>{const track=state.index.tracks.find(item=>item.id===saved.id),ids=new Set(saved.row_ids);return track.points.filter(point=>ids.has(point.row_id)).map(point=>({...point,track_id:track.id,label:track.label,focus:track.id===scenario.focus_track_id}));}).sort((a,b)=>a.time_ms-b.time_ms||a.track_id.localeCompare(b.track_id));
  }
  function showPreview(scenario,saved){
    stop();state.preview=scenario;state.previewSaved=saved;state.allPoints=null;state.allPoints=selectedRows(scenario);state.points=state.allPoints.filter(point=>point.focus);state.frame=0;renderPreview();
  }
  function renderPreview(){
    const scenario=state.preview;node('preview-label').textContent=scenario?(state.previewSaved?'Saved '+scenario.id+' · edition '+scenario.edition:'Unsaved window preview'):'Select a track, event or saved scenario';
    node('frame').max=Math.max(0,state.points.length-1);node('frame').value=state.frame;
    setOptions('source-row',selectedRows().map(point=>({id:point.row_id,label:point.label+' · '+point.row_id+' · '+timeLabel(point.time_ms)})),row=>row.label,undefined,'');
    drawFrame();syncControls();
  }
  function svgEmpty(message){return '<text x="24" y="45">'+esc(message)+'</text>';}
  function drawRoad(frame,focus){
    if(!focus){node('road').innerHTML=svgEmpty('Select an original observation');return;}
    const W=680,H=310,margin=40,scale=(W-margin*2)/120,cx=focus.y_m,cy=focus.x_m;
    const px=value=>W/2+(value-cx)*scale,py=value=>H/2-(value-cy)*scale;
    let out='<defs><clipPath id="trj-road-clip"><rect x="20" y="20" width="640" height="265"/></clipPath></defs>';
    for(let x=Math.floor((cx-60)/20)*20;x<=cx+60;x+=20)out+='<path d="M'+px(x)+' 20V285" stroke="#e1e5e8"/><text x="'+px(x)+'" y="302" text-anchor="middle">'+format(x,0)+'</text>';
    for(let y=Math.floor((cy-27)/5)*5;y<=cy+27;y+=5)out+='<path d="M20 '+py(y)+'H660" stroke="#e1e5e8"/><text x="4" y="'+py(y)+'">'+format(y,0)+'</text>';
    out+='<g clip-path="url(#trj-road-clip)">';
    for(const saved of state.preview.tracks){
      const track=state.index.tracks.find(item=>item.id===saved.id),ids=new Set(saved.row_ids),points=track.points.filter(point=>ids.has(point.row_id));
      out+='<path d="'+points.map((point,index)=>(index?'L':'M')+px(point.y_m).toFixed(2)+' '+py(point.x_m).toFixed(2)).join(' ')+'" fill="none" stroke="'+(saved.id===state.preview.focus_track_id?'#7b838b':'#c5cbd1')+'" stroke-width="1.3"/>';
    }
    for(const observed of frame)if(observed.available){
      const point=observed.point,x=px(point.y_m),y=py(point.x_m),fill=observed.focus?'#232a30':'#78828c';
      out+='<circle cx="'+x+'" cy="'+y+'" r="'+(observed.focus?5:4)+'" fill="'+fill+'"/><text x="'+(x+8)+'" y="'+(y-9)+'">'+esc(observed.label.split(' · ')[0])+' · '+esc(point.row_id)+'</text>';
    }
    out+='</g><text x="340" y="16" text-anchor="middle">Longitudinal y (m); lateral x (m)</text>';node('road').innerHTML=out;
  }
  function drawTrace(){
    const scenario=state.preview,field=node('measure').value;
    if(!scenario||!state.points.length){node('trace').innerHTML=svgEmpty('Select a scenario to inspect its original measurements');return;}
    const rows=selectedRows(),values=rows.map(point=>point[field]).filter(value=>value!==null),start=scenario.requested_start_ms,end=scenario.requested_end_ms;
    if(!values.length){node('trace').innerHTML=svgEmpty('This source window has no available '+metricLabels[field].toLowerCase());return;}
    let min=Infinity,max=-Infinity;for(const value of values){min=Math.min(min,value);max=Math.max(max,value);}const pad=Math.max((max-min)*.08,.1);min-=pad;max+=pad;
    const px=time=>60+(time-start)/Math.max(1,end-start)*595,py=value=>230-(value-min)/(max-min)*205;
    let out='';
    for(let i=0;i<=4;i++){const value=min+(max-min)*i/4,y=py(value);out+='<path d="M60 '+y+'H655" stroke="#e0e4e8"/><text x="52" y="'+(y+4)+'" text-anchor="end">'+format(value,2)+'</text>';}
    for(let i=0;i<=4;i++){const time=start+(end-start)*i/4,x=px(time);out+='<text x="'+x+'" y="250" text-anchor="middle">'+format((time-start)/1000,2)+'</text>';}
    for(const saved of scenario.tracks){
      let open=false,path='';
      for(const point of rows.filter(point=>point.track_id===saved.id)){
        if(point[field]===null){open=false;continue;}
        path+=(open?'L':'M')+px(point.time_ms).toFixed(2)+' '+py(point[field]).toFixed(2)+' ';open=true;
      }
      out+='<path d="'+path+'" fill="none" stroke="'+(saved.id===scenario.focus_track_id?'#242b31':'#9da6ae')+'" stroke-width="'+(saved.id===scenario.focus_track_id?'2':'1.4')+'"/>';
    }
    const selected=state.points[state.frame];if(selected)out+='<path d="M'+px(selected.time_ms)+' 20V235" stroke="#303a43" stroke-dasharray="3 3"/>';
    out+='<text x="358" y="270" text-anchor="middle">Seconds after '+esc(timeLabel(start))+'</text>';node('trace').innerHTML=out;
  }
  function drawRaw(){
    const table=doc()?.tables.find(item=>item.id===mapping()?.table_id),row=table?.rows.find(item=>item.id===node('source-row').value);
    node('raw-row').innerHTML=row?tableView(['Original field','Retained value'],[['row_id',row.id],['source_record',row.record],...table.headers.map((header,index)=>[header,row.cells[index]])]):'';
  }
  function drawFrame(){
    const scenario=state.preview,point=state.points[state.frame];
    node('frame').value=state.frame;
    if(!scenario||!point){node('frame-time').textContent='';node('frame-records').innerHTML='';drawRoad(null,null);drawTrace();drawRaw();return;}
    const frame=trajectoryFrame(state.index,scenario,point.time_ms);
    node('frame-time').textContent=timeLabel(point.time_ms)+' · '+point.time_ms+' source ms · observation '+(state.frame+1)+' / '+state.points.length+' · '+point.row_id+' · frame '+(point.frame??'unavailable');
    node('frame-records').innerHTML=tableHtml(['Track','Original row','Speed m/s','Acceleration m/s²','Published lane','Headway s'],frame.map(item=>'<tr>'+cell(item.label)+(item.available?'<td><button data-trj-row="'+esc(item.point.row_id)+'">'+esc(item.point.row_id)+'</button></td>'+cell(format(item.point.speed_m_s))+cell(format(item.point.acceleration_m_s2))+cell(item.point.lane??'—')+cell(format(item.point.time_headway_s)):'<td colspan="5">No original sample at this timestamp</td>')+'</tr>'));
    node('source-row').value=point.row_id;drawRaw();drawRoad(frame,point);drawTrace();
  }
  function stop(){
    if(state.animation!==null)cancelAnimationFrame(state.animation);state.animation=null;state.playing=false;node('play').textContent='Play';
  }
  function play(){
    if(state.playing){stop();return;}if(!state.points.length||operationRunning)return;
    if(state.frame>=state.points.length-1)state.frame=0;
    const started=performance.now(),origin=state.points[state.frame].time_ms,rate=Number(node('rate').value);state.playing=true;node('play').textContent='Pause';
    const tick=now=>{
      if(!state.playing)return;const current=origin+(now-started)*rate,previous=state.frame;
      while(state.frame+1<state.points.length&&state.points[state.frame+1].time_ms<=current)state.frame++;
      if(state.frame!==previous)drawFrame();
      if(state.frame===state.points.length-1){stop();return;}state.animation=requestAnimationFrame(tick);
    };state.animation=requestAnimationFrame(tick);
  }
  function renderReviews(){
    const scenario=savedScenario(),reviews=work().reviews.filter(review=>review.scenario_id===scenario?.id);
    node('review-binding').textContent=scenario?(state.formDirty||!state.previewSaved?'Edited window pending. Reselect the saved scenario to review it, or save the new edition. Original: ':'')+scenario.id+' · edition '+scenario.edition+' · SHA-256 '+trajectoryDigest(scenario):'Save a scenario edition before recording its review.';
    node('review-history').innerHTML=tableView(['Review','Decision','Reviewer','Note','Saved'],reviews.map(review=>[review.id,review.status,review.reviewer,review.note,review.at]));
    const handovers=work().handovers.filter(h=>h.scenario_id===scenario?.id);
    setOptions('handover',handovers,h=>h.id+' · '+h.title,undefined,node('handover').value||handovers.at(-1)?.id||'');
    node('handover-title').placeholder=scenario?scenario.title+' · reviewed observed scenario':'Reviewed scenario handover';
  }
  function syncControls(){
    let original;try{original=pending();}catch(error){status('The retained operation could not be decoded: '+error.message,true);}
    node('pending').hidden=!original;node('pending-text').textContent=original?original.command.type+' · '+original.command.operation_id+' · expected study edition '+original.expected_revision:'';
    node('workspace').classList.toggle('trj-readonly',!!state.received);
    node('received').hidden=!state.received;node('received-text').textContent=state.received?state.received.handover.title+' · '+state.received.handover.id+' · SHA-256 '+state.received.handover.sha256:'';
    for(const button of node('workspace').querySelectorAll('[data-trj-mutate]'))button.disabled=operationRunning||!!state.received||!project||!!original;
    for(const id of ['save-scenario','save-batch'])node(id).disabled=node(id).disabled||!mapping();
    for(const id of ['save-review','freeze'])node(id).disabled=node(id).disabled||!savedScenario()||state.formDirty||!state.previewSaved;
    node('save-batch').disabled=node('save-batch').disabled||state.selectedEvents.size===0;
    for(const id of ['export-rows','export-source'])node(id).disabled=operationRunning||!savedScenario()||state.formDirty||!state.previewSaved;
    for(const id of ['export-handover','export-report'])node(id).disabled=operationRunning||!node('handover').value;
    for(const id of ['export-index','export-events'])node(id).disabled=operationRunning||!mapping();
    for(const id of ['play','step-back','step-next','frame','rate'])node(id).disabled=operationRunning||!state.points.length;
    node('recover-command').disabled=operationRunning||!original;
    node('export-command').disabled=operationRunning||!original;
    for(const input of node('mapping-details').querySelectorAll('input,select,textarea'))input.disabled=operationRunning||!!state.received;
    for(const id of ['new-map','ngsim-map','add-rule','new-scenario','restore-draft','reopen-study'])node(id).disabled=operationRunning||!!state.received||!project;
  }
  function sync(force=false){
    try{
      const p=doc(),context=(state.received?'received:'+state.received.handover.sha256:'study:'+p?.id);
      if(!p){status('Create or reopen a study to work with its original source records.');syncControls();return;}
      const changed=state.contextKey!==context;
      if(changed){state.contextKey=context;state.mappingId=work().mappings.at(-1)?.id||'';state.scenarioId='';state.indexKey=null;state.index=null;state.selectedEvents.clear();state.preview=null;state.points=[];state.formDirty=false;}
      setOptions('table',p.tables,table=>table.id+' · '+table.title,undefined,node('table').value||p.tables[0]?.id||'');
      setOptions('mapping',work().mappings,item=>item.id+' · '+item.title,'New mapping',state.mappingId);
      if(!mapping()&&state.mappingId){state.mappingId=work().mappings.at(-1)?.id||'';node('mapping').value=state.mappingId;}
      if(changed||force)fillMapping(mapping()||emptyMapping(node('table').value));
      getIndex();
      const scenarios=work().scenarios.filter(scenario=>scenario.mapping_id===state.mappingId);
      if(!scenarios.some(scenario=>scenario.id===state.scenarioId))state.scenarioId=scenarios.at(-1)?.id||'';
      setOptions('scenario',scenarios,scenario=>scenario.id+' · edition '+scenario.edition+' · '+scenario.title,'New unsaved scenario',state.scenarioId);
      if(changed||force)fillScenario(savedScenario());
      else if(!node('focus').options.length)setOptions('focus',state.index?.tracks||[],track=>track.label);
      renderInventory();renderReviews();syncControls();
    }catch(error){status(error.message,true);}
  }
  function pickTrack(id){
    if(operationRunning||state.received)return;
    node('focus').value=id;fillScenario(null);node('focus').value=id;renderWindow(false);state.formDirty=true;retainDraft();
    try{showPreview(previewTrajectoryScenario(doc(),readScenario(),state.index),false);}catch(error){status(error.message,true);}
    renderInventory();syncControls();
  }
  function pickEvent(id){
    if(operationRunning||state.received)return;
    const event=state.events.find(item=>item.id===id),focus=state.index.tracks.find(track=>track.id===event.focus_track_id);
    state.scenarioId='';state.draftParentId=null;node('draft-comparison').innerHTML='';node('scenario').value='';state.candidateId=id;node('focus').value=focus.id;
    node('scenario-title').value=event.entity.join(' / ')+' · '+event.title;
    node('start').value=(event.start_ms-focus.first_time_ms)/1000;node('end').value=(event.end_ms-focus.first_time_ms)/1000;node('scenario-note').value='';
    node('edition-status').textContent='Observed event '+event.id+' · '+event.event_samples+' qualifying samples';renderWindow(false);
    state.formDirty=true;retainDraft();showPreview(previewTrajectoryScenario(doc(),readScenario(),state.index),false);renderReviews();syncControls();
  }
  function exportValue(kind){
    if(!doc())throw new Error('Open a study or received scenario');
    if((kind==='trajectory_handover'||kind==='trajectory_report')&&state.received)return kind==='trajectory_handover'?JSON.stringify(state.received.handover,null,2)+'\n':trajectoryReport(state.received.handover);
    return trajectoryExport(doc(),{kind,mapping_id:state.mappingId,scenario_id:state.scenarioId,handover_id:node('handover').value});
  }
  document.getElementById('trj-open-analysis').addEventListener('click',()=>{if(!operationRunning)view('analysis');});
  document.getElementById('trj-open-workspace').addEventListener('click',()=>{if(!operationRunning)view('trajectory');});
  node('jump-source').addEventListener('click',()=>{if(!operationRunning)view('analysis');});
  node('mapping').addEventListener('change',()=>{if(operationRunning)return;stop();retainDraft();state.mappingId=node('mapping').value;state.scenarioId='';state.indexKey=null;state.formDirty=false;sync(true);});
  node('table').addEventListener('change',()=>{if(operationRunning)return;state.mappingId='';node('mapping').value='';state.scenarioId='';state.indexKey=null;fillMapping(emptyMapping(node('table').value));sync(true);retainDraft();});
  bind('new-map',()=>{state.mappingId='';node('mapping').value='';state.scenarioId='';state.indexKey=null;fillMapping(emptyMapping(node('table').value));sync(true);retainDraft();status('Choose original fields and published units for the new mapping.');});
  bind('ngsim-map',()=>{if(!project)throw new Error('Open the original study');fillMapping(ngsimTrajectoryMapping(project,node('table').value,node('run').value||null));retainDraft();status('Published NGSIM columns and SI conversions filled. Review and save this mapping edition.');});
  bind('add-rule',()=>{renderRules([...readRules(),{kind:'speed_below',threshold:2,minimum_duration_ms:1000,before_ms:3000,after_ms:3000}]);retainDraft();});
  node('rules').addEventListener('click',event=>{if(operationRunning||state.received)return;const button=event.target.closest('[data-rule-remove]');if(button){const rules=readRules();rules.splice(Number(button.dataset.ruleRemove),1);renderRules(rules);retainDraft();}});
  bind('save-map',()=>commit({type:'TRAJECTORY_MAP',previous_id:state.mappingId||null,mapping:readMapping()}));
  node('track-filter').addEventListener('input',()=>{state.pages.tracks=0;renderInventory();});
  node('event-filter').addEventListener('change',()=>{state.pages.events=0;renderInventory();});
  for(const kind of ['tracks','events','findings'])for(const direction of ['prev','next'])node(kind+'-'+direction).addEventListener('click',()=>{if(operationRunning)return;state.pages[kind]+=direction==='next'?1:-1;renderInventory();});
  node('track-table').addEventListener('click',event=>{const button=event.target.closest('[data-trj-track]');if(button)pickTrack(button.dataset.trjTrack);});
  node('event-table').addEventListener('click',event=>{const button=event.target.closest('[data-trj-event]');if(button)pickEvent(button.dataset.trjEvent);});
  node('event-table').addEventListener('change',event=>{const id=event.target.dataset.trjEventSelect;if(id){if(event.target.checked)state.selectedEvents.add(id);else state.selectedEvents.delete(id);node('event-selection').textContent=state.selectedEvents.size+' selected';syncControls();}});
  node('select-events').addEventListener('click',()=>{if(operationRunning)return;for(const event of filteredEvents())state.selectedEvents.add(event.id);renderInventory();syncControls();});
  node('clear-events').addEventListener('click',()=>{if(operationRunning)return;state.selectedEvents.clear();renderInventory();syncControls();});
  bind('save-batch',()=>commit({type:'TRAJECTORY_BATCH',mapping_id:state.mappingId,candidate_ids:state.events.filter(event=>state.selectedEvents.has(event.id)).map(event=>event.id),title_prefix:node('batch-prefix').value,note:node('scenario-note').value}));
  node('scenario').addEventListener('change',()=>{if(operationRunning)return;retainDraft();fillScenario(work().scenarios.find(item=>item.id===node('scenario').value));syncControls();});
  bind('new-scenario',()=>{fillScenario(null);retainDraft();});
  node('focus').addEventListener('change',()=>{if(operationRunning)return;stop();const focus=state.index.tracks.find(track=>track.id===node('focus').value);node('start').value=0;node('end').value=focus.duration_ms/1000;state.candidateId=null;renderWindow(false);state.formDirty=true;retainDraft();});
  for(const id of ['start','end'])node(id).addEventListener('input',()=>{if(operationRunning)return;stop();renderWindow();state.formDirty=true;retainDraft();});
  node('workspace').addEventListener('input',event=>{if(operationRunning||state.received||event.target.type==='file'||['frame','track-filter'].includes(event.target.id.replace('trj-','')))return;if(['trj-scenario-title','trj-scenario-note','trj-context','trj-focus','trj-start','trj-end'].includes(event.target.id)){state.formDirty=true;renderReviews();syncControls();}retainDraft();});
  node('workspace').addEventListener('change',event=>{if(operationRunning||state.received||event.target.type==='file'||['trj-source-row','trj-mapping','trj-scenario','trj-table'].includes(event.target.id))return;if(['trj-scenario-title','trj-scenario-note','trj-context','trj-focus','trj-start','trj-end'].includes(event.target.id)){state.formDirty=true;renderReviews();syncControls();}retainDraft();});
  bind('preview',()=>{if(!mapping())throw new Error('Save or select the source mapping');showPreview(previewTrajectoryScenario(doc(),readScenario(),state.index),false);status('Preview uses the selected original observation window.');});
  bind('save-scenario',()=>commit({type:'TRAJECTORY_SCENARIO',previous_id:state.draftParentId||state.scenarioId||null,scenario:readScenario()}));
  bind('restore-draft',()=>{
    const raw=localStorage.getItem(key('draft'));if(!raw)throw new Error('No retained scenario form belongs to this project');
    const draft=JSON.parse(raw);if(draft.project_id!==project.id)throw new Error('This form belongs to another study');
    if(draft.mapping_id&&!work().mappings.some(item=>item.id===draft.mapping_id))throw new Error('Restore the original mapping edition before this draft');
    state.restoring=true;try{state.mappingId=draft.mapping_id;state.scenarioId=draft.scenario_id;state.candidateId=draft.candidate_id;state.indexKey=null;sync(true);
      if(draft.mapping)fillMapping(draft.mapping);const form=draft.scenario_form;node('scenario-title').value=form.title;node('focus').value=form.focus_track_id;node('start').value=form.start;node('end').value=form.end;node('scenario-note').value=form.note;renderWindow(false);choose('context',form.context_track_ids);state.formDirty=true;
      const original=work().scenarios.find(item=>item.id===draft.scenario_id);
      if(draft.scenario_id&&!original)throw new Error('The retained form needs its original scenario history');
      const latest=original?work().scenarios.filter(item=>item.series_id===original.series_id).sort((a,b)=>b.edition-a.edition)[0]:null;
      state.draftParentId=latest?.id||null;
      if(latest){
        const restored=readScenario();
        const rows=[['Title',latest.title,restored.title],['Mapping',latest.mapping_id,restored.mapping_id],['Focus track',latest.focus_track_id,restored.focus_track_id],['Start source ms',latest.requested_start_ms,restored.start_ms],['End source ms',latest.requested_end_ms,restored.end_ms],['Context',latest.tracks.filter(item=>item.id!==latest.focus_track_id).map(item=>item.id).join(', '),restored.context_track_ids.join(', ')],['Note',latest.note,restored.note]];
        node('draft-comparison').innerHTML='<p class="trj-code">Next save continues '+esc(latest.id)+' · edition '+latest.edition+'. Retained edits came from '+esc(original.id)+'.</p>'+tableView(['Field','Current saved edition','Restored edited form'],rows);
        node('edition-status').textContent='Restored edits from '+original.id+'; next save creates edition '+(latest.edition+1)+' after '+latest.id+'.';
      }
      renderReviews();syncControls();status('Retained edits restored. Compare the current saved edition with the form below, adjust it if needed, then save the next edition.');}finally{state.restoring=false;}
  });
  bind('reopen-study',async()=>{if(!project)throw new Error('Open a saved study');retainDraft();project=reopenTrajectoryProject(await request(db.transaction('projects').objectStore('projects').get(project.id)));render();sync(true);status('Current saved study reopened. Restore the retained draft to reconcile your edits.');});
  bind('recover-command',()=>commit(null,true));
  bind('export-command',()=>{const record=pending();if(!record)throw new Error('No retained operation');download(record.command.operation_id+'.json',JSON.stringify(record,null,2)+'\n');});
  node('play').addEventListener('click',play);
  node('frame').addEventListener('input',()=>{stop();state.frame=Number(node('frame').value);drawFrame();});
  for(const [id,delta] of [['step-back',-1],['step-next',1]])node(id).addEventListener('click',()=>{if(operationRunning)return;stop();state.frame=Math.max(0,Math.min(state.points.length-1,state.frame+delta));drawFrame();});
  node('rate').addEventListener('change',()=>{if(state.playing){stop();play();}});
  node('measure').addEventListener('change',drawTrace);
  node('source-row').addEventListener('change',drawRaw);
  node('frame-records').addEventListener('click',event=>{const button=event.target.closest('[data-trj-row]');if(button){node('source-row').value=button.dataset.trjRow;drawRaw();}});
  node('trace').addEventListener('click',event=>{if(operationRunning||!state.points.length)return;stop();const box=node('trace').getBoundingClientRect(),x=(event.clientX-box.left)/box.width*680,scenario=state.preview,target=scenario.requested_start_ms+(x-60)/595*(scenario.requested_end_ms-scenario.requested_start_ms);let best=0;for(let i=1;i<state.points.length;i++)if(Math.abs(state.points[i].time_ms-target)<Math.abs(state.points[best].time_ms-target))best=i;state.frame=best;drawFrame();});
  bind('save-review',()=>commit({type:'TRAJECTORY_REVIEW',scenario_id:state.scenarioId,status:node('review-status').value,reviewer:node('reviewer').value,note:node('review-note').value}));
  bind('freeze',()=>commit({type:'TRAJECTORY_HANDOVER',scenario_id:state.scenarioId,title:node('handover-title').value||savedScenario()?.title+' · reviewed observed scenario'}));
  node('handover').addEventListener('change',syncControls);
  for(const [id,kind,extension,type] of [['export-index','trajectory_index','json','application/json'],['export-events','trajectory_candidates','json','application/json'],['export-rows','trajectory_rows','csv','text/csv'],['export-source','trajectory_source','csv','text/csv'],['export-handover','trajectory_handover','json','application/json'],['export-report','trajectory_report','md','text/markdown']])bind(id,()=>{const text=exportValue(kind),id=kind.includes('handover')||kind.includes('report')?node('handover').value:kind.includes('index')||kind.includes('candidates')?state.mappingId:state.scenarioId;download(id+'-'+kind+'.'+extension,text,type);status('Complete '+kind.replace('trajectory_','')+' exported.');});
  bind('open-handover',async()=>{
    const file=node('handover-file').files[0];if(!file)throw new Error('Choose the complete scenario handover JSON');
    const handover=inspectTrajectoryHandover(await file.text());state.received={handover,context:trajectoryHandoverContext(handover)};state.contextKey=null;sync(true);
    status('Complete original source, exact scenario observations and accepted review verified.');view('trajectory');
  });
  bind('return-study',()=>{state.received=null;state.contextKey=null;sync(true);status('Returned to the saved study and its editable scenario history.');});
  document.addEventListener('study-workspace-render',()=>{if(state.actualProjectId!==project?.id){state.actualProjectId=project?.id;state.received=null;state.contextKey=null;}sync();});
  document.addEventListener('study-workspace-busy',stop);
  document.addEventListener('study-workspace-ready',()=>{syncControls();renderInventory();});
  window.addEventListener('beforeunload',()=>{stop();retainDraft();});
  let initial='analysis';try{initial=localStorage.getItem('tjlabs.study-workspace-view')||initial;}catch{}view(initial);sync();
})();
