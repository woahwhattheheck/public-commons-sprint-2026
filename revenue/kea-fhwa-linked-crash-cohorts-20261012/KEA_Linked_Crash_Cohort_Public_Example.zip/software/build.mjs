import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { loadPublishedExample } from './example.mjs';
import { applyTrajectoryCommand } from './trajectory.mjs';
import { reopenCrashProject } from './crash_core.mjs';
import { loadCrashExample } from './crash-example.mjs';
const base=new URL('./',import.meta.url);
const read=path=>readFile(new URL(path,base),'utf8');
const names=['app.template.html','styles.css','core.mjs','client.mjs','trajectory.mjs','trajectory-client.mjs','trajectory.css','trajectory-panel.html','crash_core.mjs','crash_client.mjs','crash.css','crash-panel.html'];
const [template,css,core,client,trajectory,trajectoryClient,trajectoryCSS,trajectoryPanel,crash,crashClient,crashCSS,crashPanel]=await Promise.all(names.map(read));
let example;
try{example=reopenCrashProject(JSON.parse(await read('example-project.json')));}
catch(error){
  if(error.code!=='ENOENT')throw error;
  example=(await loadPublishedExample()).project;
  const spec=JSON.parse(await read('example/trajectory-commands.json'));
  if(example.id!==spec.project_id)throw new Error('The scenario example belongs to a different original study');
  for(const command of spec.commands)example=applyTrajectoryCommand(example,command).project;
}
const crashExample=(await loadCrashExample()).project;
const moduleBody=text=>text.replace(/^import .*?;\n/gm,'').replace(/^export /gm,'');
const script='globalThis.STUDY_DESK_EXAMPLE='+JSON.stringify(example).replace(/</g,'\\u003c')+';\n'
  +'globalThis.CRASH_DESK_EXAMPLE='+JSON.stringify(crashExample).replace(/</g,'\\u003c')+';\n'
  +moduleBody(core)+'\n'+moduleBody(trajectory)+'\n'+moduleBody(crash)+'\n'+client+'\n'+trajectoryClient+'\n'+crashClient;
const stack='<div class="stack">',end='</div></main><script type="module">';
if(!template.includes(stack)||!template.includes(end))throw new Error('The maintained Study Data Desk template changed; compose its workspace navigation before building');
const navigation='<nav class="trj-workspace-nav" aria-label="Study workspace"><button id="trj-open-analysis" aria-pressed="true">Source analysis</button><button id="trj-open-workspace" aria-pressed="false">Observed scenarios</button><button id="cr-open-workspace" aria-pressed="false">Linked crash cohorts</button></nav>';
const html=template.replace(stack,stack+navigation).replace(end,trajectoryPanel+'\n'+crashPanel+'\n'+end)
  .replace('__CSS__',css+'\n'+trajectoryCSS+'\n'+crashCSS)
  .replace('__CORE__',script.replace(/<\/script/gi,'<\\/script')).replace('__CLIENT__','');
const path=fileURLToPath(new URL('Study_Data_Desk.html',base));
await writeFile(path,html);
process.stdout.write(JSON.stringify({file:path,bytes:Buffer.byteLength(html),example_project:example.id,scenario_editions:example.trajectory?.scenarios.length||0,crash_example_project:crashExample.id,crash_cohort_editions:crashExample.crash.cohorts.length})+'\n');
