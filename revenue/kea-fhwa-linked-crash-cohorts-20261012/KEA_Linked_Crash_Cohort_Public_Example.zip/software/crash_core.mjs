// Linked crash cohorts use the original Study Data Desk tables and operation ledger.
import { createProject, parseCSV, summarize } from './core.mjs';
import { reopenTrajectoryProject, trajectoryDigest } from './trajectory.mjs';

export const CRASH_SCHEMA = 'tjlabs.crash-cohort-workspace/v1';
const ccClone = value => JSON.parse(JSON.stringify(value));
const ccCanonical = value => JSON.stringify(value, (_, item) => item && !Array.isArray(item) && typeof item === 'object' ? Object.fromEntries(Object.keys(item).sort().map(key => [key,item[key]])) : item);
const ccSame = (a,b) => ccCanonical(a) === ccCanonical(b);
const ccDigest = value => trajectoryDigest(typeof value === 'string' ? value : ccCanonical(value));
const ccFail = (message,code='crash_arguments') => {throw Object.assign(new Error(message),{code});};
const ccText = (value,label) => typeof value === 'string' && value.trim() ? value.trim() : ccFail(label+' is required');
const ccFind = (values,id,label) => values.find(value=>value.id===id) || ccFail(label+' was not found');
const ccKinds = ['crash','vehicle','person','parkwork'];
const ccFields = ['mappings','decisions','cohorts','plans','analyses','reviews','handovers'];
const ccEmpty = () => ({schema:CRASH_SCHEMA,...Object.fromEntries(ccFields.map(k=>[k,[]]))});
const ccState = project => project.crash || ccEmpty();
const ccTable = (project,id) => ccFind(project.tables,id,'Original source table');
const ccRow = (project,ref) => ccFind(ccTable(project,ref.table_id).rows,ref.row_id,'Original source row');
const ccRefKey = ref => ccCanonical([ref.table_id,ref.row_id]);
const ccObject = (project,ref) => {const t=ccTable(project,ref.table_id),r=ccRow(project,ref);return Object.fromEntries(t.headers.map((h,i)=>[h,r.cells[i]]));};
const ccNumber = value => /^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(String(value).trim()) && Number.isFinite(Number(value)) ? Number(value) : null;
const ccContext = p => ({id:p.id,title:p.title,case_id:p.case_id,source_note:p.source_note,created_at:p.created_at});
const ccBlank = value => value === undefined || value === null || String(value).trim() === '';
const ccUnique = values => [...new Set(values)];
const ccByteLength = text => {let n=0;for(const c of text){const p=c.codePointAt(0);n+=p<128?1:p<2048?2:p<65536?3:4;}return n;};

function ccCSVLines(text,delimiter) {
  const lines=[];let line=1,start=1,quoted=false,content=false,cells=1;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(c==='"'){if(quoted&&text[i+1]==='"'){i++;content=true;continue;}quoted=!quoted;}
    else if(!quoted&&c===delimiter){cells++;content=true;}
    else if(c==='\r'||c==='\n'){
      if(c==='\r'&&text[i+1]==='\n')i++;
      if(quoted)content=true;
      if(!quoted){if(content||cells>1)lines.push(start);content=false;cells=1;start=line+1;}line++;
    }else content=true;
  }
  if(content||cells>1)lines.push(start);
  return lines.slice(1);
}
export function parseCrashSource(text,parser={format:'csv',delimiter:','}) {
  if(typeof text!=='string'||!text.length)ccFail('Choose the complete original source text');
  const format=parser.format||'csv';
  if(format==='csv'){
    const delimiter=parser.delimiter||',',parsed=parseCSV(text,delimiter),lines=ccCSVLines(text.replace(/^\uFEFF/,''),delimiter);
    return {...parsed,locations:parsed.data.map((_,i)=>({physical_line:lines[i]??null,record_ordinal:i+1})),parser:{format,delimiter}};
  }
  if(format!=='json')ccFail('Choose CSV or JSON for this original source');
  const rowsPath=parser.rows_path||[];
  if(!Array.isArray(rowsPath)||rowsPath.length>24||rowsPath.some(k=>!(typeof k==='string'||Number.isSafeInteger(k)&&k>=0)||['__proto__','constructor','prototype'].includes(k)))ccFail('Choose an explicit JSON array path');
  let rows=JSON.parse(text.replace(/^\uFEFF/,''));const envelope=rows;
  for(const step of rowsPath){if(rows===null||typeof rows!=='object'||!Object.hasOwn(rows,step))ccFail('The selected JSON array path is absent');rows=rows[step];}
  if(!Array.isArray(rows)||!rows.length||rows.some(r=>!r||typeof r!=='object'||Array.isArray(r)))ccFail('The selected JSON path must contain complete row objects');
  if(parser.count_path){
    let count=envelope;
    for(const step of parser.count_path){if(count===null||typeof count!=='object'||!Object.hasOwn(count,step))ccFail('The declared JSON count path is absent');count=count[step];}
    if(!Number.isSafeInteger(count)||count!==rows.length)ccFail('The publisher row count differs from the received array');
  }
  const headers=ccUnique(rows.flatMap(r=>Object.keys(r)));
  if(!headers.length||headers.some(h=>!h))ccFail('Source columns must have names');
  const data=rows.map(r=>headers.map(h=>r[h]===null||r[h]===undefined?'':typeof r[h]==='object'?ccFail('Choose a tabular source with scalar cells'):String(r[h])));
  return {headers,data,locations:rows.map((_,i)=>({json_path:[...rowsPath,i],record_ordinal:i+1})),parser:{format,rows_path:ccClone(rowsPath),...(parser.count_path?{count_path:ccClone(parser.count_path)}:{})}};
}
function ccVerifyTable(table) {
  if(typeof table.original_text!=='string'||!Array.isArray(table.rows)||!Array.isArray(table.headers))ccFail('The complete original table is missing','crash_source_changed');
  const parsed=parseCrashSource(table.original_text,table.source_parser||{format:table.format||'csv',delimiter:table.delimiter||','});
  if(!ccSame(parsed.headers,table.headers)||!ccSame(parsed.data,table.rows.map(r=>r.cells))||new Set(table.rows.map(r=>r.id)).size!==table.rows.length)ccFail('Saved source rows differ from the original file','crash_source_changed');
}
function ccBinding(project,tableId) {
  const table=ccTable(project,tableId),{rows,original_text,...metadata}=table;
  return {project_id:project.id,table_id:table.id,source_sha256:ccDigest(original_text),source_bytes:ccByteLength(original_text),records_sha256:ccDigest({headers:table.headers,rows:table.rows}),metadata_sha256:ccDigest(metadata),rows:rows.length,columns:table.headers.length};
}
function ccCheckMapping(project,mapping) {
  for(const [kind,source] of Object.entries(mapping.sources)){
    if(!ccKinds.includes(kind))ccFail('Unknown linked source family');
    if(!ccSame(ccBinding(project,source.table_id),source.binding))ccFail('The '+kind+' mapping belongs to a different original source edition','crash_source_changed');
  }
}
function ccKeySpec(value,table,label) {
  if(typeof value==='string'&&table.headers.includes(value))return {field:value};
  if(value&&typeof value==='object'&&Object.hasOwn(value,'literal')&&!ccBlank(value.literal))return {literal:String(value.literal)};
  if(value&&typeof value==='object'&&table.headers.includes(value.field))return {field:value.field};
  ccFail('Choose an existing '+label+' column or a declared constant');
}
function ccNormalizeMapping(input,project) {
  const sources={},chosen=[];
  for(const kind of ccKinds){
    const value=input.sources?.[kind];if(!value){if(kind!=='parkwork')ccFail('Choose the '+kind+' source table');continue;}
    const table=ccTable(project,value.table_id);ccVerifyTable(table);
    const roles=['year','state','crash',...(kind==='crash'?[]:['vehicle']),...(kind==='person'?['person']:[])];
    const keys=Object.fromEntries(roles.map(role=>[role,ccKeySpec(value.keys?.[role],table,kind+' '+role+' identity')]));
    sources[kind]={table_id:table.id,keys,binding:ccBinding(project,table.id)};chosen.push(table.id);
  }
  if(new Set(chosen).size!==chosen.length)ccFail('Choose a distinct original table for each record family');
  if(!['integer_codes','exact_text'].includes(input.key_format))ccFail('Choose integer code or exact text key comparison');
  const personType=input.person_type_field||null;
  if(personType&&!ccTable(project,sources.person.table_id).headers.includes(personType))ccFail('Choose the original person type field');
  return {title:ccText(input.title,'Linkage title'),sources,key_format:input.key_format,
    non_motorist_vehicle_values:ccUnique((input.non_motorist_vehicle_values||['0']).map(String)),
    person_type_field:personType,parked_person_type_values:ccUnique((input.parked_person_type_values||['3']).map(String)),
    key_missing_values:ccUnique(['',...(input.key_missing_values||[]).map(String)]),
    note:String(input.note||''),definition_url:String(input.definition_url||'')};
}
function ccNormalizeCode(raw,mapping) {
  if(ccBlank(raw)||mapping.key_missing_values.includes(String(raw).trim()))return null;
  const text=String(raw).trim();
  if(mapping.key_format==='exact_text')return text;
  if(!/^\+?\d+$/.test(text))return null;
  return text.replace(/^\+/,'').replace(/^0+(?=\d)/,'');
}
function ccEffectiveDecisions(project,mappingId) {
  const latest=new Map();
  for(const d of ccState(project).decisions)if(d.mapping_id===mappingId)latest.set(ccRefKey(d),d);
  return [...latest.values()].map(ccClone);
}
function ccIssue(kind,entity,refs,detail) {return {id:'crash-issue-'+ccDigest([kind,entity,refs,detail]).slice(0,24),kind,entity,refs:refs.map(ccClone),detail};}
function ccBuildIndex(project,mapping,decisions) {
  ccCheckMapping(project,mapping);
  const rows={},groups={},findings=[],rowLookup=new Map(),objects=new Map(),exclusions=new Map(decisions.map(d=>[ccRefKey(d),d]));
  for(const [kind,source] of Object.entries(mapping.sources)){
    const table=ccTable(project,source.table_id);rows[kind]=[];groups[kind]=new Map();
    for(let ordinal=0;ordinal<table.rows.length;ordinal++){
      const original=table.rows[ordinal],ref={table_id:table.id,row_id:original.id,ordinal:ordinal+1};
      const object=Object.fromEntries(table.headers.map((h,i)=>[h,original.cells[i]]));objects.set(ccRefKey(ref),object);
      const keys=Object.fromEntries(Object.entries(source.keys).map(([role,spec])=>[role,ccNormalizeCode(Object.hasOwn(spec,'literal')?spec.literal:object[spec.field],mapping)]));
      const identityRoles=['year','state','crash',...(kind==='crash'?[]:['vehicle']),...(kind==='person'?['person']:[])],valid=identityRoles.every(role=>keys[role]!==null);
      const decision=exclusions.get(ccRefKey(ref));
      const row={entity:kind,ref,keys,key:valid?ccCanonical(identityRoles.map(role=>keys[role])):null,
        crash_key:['year','state','crash'].every(role=>keys[role]!==null)?ccCanonical(['year','state','crash'].map(role=>keys[role])):null,
        excluded:decision?.exclude===true,decision_id:decision?.id||null,identity_status:valid?'UNIQUE':'MISSING_OR_INVALID_KEY',crash_status:null,vehicle_status:null,
        crash_ref:null,vehicle_ref:null,vehicle_entity:null};
      rows[kind].push(row);rowLookup.set(ccRefKey(ref),row);
      if(!row.excluded){
        if(!valid)findings.push(ccIssue('MISSING_OR_INVALID_KEY',kind,[ref],'Every composite key component must be available under the selected comparison rule.'));
        else{if(!groups[kind].has(row.key))groups[kind].set(row.key,[]);groups[kind].get(row.key).push(row);}
      }
    }
    for(const [identity,members] of groups[kind])if(members.length>1){
      members.forEach(r=>{r.identity_status='AMBIGUOUS_KEY';});
      findings.push(ccIssue('AMBIGUOUS_KEY',kind,members.map(r=>r.ref),'More than one retained row has composite key '+identity+'.'));
    }
  }
  const crashGroups=groups.crash;
  for(const kind of Object.keys(rows))for(const row of rows[kind]){
    if(row.excluded){row.crash_status='EXCLUDED';continue;}
    const matches=row.crash_key?crashGroups.get(row.crash_key)||[]:[];
    row.crash_status=matches.length===1?'MATCHED':matches.length>1?'AMBIGUOUS':'MISSING';
    if(matches.length===1)row.crash_ref=ccClone(matches[0].ref);
    if(kind!=='crash'&&row.crash_status!=='MATCHED')findings.push(ccIssue('CRASH_LINK_'+row.crash_status,kind,[row.ref,...matches.map(r=>r.ref)],'This record has no unique selected crash parent.'));
    if(kind!=='person')continue;
    const object=objects.get(ccRefKey(row.ref)),vehicleCode=row.keys.vehicle;
    if(vehicleCode!==null&&mapping.non_motorist_vehicle_values.map(v=>ccNormalizeCode(v,mapping)).includes(vehicleCode)){
      row.vehicle_status='NOT_APPLICABLE';continue;
    }
    const parked=mapping.person_type_field&&mapping.parked_person_type_values.includes(String(object[mapping.person_type_field]));
    const target=parked?'parkwork':'vehicle';row.vehicle_entity=target;
    const vehicleKey=row.crash_key&&vehicleCode!==null?ccCanonical([row.keys.year,row.keys.state,row.keys.crash,vehicleCode]):null;
    const vehicleMatches=vehicleKey?groups[target]?.get(vehicleKey)||[]:[];
    row.vehicle_status=!mapping.sources[target]?'SOURCE_NOT_SELECTED':vehicleMatches.length===1?'MATCHED':vehicleMatches.length>1?'AMBIGUOUS':'MISSING';
    if(vehicleMatches.length===1)row.vehicle_ref=ccClone(vehicleMatches[0].ref);
    else findings.push(ccIssue('VEHICLE_LINK_'+row.vehicle_status,'person',[row.ref,...vehicleMatches.map(r=>r.ref)],'The original person record requires a unique '+target+' parent; its crash-level person identity remains visible.'));
  }
  const byCrash=new Map();
  for(const [kind,items] of Object.entries(rows))for(const row of items){
    if(!row.crash_key||row.excluded)continue;
    if(!byCrash.has(row.crash_key))byCrash.set(row.crash_key,Object.fromEntries(ccKinds.map(k=>[k,[]])));
    byCrash.get(row.crash_key)[kind].push(row);
  }
  const coverage=Object.fromEntries(Object.entries(rows).map(([kind,items])=>[kind,{
    source_rows:items.length,excluded_rows:items.filter(r=>r.excluded).length,
    unique_records:items.filter(r=>!r.excluded&&r.identity_status==='UNIQUE').length,
    unresolved_identity_rows:items.filter(r=>!r.excluded&&r.identity_status!=='UNIQUE').length,
    matched_crash_records:items.filter(r=>!r.excluded&&r.identity_status==='UNIQUE'&&r.crash_status==='MATCHED').length,
    unlinked_crash_rows:items.filter(r=>!r.excluded&&r.crash_status!=='MATCHED').length,
    not_vehicle_occupants:items.filter(r=>!r.excluded&&r.vehicle_status==='NOT_APPLICABLE').length,
    unlinked_occupant_rows:items.filter(r=>!r.excluded&&r.vehicle_status&&!['MATCHED','NOT_APPLICABLE'].includes(r.vehicle_status)).length
  }]));
  return {public:{mapping_id:mapping.id,source_bindings:ccClone(Object.fromEntries(Object.entries(mapping.sources).map(([k,s])=>[k,s.binding]))),coverage,rows,findings,decisions:ccClone(decisions)},
    byCrash,rowLookup,objects};
}
export function crashIndex(project,mappingId,{decisions}={}) {
  const mapping=ccFind(ccState(project).mappings,mappingId,'Saved linkage');
  return ccBuildIndex(project,mapping,decisions||ccEffectiveDecisions(project,mappingId)).public;
}
export function crashSourceRow(project,ref) {
  const table=ccTable(project,ref.table_id),row=ccRow(project,ref);
  return {table_id:table.id,table_title:table.title,filename:table.filename,source_url:table.source_url,source_sha256:ccDigest(table.original_text),row:ccClone(row),headers:[...table.headers],values:ccObject(project,ref)};
}
function ccNormalizeFilter(filter,mapping,project,entity) {
  const source=mapping.sources[entity];if(!source)ccFail('Select the '+entity+' table before using its conditions');
  const field=filter.field;if(!ccTable(project,source.table_id).headers.includes(field))ccFail('Choose an existing '+entity+' condition column');
  if(!['in','not_in','range','missing','present'].includes(filter.op))ccFail('Choose an exact-value, numeric-range or availability condition');
  const values=(filter.values||[]).map(String),missing=ccUnique(['',...(filter.missing_values||[]).map(String)]);
  if(['in','not_in'].includes(filter.op)&&!values.length)ccFail('Choose at least one original source value');
  const min=ccBlank(filter.min)?null:ccNumber(filter.min),max=ccBlank(filter.max)?null:ccNumber(filter.max);
  if(filter.op==='range'&&((ccBlank(filter.min)&&ccBlank(filter.max))||(!ccBlank(filter.min)&&min===null)||(!ccBlank(filter.max)&&max===null)||(min!==null&&max!==null&&min>max)))ccFail('Choose a finite ordered numeric range');
  return {field,op:filter.op,values:ccUnique(values),missing_values:missing,min,max};
}
function ccFilterValue(object,filter) {
  const raw=object?.[filter.field],missing=ccBlank(raw)||filter.missing_values.includes(String(raw));
  if(filter.op==='missing')return missing;
  if(filter.op==='present')return !missing;
  if(missing)return null;
  if(filter.op==='in')return filter.values.includes(String(raw));
  if(filter.op==='not_in')return !filter.values.includes(String(raw));
  const value=ccNumber(raw);if(value===null)return null;
  return (filter.min===null||value>=filter.min)&&(filter.max===null||value<=filter.max);
}
function ccAllConditions(object,filters) {
  const results=filters.map(f=>ccFilterValue(object,f));return results.includes(false)?false:results.includes(null)?null:true;
}
function ccNormalizeCohort(input,mapping,project) {
  if(!Array.isArray(input.groups))ccFail('Provide the explicit cohort condition groups');
  const groups=input.groups.map((g,i)=>{
    if(!ccKinds.includes(g.entity)||!mapping.sources[g.entity])ccFail('Choose an available record family');
    const quantifier=g.quantifier||'any';
    if(!['any','none','all'].includes(quantifier))ccFail('Choose any, none, or every available record for the condition group');
    if(!Array.isArray(g.filters)||!g.filters.length)ccFail('Each condition group needs at least one source condition');
    return {id:'condition-'+(i+1),entity:g.entity,quantifier,filters:g.filters.map(f=>ccNormalizeFilter(f,mapping,project,g.entity))};
  });
  return {title:ccText(input.title,'Cohort title'),mapping_id:mapping.id,groups,note:String(input.note||'')};
}
function ccEvaluateCohort(project,mapping,spec,decisions) {
  const built=ccBuildIndex(project,mapping,decisions),index=built.public,selection=[];
  for(const crash of index.rows.crash){
    if(crash.excluded||crash.identity_status!=='UNIQUE')continue;
    const relatives=built.byCrash.get(crash.crash_key),groups=[];
    for(const group of spec.groups){
      const rows=(relatives?.[group.entity]||[]).filter(r=>!r.excluded);
      const examined=rows.map(row=>({ref:row.ref,result:row.identity_status!=='UNIQUE'||row.crash_status!=='MATCHED'?null:ccAllConditions(built.objects.get(ccRefKey(row.ref)),group.filters),identity_status:row.identity_status}));
      const yes=examined.filter(r=>r.result===true),no=examined.filter(r=>r.result===false),unknown=examined.filter(r=>r.result===null);
      let pass;
      if(group.quantifier==='any')pass=yes.length?true:unknown.length?null:false;
      else if(group.quantifier==='none')pass=yes.length?false:unknown.length?null:true;
      else pass=no.length?false:unknown.length?null:examined.length>0;
      groups.push({id:group.id,entity:group.entity,quantifier:group.quantifier,result:pass,matching_rows:yes.map(r=>r.ref),nonmatching_rows:no.map(r=>r.ref),unavailable_rows:unknown.map(r=>r.ref)});
    }
    const status=groups.some(g=>g.result===false)?'EXCLUDED':groups.some(g=>g.result===null)?'INDETERMINATE':'INCLUDED';
    selection.push({crash_key:crash.crash_key,crash_ref:crash.ref,status,groups,
      linked_records:Object.fromEntries(Object.entries(relatives).map(([kind,rows])=>[kind,rows.filter(r=>!r.excluded&&r.identity_status==='UNIQUE'&&r.crash_status==='MATCHED').map(r=>r.ref)]))});
  }
  return {mapping_sha256:ccDigest(mapping),source_bindings:index.source_bindings,coverage:index.coverage,decisions:ccClone(decisions),selection,
    included_crashes:selection.filter(r=>r.status==='INCLUDED').length,excluded_crashes:selection.filter(r=>r.status==='EXCLUDED').length,
    indeterminate_crashes:selection.filter(r=>r.status==='INDETERMINATE').length,findings:index.findings,
    method:'Each crash is counted once by its complete year/state/crash key. All conditions within one child group apply to the same original vehicle or person. Any/none/every groups use three-valued availability; unknown or ambiguous rows cannot silently establish a negative result. Every requires at least one record. Related record counts retain each family independently.'};
}
export function previewCrashCohort(project,input,{decisions}={}) {
  const mapping=ccFind(ccState(project).mappings,input.mapping_id,'Saved linkage'),spec=ccNormalizeCohort(input,mapping,project);
  return {...spec,...ccEvaluateCohort(project,mapping,spec,decisions||ccEffectiveDecisions(project,mapping.id))};
}
function ccPrevious(values,previousId,label) {
  if(!previousId)return {previous_id:null,series_id:null,edition:1};
  const previous=ccFind(values,previousId,'Previous '+label);
  if(values.some(value=>value.previous_id===previous.id))ccFail('This '+label+' edition already has a successor. Reopen the current edition before saving.','crash_edition_changed');
  return {previous_id:previous.id,series_id:previous.series_id||previous.id,edition:previous.edition+1};
}
function ccNormalizePlan(input,cohort,mapping,project) {
  if(!Array.isArray(input.measures)||!input.measures.length)ccFail('Add at least one record count, distribution, proportion or numeric summary');
  const measures=input.measures.map((m,i)=>{
    if(!ccKinds.includes(m.entity)||!mapping.sources[m.entity])ccFail('Choose the measure record family');
    const table=ccTable(project,mapping.sources[m.entity].table_id);
    if(!['count','distribution','proportion','numeric'].includes(m.kind))ccFail('Choose a supported descriptive measure');
    if(m.kind!=='count'&&!table.headers.includes(m.field))ccFail('Choose the original measure field');
    const filters=(m.filters||[]).map(f=>ccNormalizeFilter(f,mapping,project,m.entity));
    const groups=(m.group_by||[]).map(g=>{
      const entity=g.scope==='crash'?'crash':m.entity;
      if(!['self','crash'].includes(g.scope)||!ccTable(project,mapping.sources[entity].table_id).headers.includes(g.field))ccFail('Group a measure by its own record fields or its one crash parent');
      return {scope:g.scope,field:g.field,label:String(g.label||g.field),missing_values:ccUnique(['',...(g.missing_values||[]).map(String)])};
    });
    const min=ccBlank(m.min)?null:ccNumber(m.min),max=ccBlank(m.max)?null:ccNumber(m.max);
    if((!ccBlank(m.min)&&min===null)||(!ccBlank(m.max)&&max===null)||(min!==null&&max!==null&&min>max))ccFail('Numeric measure limits must be finite and ordered');
    const denominator=m.denominator||'all_records';if(!['all_records','observed_values'].includes(denominator))ccFail('Choose all selected records or observed measure values as the denominator');
    const numerator=(m.numerator_values||[]).map(String);
    if(m.kind==='proportion'&&!numerator.length)ccFail('Choose the original codes counted in the numerator');
    return {id:String(m.id||'measure-'+(i+1)),label:ccText(m.label,'Measure label'),entity:m.entity,kind:m.kind,field:m.kind==='count'?null:m.field,
      label_field:m.label_field&&table.headers.includes(m.label_field)?m.label_field:null,unit:String(m.unit||''),missing_values:ccUnique(['',...(m.missing_values||[]).map(String)]),
      filters,group_by:groups,min,max,denominator,numerator_values:ccUnique(numerator)};
  });
  if(new Set(measures.map(m=>m.id)).size!==measures.length)ccFail('Measure identities must be unique within a plan');
  return {title:ccText(input.title,'Analysis plan title'),cohort_id:cohort.id,cohort_sha256:ccDigest(cohort),measures,note:String(input.note||'')};
}
function ccAnalyze(project,plan) {
  const state=ccState(project),cohort=ccFind(state.cohorts,plan.cohort_id,'Saved cohort'),mapping=ccFind(state.mappings,cohort.mapping_id,'Saved linkage');
  if(plan.cohort_sha256!==ccDigest(cohort))ccFail('The analysis plan belongs to a different cohort edition','crash_source_changed');
  const built=ccBuildIndex(project,mapping,cohort.decisions),selected=new Set(cohort.selection.filter(c=>c.status==='INCLUDED').map(c=>c.crash_key));
  const populations=Object.fromEntries(Object.entries(built.public.rows).map(([kind,rows])=>[kind,rows.filter(r=>!r.excluded&&r.identity_status==='UNIQUE'&&r.crash_status==='MATCHED'&&selected.has(r.crash_key))]));
  const summaries=[],observations=[],populationReviews=[];
  for(const measure of plan.measures){
    const candidates=populations[measure.entity]||[],buckets=new Map();let filtered=0,uncertain=0;
    for(const row of candidates){
      const values=built.objects.get(ccRefKey(row.ref)),match=ccAllConditions(values,measure.filters);
      if(match!==true){if(match===null)uncertain++;else filtered++;populationReviews.push({measure_id:measure.id,ref:row.ref,state:match===null?'FILTER_UNAVAILABLE':'FILTER_EXCLUDED'});continue;}
      const group=measure.group_by.map(g=>{
        const source=g.scope==='crash'?built.objects.get(ccRefKey(row.crash_ref)):values,raw=source?.[g.field];
        return {scope:g.scope,field:g.field,label:g.label,value:ccBlank(raw)||g.missing_values.includes(String(raw))?null:String(raw)};
      }),groupKey=ccCanonical(group);
      if(!buckets.has(groupKey))buckets.set(groupKey,{group,rows:[]});
      const raw=measure.field?values[measure.field]:null,missing=measure.kind!=='count'&&(ccBlank(raw)||measure.missing_values.includes(String(raw)));
      let status=missing?'MISSING':'VALID',numeric=null;
      if(measure.kind==='numeric'&&!missing){
        numeric=ccNumber(raw);if(numeric===null)status='NONNUMERIC';else if((measure.min!==null&&numeric<measure.min)||(measure.max!==null&&numeric>measure.max))status='OUT_OF_RANGE';
      }
      const observation={measure_id:measure.id,entity:measure.entity,ref:ccClone(row.ref),crash_ref:ccClone(row.crash_ref),vehicle_ref:ccClone(row.vehicle_ref),
        vehicle_status:row.vehicle_status,group_key:groupKey,raw,source_label:measure.label_field?values[measure.label_field]:null,status,
        value:measure.kind==='numeric'&&status==='VALID'?numeric:null,numerator:measure.kind==='proportion'&&status==='VALID'?measure.numerator_values.includes(String(raw)):null};
      observations.push(observation);buckets.get(groupKey).rows.push(observation);
    }
    if(!buckets.size)buckets.set('[]',{group:[],rows:[]});
    for(const [groupKey,bucket] of buckets){
      const all=bucket.rows,valid=all.filter(r=>r.status==='VALID'),denominator=measure.denominator==='observed_values'?valid.length:all.length;
      const summary={measure_id:measure.id,label:measure.label,entity:measure.entity,kind:measure.kind,unit:measure.unit,field:measure.field,group:bucket.group,
        group_key:groupKey,records:all.length,observed_values:valid.length,unavailable_values:all.length-valid.length,
        denominator,denominator_basis:measure.denominator,source_population:candidates.length,filter_excluded:filtered,filter_unavailable:uncertain,
        row_refs:all.map(r=>r.ref),unavailable_rows:all.filter(r=>r.status!=='VALID').map(r=>({ref:r.ref,status:r.status,raw:r.raw})),
        count:null,numerator:null,proportion:null,statistics:null,distribution:null};
      if(measure.kind==='count')summary.count=all.length;
      if(measure.kind==='numeric')summary.statistics=summarize(valid.map(r=>r.value));
      if(measure.kind==='proportion'){summary.numerator=valid.filter(r=>r.numerator).length;summary.proportion=denominator?summary.numerator/denominator:null;}
      if(measure.kind==='distribution'){
        const categories=new Map();
        for(const r of all){const key=ccCanonical([r.status==='VALID',r.raw]);if(!categories.has(key))categories.set(key,{value:r.raw,status:r.status,labels:[],count:0,row_refs:[]});const d=categories.get(key);d.count++;d.row_refs.push(r.ref);if(r.source_label!==null&&!d.labels.includes(r.source_label))d.labels.push(r.source_label);}
        summary.distribution=[...categories.values()].map(d=>({...d,share:denominator&&!(measure.denominator==='observed_values'&&d.status!=='VALID')?d.count/denominator:null}));
      }
      summaries.push(summary);
    }
  }
  return {cohort_id:cohort.id,cohort_sha256:ccDigest(cohort),mapping_id:mapping.id,source_bindings:ccClone(cohort.source_bindings),
    crash_selection:{included:cohort.included_crashes,excluded:cohort.excluded_crashes,indeterminate:cohort.indeterminate_crashes},
    coverage:ccClone(cohort.coverage),populations:Object.fromEntries(Object.entries(populations).map(([kind,rows])=>[kind,{records:rows.length,row_refs:rows.map(r=>r.ref),unlinked_vehicle_records:rows.filter(r=>r.vehicle_status&&!['MATCHED','NOT_APPLICABLE'].includes(r.vehicle_status)).length}])),
    summaries,observations,population_reviews:populationReviews,findings:ccClone(cohort.findings),
    method:'All results describe the selected original records. A crash, vehicle, parked/working vehicle and person each have their own composite identity and denominator. Child records are never multiplied by another child family. Numeric summaries exclude only explicitly missing, nonnumeric and out-of-range values and retain those original values. Percentages use the selected denominator; no exposure denominator, causal effect or population crash risk is inferred.'};
}
export function analyzeCrashPlan(project,planId) {return ccAnalyze(project,ccFind(ccState(project).plans,planId,'Saved analysis plan'));}
function ccCheckChain(values,label) {
  for(const value of values)if(value.previous_id){
    const previous=ccFind(values,value.previous_id,'Previous '+label);
    if((previous.series_id||previous.id)!==value.series_id||previous.edition+1!==value.edition)ccFail('Invalid '+label+' edition chain');
  }
}
export function reopenCrashProject(raw) {
  const project=reopenTrajectoryProject(raw),state=ccState(project);
  if(state.schema!==CRASH_SCHEMA)ccFail('Unsupported crash cohort workspace');
  for(const name of ccFields)if(!Array.isArray(state[name])||state[name].some(v=>!v||typeof v.id!=='string'||!v.id)||new Set(state[name].map(v=>v.id)).size!==state[name].length)ccFail('Incomplete or repeated '+name+' identity');
  for(const mapping of state.mappings)ccCheckMapping(project,mapping);
  for(const decision of state.decisions){const m=ccFind(state.mappings,decision.mapping_id,'Decision linkage');if(!Object.values(m.sources).some(s=>s.table_id===decision.table_id))ccFail('Decision belongs to another linkage source');ccRow(project,decision);}
  for(const cohort of state.cohorts){const mapping=ccFind(state.mappings,cohort.mapping_id,'Cohort linkage');if(cohort.mapping_sha256!==ccDigest(mapping))ccFail('Cohort linkage changed');for(const d of cohort.decisions||[])if(!ccSame(ccFind(state.decisions,d.id,'Retained decision'),d))ccFail('Cohort source decision changed');}
  ccCheckChain(state.cohorts,'cohort');ccCheckChain(state.plans,'plan');
  for(const plan of state.plans)if(ccDigest(ccFind(state.cohorts,plan.cohort_id,'Plan cohort'))!==plan.cohort_sha256)ccFail('Saved cohort changed');
  for(const run of state.analyses){const plan=ccFind(state.plans,run.plan_id,'Analysis plan');if(run.plan_sha256!==ccDigest(plan)||run.report_sha256!==ccDigest(run.report))ccFail('Saved analysis or plan changed');}
  for(const review of state.reviews)if(review.analysis_sha256!==ccDigest(ccFind(state.analyses,review.analysis_id,'Reviewed analysis')))ccFail('Reviewed analysis changed');
  for(const handover of state.handovers){const review=ccFind(state.reviews,handover.review_id,'Handover review');if(review.analysis_id!==handover.analysis_id||review.status!=='ACCEPTED')ccFail('The handover needs its exact accepted review');}
  return project;
}
export function applyCrashCommand(project,command) {
  const p=reopenCrashProject(project),c=ccClone(command),op=ccText(c.operation_id,'Original operation ID');
  const payload=ccCanonical({...c,at:undefined,...(c.type==='CRASH_IMPORT'?{text:undefined}: {})}),existing=p.operations.find(o=>o.id===op);
  if(existing){if(existing.payload!==payload||(c.type==='CRASH_IMPORT'&&ccTable(p,existing.output.table_id).original_text!==c.text))ccFail('This original operation ID has different inputs','crash_request_changed');return {project,output:ccClone(existing.output),reused:true};}
  const at=ccText(c.at,'Operation time');p.crash=p.crash||ccEmpty();const state=p.crash;let output;
  if(c.type==='CRASH_IMPORT'){
    const parsed=parseCrashSource(c.text,c.parser),id='table-'+(p.tables.length+1);
    if(p.tables.some(t=>t.id===id))ccFail('The next original table identity is occupied');
    p.tables.push({id,title:ccText(c.title,'Table title'),filename:ccText(c.filename,'Original filename'),source_url:String(c.source_url||''),source_note:String(c.source_note||''),license:String(c.license||''),at,
      original_text:c.text,format:parsed.parser.format,delimiter:parsed.parser.delimiter||',',source_parser:parsed.parser,headers:parsed.headers,
      rows:parsed.data.map((cells,i)=>({id:id+':'+(i+1),record:i+1,...parsed.locations[i],cells}))});
    output={table_id:id,rows:parsed.data.length,columns:parsed.headers.length,source_sha256:ccDigest(c.text)};
  }else if(c.type==='CRASH_MAP'){
    const normalized=ccNormalizeMapping(c.mapping,p),id='crash-map-'+(state.mappings.length+1);
    if(c.previous_id)ccFind(state.mappings,c.previous_id,'Previous linkage');
    state.mappings.push({...normalized,id,at,previous_id:c.previous_id||null});output={mapping_id:id};
  }else if(c.type==='CRASH_DECISION'){
    const mapping=ccFind(state.mappings,c.mapping_id,'Saved linkage');if(!Object.values(mapping.sources).some(s=>s.table_id===c.table_id))ccFail('Choose a row from this selected linkage');
    ccRow(p,c);if(typeof c.exclude!=='boolean')ccFail('Choose exclude or restore for the original row');
    const id='crash-decision-'+(state.decisions.length+1);state.decisions.push({id,mapping_id:mapping.id,table_id:c.table_id,row_id:c.row_id,exclude:c.exclude,reviewer:ccText(c.reviewer,'Reviewer'),reason:ccText(c.reason,'Decision reason'),at});
    output={decision_id:id,mapping_id:mapping.id};
  }else if(c.type==='CRASH_COHORT'){
    const mapping=ccFind(state.mappings,c.cohort.mapping_id,'Saved linkage'),spec=ccNormalizeCohort(c.cohort,mapping,p),chain=ccPrevious(state.cohorts,c.previous_id,'cohort');
    const id='crash-cohort-'+(state.cohorts.length+1),cohort={...spec,...chain,series_id:chain.series_id||id,id,at,...ccEvaluateCohort(p,mapping,spec,ccEffectiveDecisions(p,mapping.id))};
    state.cohorts.push(cohort);output={cohort_id:id,edition:cohort.edition,included_crashes:cohort.included_crashes,indeterminate_crashes:cohort.indeterminate_crashes};
  }else if(c.type==='CRASH_PLAN'){
    const cohort=ccFind(state.cohorts,c.plan.cohort_id,'Saved cohort'),mapping=ccFind(state.mappings,cohort.mapping_id,'Saved linkage'),plan=ccNormalizePlan(c.plan,cohort,mapping,p),chain=ccPrevious(state.plans,c.previous_id,'plan');
    const id='crash-plan-'+(state.plans.length+1);state.plans.push({...plan,...chain,series_id:chain.series_id||id,id,at});output={plan_id:id,edition:chain.edition};
  }else if(c.type==='CRASH_RUN'){
    const plan=ccFind(state.plans,c.plan_id,'Saved analysis plan'),report=ccAnalyze(p,plan),id='crash-analysis-'+(state.analyses.length+1);
    state.analyses.push({id,at,plan_id:plan.id,plan_sha256:ccDigest(plan),project_revision:p.revision,report,report_sha256:ccDigest(report)});
    output={analysis_id:id,crashes:report.crash_selection.included,people:report.populations.person?.records||0,vehicles:report.populations.vehicle?.records||0,findings:report.findings.length};
  }else if(c.type==='CRASH_REVIEW'){
    const analysis=ccFind(state.analyses,c.analysis_id,'Saved analysis');if(!['ACCEPTED','CORRECTIONS_REQUESTED'].includes(c.status))ccFail('Choose a review decision');
    if(c.expected_analysis_sha256!==ccDigest(analysis))ccFail('The selected analysis changed. Reopen its exact source and result before review.','crash_analysis_changed');
    const id='crash-review-'+(state.reviews.length+1);state.reviews.push({id,analysis_id:analysis.id,analysis_sha256:ccDigest(analysis),status:c.status,reviewer:ccText(c.reviewer,'Reviewer'),note:ccText(c.note,'Review note'),at});output={review_id:id,analysis_id:analysis.id};
  }else if(c.type==='CRASH_HANDOVER'){
    const analysis=ccFind(state.analyses,c.analysis_id,'Saved analysis'),review=[...state.reviews].reverse().find(r=>r.analysis_id===analysis.id);
    if(!review||review.status!=='ACCEPTED')ccFail('Accept this exact saved analysis before freezing its handover','crash_review');
    const id='crash-handover-'+(state.handovers.length+1),history=Object.fromEntries(ccFields.filter(k=>k!=='handovers').map(k=>[k,state[k].map(v=>v.id)]));
    const tableIds=ccUnique(state.mappings.flatMap(m=>Object.values(m.sources).map(s=>s.table_id)));
    state.handovers.push({id,title:ccText(c.title,'Handover title'),analysis_id:analysis.id,review_id:review.id,at,project_revision:p.revision+1,
      project_context:ccClone(ccContext(p)),table_ids:tableIds,history,operation_ids:[...p.operations.filter(o=>o.type.startsWith('CRASH_')||o.type==='IMPORT'&&tableIds.includes(o.output?.table_id)).map(o=>o.id),op]});
    output={handover_id:id,analysis_id:analysis.id};
  }else ccFail('Unknown crash cohort operation');
  p.revision++;p.updated_at=at;p.operations.push({id:op,type:c.type,at,payload,output:ccClone(output)});
  return {project:p,output,reused:false};
}
export function crashAnalysisDigest(project,id) {return ccDigest(ccFind(ccState(project).analyses,id,'Saved analysis'));}
export function materializeCrashHandover(project,handoverId) {
  reopenCrashProject(project);const state=ccState(project),handover=ccFind(state.handovers,handoverId,'Saved crash handover');
  const workspace={schema:CRASH_SCHEMA,...Object.fromEntries(ccFields.filter(k=>k!=='handovers').map(k=>[k,handover.history[k].map(id=>ccClone(ccFind(state[k],id,'Frozen '+k)))])),handovers:[ccClone(handover)]};
  const value={schema:'tjlabs.crash-cohort-handover/v1',handover:ccClone(handover),tables:handover.table_ids.map(id=>ccClone(ccTable(project,id))),workspace,
    operations:handover.operation_ids.map(id=>ccClone(ccFind(project.operations,id,'Original operation'))),
    method:'Complete original files and the frozen linked-cohort workspace accompany the selected reviewed analysis. Every descriptive result can be recomputed from these original rows and saved definitions.'};
  return {...value,sha256:ccDigest(value)};
}
function ccHandoverContext(value) {
  const h=value.handover,p=createProject({id:h.project_context.id,title:h.project_context.title,case_id:h.project_context.case_id,source_note:h.project_context.source_note,at:h.project_context.created_at});
  p.revision=h.project_revision;p.updated_at=h.at;p.tables=ccClone(value.tables);p.crash=ccClone(value.workspace);p.operations=ccClone(value.operations);return p;
}
export function inspectCrashHandover(input) {
  const value=typeof input==='string'?JSON.parse(input):ccClone(input),{sha256,...body}=value;
  if(value.schema!=='tjlabs.crash-cohort-handover/v1'||sha256!==ccDigest(body))ccFail('The complete crash handover digest differs','crash_handover_changed');
  if(!ccSame(value.workspace.handovers,[value.handover]))ccFail('The selected frozen handover differs from its workspace');
  const p=ccHandoverContext(value);for(const table of p.tables)ccVerifyTable(table);reopenCrashProject(p);
  for(const cohort of p.crash.cohorts){
    const mapping=ccFind(p.crash.mappings,cohort.mapping_id,'Frozen linkage'),computed=ccEvaluateCohort(p,mapping,cohort,cohort.decisions);
    for(const field of Object.keys(computed))if(!ccSame(cohort[field],computed[field]))ccFail('The received cohort differs from its original-row recomputation: '+field,'crash_handover_changed');
  }
  for(const analysis of p.crash.analyses)if(!ccSame(analysis.report,ccAnalyze(p,ccFind(p.crash.plans,analysis.plan_id,'Frozen plan'))))ccFail('The received analysis differs from its complete original rows','crash_handover_changed');
  if(!ccSame(materializeCrashHandover(p,value.handover.id),value))ccFail('The retained receiving graph differs from the frozen packet');
  return value;
}
export function crashHandoverContext(input) {return ccHandoverContext(inspectCrashHandover(input));}
function ccCSV(headers,rows) {
  const cell=value=>{let s=value===null||value===undefined?'':typeof value==='object'?ccCanonical(value):String(value);if(typeof value==='string'&&/^[\t\r\n ]*[=+@-]/.test(s)&&ccNumber(s)===null)s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
  return [headers,...rows].map(row=>row.map(cell).join(',')).join('\r\n')+'\r\n';
}
export function crashSummaryCSV(project,analysisId) {
  const run=ccFind(ccState(project).analyses,analysisId,'Saved analysis');
  return ccCSV(['measure_id','label','entity','kind','group','records','observed_values','unavailable_values','denominator','denominator_basis','count','numerator','proportion','numeric_n','mean','sd','min','q1','median','q3','max','unit','distribution','original_row_refs'],
    run.report.summaries.map(s=>[s.measure_id,s.label,s.entity,s.kind,s.group,s.records,s.observed_values,s.unavailable_values,s.denominator,s.denominator_basis,s.count,s.numerator,s.proportion,s.statistics?.n,s.statistics?.mean,s.statistics?.sd,s.statistics?.min,s.statistics?.q1,s.statistics?.median,s.statistics?.q3,s.statistics?.max,s.unit,s.distribution,s.row_refs]));
}
export function crashRowsCSV(project,analysisId,entity) {
  if(!ccKinds.includes(entity))ccFail('Choose a valid source record family');
  const state=ccState(project),run=ccFind(state.analyses,analysisId,'Saved analysis'),cohort=ccFind(state.cohorts,run.report.cohort_id,'Saved cohort'),mapping=ccFind(state.mappings,cohort.mapping_id,'Saved linkage');
  if(!mapping.sources[entity])ccFail('This record family was not selected');
  const table=ccTable(project,mapping.sources[entity].table_id),refs=run.report.populations[entity].row_refs;
  return ccCSV(['source_table_id','original_row_id','record_ordinal',...table.headers],refs.map(ref=>[table.id,ref.row_id,ref.ordinal,...ccRow(project,ref).cells]));
}
export function crashReportMarkdown(project,handoverId) {
  const h=materializeCrashHandover(project,handoverId),p=ccHandoverContext(h),run=ccFind(p.crash.analyses,h.handover.analysis_id,'Reviewed analysis'),review=ccFind(p.crash.reviews,h.handover.review_id,'Review'),plan=ccFind(p.crash.plans,run.plan_id,'Analysis plan');
  const cell=v=>String(v??'').replace(/\|/g,'\\|').replace(/[\r\n]+/g,' '),number=v=>v===null||v===undefined?'—':Number(v).toLocaleString('en-US',{maximumFractionDigits:6});
  const lines=['# '+h.handover.title,'','Project: '+h.handover.project_context.id,'','Case: '+(h.handover.project_context.case_id||'Unassigned'),'','Analysis: '+run.id+' · '+run.at,'','Review: '+review.reviewer+' · '+review.status+' · '+review.note,'','## Original source files','',
    '| File | Rows | Columns | SHA-256 | Source |','| --- | ---: | ---: | --- | --- |',...h.tables.map(t=>'| '+[t.filename,t.rows.length,t.headers.length,ccDigest(t.original_text),t.source_url].map(cell).join(' | ')+' |'),'',
    '## Cohort and denominators','',run.report.crash_selection.included+' included crashes; '+run.report.crash_selection.excluded+' excluded; '+run.report.crash_selection.indeterminate+' indeterminate.','',
    '| Record family | Selected unique records |','| --- | ---: |',...Object.entries(run.report.populations).map(([k,v])=>'| '+k+' | '+v.records+' |'),'','## Descriptive results','',
    '| Measure | Family | Group | Records | Observed | Declared denominator | Result |','| --- | --- | --- | ---: | ---: | ---: | --- |',...run.report.summaries.map(s=>'| '+[s.label,s.entity,s.group.map(g=>g.label+'='+(g.value??'Unavailable')).join('; '),s.records,s.observed_values,s.denominator+' · '+s.denominator_basis,s.kind==='count'?s.count:s.kind==='proportion'?number(s.numerator)+' / '+s.denominator+' = '+number(s.proportion):s.kind==='numeric'?'mean '+number(s.statistics.mean)+' '+s.unit+'; SD '+number(s.statistics.sd)+'; median '+number(s.statistics.median)+'; numeric n '+number(s.statistics.n):s.distribution.map(d=>String(d.value??'Blank')+': '+d.count+' ['+d.status+']').join('; ')].map(cell).join(' | ')+' |'),'',
    '## Method','','Numeric means, standard deviations and quantiles use the displayed numeric n: original observations with a valid numeric value after the saved missing-code and range rules. The declared denominator remains visible separately for the measure population.', '',run.report.method,'',plan.note,'','## Complete receiving','',
    'The accompanying handover JSON preserves the original source texts, source mapping, each saved cohort and plan edition, row decisions, original operation identities, reviewed analyses and frozen context. Open it in the linked-cohort receiving panel to recompute the complete result. The full project JSON preserves the broader editable study.',''];
  return lines.join('\n');
}
export function crashCompareAnalyses(project,leftId,rightId) {
  const values=[leftId,rightId].map(id=>ccFind(ccState(project).analyses,id,'Saved comparison analysis'));
  return values.map(run=>({analysis_id:run.id,at:run.at,cohort_id:run.report.cohort_id,source_bindings:ccClone(run.report.source_bindings),populations:ccClone(run.report.populations),
    summaries:run.report.summaries.map(s=>({measure_id:s.measure_id,label:s.label,entity:s.entity,kind:s.kind,group:s.group,records:s.records,denominator:s.denominator,denominator_basis:s.denominator_basis,count:s.count,numerator:s.numerator,proportion:s.proportion,statistics:s.statistics,distribution:s.distribution}))}));
}
export function crashExport(project,command) {
  const kind=command.kind;
  if(kind==='crash_index')return JSON.stringify(crashIndex(project,command.mapping_id),null,2)+'\n';
  if(kind==='crash_summary')return crashSummaryCSV(project,command.analysis_id);
  if(kind==='crash_rows')return crashRowsCSV(project,command.analysis_id,command.entity);
  if(kind==='crash_report')return crashReportMarkdown(project,command.handover_id);
  if(kind==='crash_handover')return JSON.stringify(materializeCrashHandover(project,command.handover_id),null,2)+'\n';
  if(kind==='crash_analysis')return JSON.stringify(ccFind(ccState(project).analyses,command.analysis_id,'Saved analysis'),null,2)+'\n';
  if(kind==='crash_cohort')return JSON.stringify(ccFind(ccState(project).cohorts,command.cohort_id,'Saved cohort'),null,2)+'\n';
  ccFail('Choose a supported crash workspace export');
}
