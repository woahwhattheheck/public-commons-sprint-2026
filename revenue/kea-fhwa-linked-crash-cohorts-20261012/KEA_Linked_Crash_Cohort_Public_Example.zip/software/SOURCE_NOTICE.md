# Original public source attribution

Source: National Highway Traffic Safety Administration, Fatality Analysis Reporting System, case year 2020, District of Columbia. The three complete original accident, vehicle and person exports retain their original file bytes. Original publisher URLs, byte counts, SHA-256 values and year-specific definitions accompany example/crash/source.json and CRASH_COHORT_WORKSPACE.md.

The example retains the original linked project, cohort definitions, named reviews and frozen handovers. Its descriptive measures use the selected source populations and their explicit entity denominators.
