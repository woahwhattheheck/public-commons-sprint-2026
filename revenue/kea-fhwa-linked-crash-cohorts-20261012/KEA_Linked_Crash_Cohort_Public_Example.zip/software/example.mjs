import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createProject, applyCommand, summaryCSV, reducedCSV, handoverReport, materializeHandover } from './core.mjs';
const root=new URL('./example/',import.meta.url);
const read=name=>readFile(new URL(name,root),'utf8');
export async function loadPublishedExample() {
  const [config,source]=await Promise.all(['commands.json','source.json'].map(async name=>JSON.parse(await read(name))));
  if(config.schema!=='tjlabs.published-study-example/v1'||source.schema!=='tjlabs.published-study-source/v1'||!Array.isArray(config.commands))throw new Error('Keep the complete published example configuration');
  if(!/^[a-z0-9][a-z0-9.-]*$/.test(source.input_filename))throw new Error('Invalid published source filename');
  const original=await read(source.input_filename);
  if(Buffer.byteLength(original)!==source.bytes||createHash('sha256').update(original).digest('hex')!==source.sha256)throw new Error('The published source differs from its retained complete response');
  let project=createProject(config.project);
  for(const originalCommand of config.commands) {
    const command=structuredClone(originalCommand);
    if(command.type==='IMPORT') {
      if(command.file!==source.input_filename)throw new Error('The example command references another source');
      command.text=original;delete command.file;
    }
    project=applyCommand(project,command).project;
  }
  return {project,source};
}
export async function exportPublishedExample(destination) {
  const {project,source}=await loadPublishedExample(),run=project.runs.at(-1),handover=materializeHandover(project,project.handovers.at(-1).id);
  const files={
    'study-project.json':JSON.stringify(project)+'\n',
    'source-and-analysis.json':JSON.stringify(handover)+'\n',
    'summary.csv':summaryCSV(run),'reduced-rows.csv':reducedCSV(run),'report.md':handoverReport(handover)
  };
  await mkdir(destination,{recursive:true,mode:0o700});const received=[];
  for(const [name,content] of Object.entries(files)){
    const path=join(destination,name);let reused=false;
    try{await writeFile(path,content,{flag:'wx',mode:0o600});}
    catch(error){if(error.code!=='EEXIST')throw error;if(await readFile(path,'utf8')!==content)throw new Error('Existing output differs: '+path);reused=true;}
    received.push({file:path,bytes:Buffer.byteLength(content),sha256:createHash('sha256').update(content).digest('hex'),reused});
  }
  return {project_id:project.id,source_rows:source.source_rows,files:received};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  if(!process.argv[2])throw new Error('Usage: node example.mjs /absolute/private/example-output');
  process.stdout.write(JSON.stringify(await exportPublishedExample(resolve(process.argv[2])))+'\n');
}
