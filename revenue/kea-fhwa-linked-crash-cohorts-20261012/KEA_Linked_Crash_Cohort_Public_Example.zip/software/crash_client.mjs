(() => {
  const n=id=>document.getElementById('cr-'+id),e=escape,clone=v=>JSON.parse(JSON.stringify(v)),kinds=['crash','vehicle','person','parkwork'];
  const labels={crash:'Crash',vehicle:'In-transport vehicle',person:'Person',parkwork:'Parked / working vehicle'};
  const roles={crash:['year','state','crash'],vehicle:['year','state','crash','vehicle'],person:['year','state','crash','vehicle','person'],parkwork:['year','state','crash','vehicle']};
  const C={auxRequests:[],draftEditions:[],reviewContext:null,decisionContext:null,requestId:'',importBuffer:null,context:null,projectId:null,mapId:'',cohortId:'',planId:'',analysisId:'',handoverId:'',index:null,indexKey:null,preview:null,previewSaved:true,row:null,received:null,pending:null,draft:null,draftDirty:false,draftBase:null,formGeneration:0,restoring:false,groups:[],measures:[],pages:{source:0,findings:0,selection:0,observations:0},syncGeneration:0};
  const defaultFormValues=Object.fromEntries([...document.querySelectorAll('#cr-workspace [data-cr-draft]')].filter(v=>v.id).map(v=>[v.id,v.value]));
  const doc=()=>C.received?.context||project,work=()=>doc()?.crash||{mappings:[],decisions:[],cohorts:[],plans:[],analyses:[],reviews:[],handovers:[]};
  const map=()=>work().mappings.find(v=>v.id===C.mapId),cohort=()=>work().cohorts.find(v=>v.id===C.cohortId),plan=()=>work().plans.find(v=>v.id===C.planId),analysis=()=>work().analyses.find(v=>v.id===C.analysisId);
  const table=id=>doc()?.tables.find(t=>t.id===id),columns=entity=>table(map()?.sources[entity]?.table_id)?.headers||[];
  const fmt=(v,digits=5)=>v===null||v===undefined?'—':Number(v).toLocaleString(undefined,{maximumFractionDigits:digits});
  const lines=v=>String(v||'').split(/\r?\n/).map(v=>v.trim()).filter(v=>v!=='');
  const status=(text,error=false)=>{n('status').textContent=text||'';n('status').dataset.kind=error?'error':'info';};
  const rowRefButton=(ref,label)=>'<button type="button" data-cr-row="'+e(ref.table_id)+'" data-cr-row-id="'+e(ref.row_id)+'">'+e(label||ref.row_id)+'</button>';
  const td=v=>'<td>'+e(v)+'</td>',htmlTable=(headers,rows)=>'<table><thead><tr>'+headers.map(h=>'<th>'+e(h)+'</th>').join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody></table>';
  const recordTable=(headers,rows)=>htmlTable(headers,rows.map(row=>'<tr>'+row.map(td).join('')+'</tr>'));
  const itemOptions=(items,selected='',empty='Choose an edition')=>'<option value="">'+e(empty)+'</option>'+items.map(v=>'<option value="'+e(v.id)+'"'+(v.id===selected?' selected':'')+'>'+e(v.label||v.id)+'</option>').join('');
  const fieldOptions=(fields,selected='',empty='Choose a source column')=>'<option value="">'+e(empty)+'</option>'+[...new Set([...fields,...(selected&&!fields.includes(selected)?[selected]:[])])].map(v=>'<option value="'+e(v)+'"'+(v===selected?' selected':'')+'>'+e(v)+(fields.includes(v)?'':' (not in selected source)')+'</option>').join('');
  function choose(id,items,selectedValue=n(id).value,empty){n(id).innerHTML=itemOptions(items,selectedValue,empty);if([...n(id).options].some(v=>v.value===selectedValue))n(id).value=selectedValue;}
  function paged(items,kind,size=50){const pages=Math.max(1,Math.ceil(items.length/size));C.pages[kind]=Math.min(Math.max(C.pages[kind]||0,0),pages-1);const start=C.pages[kind]*size;
    n(kind+'-page').textContent=items.length?(start+1)+'–'+Math.min(items.length,start+size)+' of '+items.length:'0 records';
    n(kind+'-prev').disabled=operationRunning||start===0;n(kind+'-next').disabled=operationRunning||start+size>=items.length;return items.slice(start,start+size);}
  const auxReady=new Promise((resolve,reject)=>{const req=indexedDB.open('tjlabs-study-data-desk-cohort-state',1);req.onupgradeneeded=()=>req.result.createObjectStore('items',{keyPath:'key'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
  async function auxGet(key){const adb=await auxReady;return request(adb.transaction('items').objectStore('items').get(key));}
  async function auxAll(){const adb=await auxReady;return request(adb.transaction('items').objectStore('items').getAll());}
  async function auxWrite(fn){const adb=await auxReady;return new Promise((resolve,reject)=>{const tx=adb.transaction('items','readwrite');let why;try{fn(tx.objectStore('items'),error=>{why=error;tx.abort();});}catch(error){why=error;tx.abort();}tx.oncomplete=resolve;tx.onerror=()=>reject(why||tx.error);tx.onabort=()=>reject(why||tx.error||new Error('The retained operation save was interrupted'));});}
  const pendingKey=id=>'pending|'+id,draftKey=id=>'draft|'+id,operationKey=id=>'operation|'+id;
  async function readPending(id=project?.id){if(!id)return null;const ptr=await auxGet(pendingKey(id));if(!ptr)return null;const record=await auxGet(operationKey(ptr.id));if(!record)throw new Error('The original pending request is missing; preserve the browser workspace before continuing');return record;}
  async function retainPending(record){await auxWrite((store,fail)=>{const q=store.get(pendingKey(record.project_id));q.onsuccess=()=>{if(q.result){fail(new Error('This study already has a retained original operation. Reopen its recovery panel.'));return;}store.add({...record,key:operationKey(record.command.operation_id)});store.put({key:pendingKey(record.project_id),id:record.command.operation_id});};});}
  async function settlePending(record,result,error){await auxWrite((store,fail)=>{const q=store.get(pendingKey(record.project_id));q.onsuccess=()=>{if(q.result&&q.result.id!==record.command.operation_id){fail(new Error('Another pending operation now owns this study; preserve the original completion.'));return;}store.put({...record,key:operationKey(record.command.operation_id),state:error?'validation_failed':'completed',completed_at:stamp(),result:result||null,error:error?{code:error.code||'arguments',message:error.message}:null});if(q.result)store.delete(pendingKey(record.project_id));};});}
  let draftQueue=Promise.resolve();const draftWrites=new Map();
  function queueDraftWrite(record,immutable=false){
    const entry={record,immutable};draftWrites.set(record.key,entry);
    draftQueue=draftQueue.catch(()=>{}).then(async()=>{
      for(const [key,current] of [...draftWrites]){
        await auxWrite((store,fail)=>{
          if(!current.immutable){store.put(current.record);return;}
          const req=store.get(key);req.onsuccess=()=>{if(req.result){if(JSON.stringify(req.result)!==JSON.stringify(current.record))fail(new Error('A retained form edition already has different bytes'));}else store.add(current.record);};
        });
        if(draftWrites.get(key)===current)draftWrites.delete(key);
      }
    });
    draftQueue.catch(error=>status('Complete edited forms remain in this page because their durable save failed: '+error.message,true));return draftQueue;
  }
  async function runSelection(fn){
    if(operationRunning)return;operationRunning=true;document.dispatchEvent(new Event('study-workspace-busy'));
    const controls=[...document.querySelectorAll('button,input,select,textarea')].map(node=>[node,node.disabled]);controls.forEach(([node])=>{node.disabled=true;});
    try{await fn();}catch(error){status(error.message,true);sync();}
    finally{controls.forEach(([node,disabled])=>{node.disabled=disabled;});operationRunning=false;document.dispatchEvent(new Event('study-workspace-ready'));}
  }
  function captureForms(){
    return {values:Object.fromEntries([...n('workspace').querySelectorAll('[data-cr-draft]')].filter(v=>v.id).map(v=>[v.id,v.type==='checkbox'?v.checked:v.value])),
      mapping:readMapping(),groups:readGroups(),measures:readMeasures(),map_id:C.mapId,cohort_id:C.cohortId,plan_id:C.planId,analysis_id:C.analysisId,handover_id:C.handoverId,row:C.row?clone(C.row):null,review_context:C.reviewContext,decision_context:C.decisionContext};
  }
  function bankDraft(reason){
    if(!project||C.received||C.restoring)return;
    const saved={key:'draft-edition|'+project.id+'|'+uid(),schema:'tjlabs.crash-form-draft/v1',id:uid(),project_id:project.id,base_revision:C.draftBase??project.revision,saved_at:stamp(),generation:C.formGeneration,reason,forms:captureForms()};
    saved.form_sha256=trajectoryDigest({project_id:saved.project_id,base_revision:saved.base_revision,forms:saved.forms});const prior=C.draftEditions.find(v=>v.form_sha256===saved.form_sha256);if(prior)return draftQueue;C.draftEditions.push(saved);const queued=queueDraftWrite(saved,true);renderDraftHistory();return queued;
  }
  function bankSavedDraft(saved,reason){
    if(!saved)return;const retained={...clone(saved),key:'draft-edition|'+saved.project_id+'|'+uid(),id:uid(),reason};
    return queueDraftWrite(retained,true);
  }
  function selectAnalysis(id){
    id=id||'';
    if(C.analysisId!==id||C.reviewContext!==doc()?.id+'|'+id){
      if(C.analysisId&&!C.restoring&&!C.received)bankDraft('Before changing the reviewed analysis');
      C.analysisId=id;C.reviewContext=doc()?.id+'|'+id;
      n('reviewer').value='';n('review-note').value='';n('review-status').value='ACCEPTED';n('handover-title').value='';
    }
  }
  function renderDraftHistory(){
    choose('draft-select',C.draftEditions.map(v=>({id:v.key,label:v.saved_at+' · study edition '+v.base_revision+' · '+(v.reason||'Saved forms')})),n('draft-select').value,'Choose a prior complete form edition');
  }
  function renderRequestHistory(){
    choose('request-select',C.auxRequests.map(v=>({id:v.command.operation_id,label:v.command.operation_id+' · '+v.state+' · '+v.command.type})),C.requestId||n('request-select').value,'Choose an original browser operation');
    n('aux-history').innerHTML=recordTable(['Original request','Action','State','Prepared edition','Result / error'],C.auxRequests.map(v=>[v.command.operation_id,v.command.type,v.state,v.expected_revision,v.error?.message||JSON.stringify(v.result||{})]));
  }
  function resetDecisionForm(){
    C.decisionContext=C.row?C.mapId+'|'+C.row.table_id+'|'+C.row.row_id:null;
    n('decision-kind').value='exclude';n('decision-reviewer').value='';n('decision-reason').value='';
  }
  function retainDraft(){
    if(!project||C.received||C.restoring)return;C.draftDirty=true;C.formGeneration++;C.draftBase=C.draftBase??project.revision;
    const saved={key:draftKey(project.id),schema:'tjlabs.crash-form-draft/v1',id:uid(),project_id:project.id,base_revision:C.draftBase,saved_at:stamp(),generation:C.formGeneration,forms:captureForms()};
    C.draft=saved;queueDraftWrite(saved);syncControls();
  }
  async function refreshStored(){
    const id=project?.id,generation=++C.syncGeneration;
    try{const [pending,draft,items]=await Promise.all([readPending(id),id?auxGet(draftKey(id)):null,auxAll()]);if(id!==project?.id||generation!==C.syncGeneration)return;
      C.pending=pending;if(!C.draftDirty)C.draft=draft||null;C.draftEditions=C.received?[]:items.filter(v=>v.key.startsWith('draft-edition|')&&v.project_id===id);C.auxRequests=items.filter(v=>v.key.startsWith('operation|')&&v.project_id===doc()?.id);renderDraftHistory();renderRequestHistory();choose('received-select',items.filter(v=>v.kind==='received').map(v=>({id:v.key,label:v.title+' · '+v.handover_id})),n('received-select').value,'Choose retained handover');syncControls();
    }catch(error){status('Retained workspace state could not be opened: '+error.message,true);}
  }
  function guardEditable(){if(!project||C.received)throw new Error('Open the editable saved study before recording a change');if(C.draftDirty&&C.draftBase!==project.revision)throw Object.assign(new Error('This form was edited against another saved study edition. Reopen the current study, restore the retained draft, then explicitly use those forms on the current edition.'),{code:'study_changed'});}
  async function commit(command,recover=false){
    if(recover){if(!project||C.received)throw new Error('Open the editable saved study to recover its original request');}else guardEditable();await draftQueue;let record;
    if(recover){record=await readPending(project.id);if(!record)throw new Error('There is no original pending request for this study');}
    else{if(await readPending(project.id))throw new Error('Recover the retained original request before saving another operation');record={schema:'tjlabs.crash-pending/v1',state:'pending',project_id:project.id,expected_revision:project.revision,submitted_draft_id:C.draft?.id||null,submitted_forms:captureForms(),command:{...command,operation_id:uid(),at:stamp()}};await retainPending(record);}
    C.pending=record;syncControls();let result;
    try{
      const current=reopenCrashProject(await request(db.transaction('projects').objectStore('projects').get(record.project_id)));
      if(!current.operations.some(v=>v.id===record.command.operation_id)&&current.revision!==record.expected_revision)throw Object.assign(new Error('The saved study advanced after this original request was prepared. Its form remains retained for deliberate reconciliation.'),{code:'study_changed'});
      result=applyCrashCommand(current,record.command);
      if(!result.reused){try{await save(result.project,current.revision);}catch(error){
        if(error.code!=='study_changed')throw error;const latest=reopenCrashProject(await request(db.transaction('projects').objectStore('projects').get(record.project_id)));
        if(!latest.operations.some(v=>v.id===record.command.operation_id))throw error;result=applyCrashCommand(latest,record.command);
      }}
      project=result.project;
    }catch(error){
      if(error.code==='study_changed'||String(error.code||'').startsWith('crash_')){
        await settlePending(record,null,error);C.pending=null;await refreshStored();status(error.message+' The complete edited form and original failed request are retained.',true);
      }
      throw error;
    }
    await settlePending(record,{...result.output,revision:project.revision,reused:result.reused},null);C.pending=null;await refreshStored();
    if(C.draft?.id===record.submitted_draft_id){C.draftDirty=false;C.draftBase=project.revision;await auxWrite(store=>{const q=store.get(draftKey(project.id));q.onsuccess=()=>{if(q.result?.id===record.submitted_draft_id)store.put({...q.result,applied_operation_id:record.command.operation_id,applied_revision:project.revision});};});}
    adoptOutput(record.command,result.output);render();sync();try{await listProjects();}catch(error){status('The original operation is saved; the project list could not refresh: '+error.message,true);return result.output;}
    status((result.reused?'Recovered original operation. ':'Saved. ')+record.command.type+' · '+record.command.operation_id+' · study edition '+project.revision);return result.output;
  }
  function adoptOutput(command,out){
    C.indexKey=null;
    if(command.type==='CRASH_IMPORT'){n('source-table').value=out.table_id;C.sourceChoice=out.table_id;}
    if(command.type==='CRASH_MAP'){C.mapId=out.mapping_id;C.cohortId='';C.planId='';selectAnalysis('');C.preview=null;fillMapping(map());fillCohort(null);fillPlan(null);}
    if(command.type==='CRASH_COHORT'){C.cohortId=out.cohort_id;C.preview=cohort();C.previewSaved=true;fillCohort(cohort());}
    if(command.type==='CRASH_PLAN'){C.planId=out.plan_id;fillPlan(plan());}
    if(command.type==='CRASH_RUN'){selectAnalysis(out.analysis_id);adoptAnalysis(analysis(),false);}
    if(command.type==='CRASH_HANDOVER')C.handoverId=out.handover_id;
  }
  function bind(id,fn){wire('cr-'+id,async()=>{status('');try{await fn();}catch(error){status(error.message,true);throw error;}});}
  function edit(fn){if(operationRunning||C.received||!project)return;try{fn();retainDraft();}catch(error){status(error.message,true);}}
  function getIndex(){if(!map())return null;const key=doc().id+'|'+doc().revision+'|'+C.mapId;if(C.indexKey!==key){C.index=crashIndex(doc(),C.mapId);C.indexKey=key;}return C.index;}
  function emptyMapping(){return {title:'Original crash record linkage',sources:{},key_format:'integer_codes',person_type_field:'',non_motorist_vehicle_values:['0'],parked_person_type_values:['3'],key_missing_values:[],definition_url:'',note:''};}
  function renderMappingSources(value){
    n('map-sources').innerHTML=kinds.map(kind=>{
      const src=value.sources?.[kind]||{},t=table(src.table_id),keys=src.keys||{};
      return '<div class="cr-map-family" data-cr-map-family="'+kind+'"><h4>'+e(labels[kind])+(kind==='crash'?' · required':' · optional')+'</h4><label>Complete original table<select data-cr-map-table="'+kind+'">'+itemOptions((doc()?.tables||[]).map(t=>({id:t.id,label:t.id+' · '+t.title+' · '+t.rows.length+' rows'})),src.table_id||'',kind==='crash'?'Choose crash source':'No source selected')+'</select></label><div class="cr-grid">'+roles[kind].map(role=>{
        const spec=keys[role]||{},field=typeof spec==='string'?spec:spec.field||'',literal=typeof spec==='object'&&Object.prototype.hasOwnProperty.call(spec,'literal');
        return '<div class="cr-key" data-cr-key="'+role+'"><label>'+e(role)+'<select data-cr-key-mode><option value="field"'+(!literal?' selected':'')+'>Original column</option><option value="literal"'+(literal?' selected':'')+'>Explicit fixed value</option></select></label><select data-cr-key-field aria-label="'+e(kind+' '+role+' source field')+'">'+fieldOptions(t?.headers||[],field)+'</select><input data-cr-key-literal aria-label="'+e(kind+' '+role+' fixed value')+'" value="'+e(literal?spec.literal:'')+'" placeholder="Fixed source value"></div>';
      }).join('')+'</div></div>';
    }).join('');
    const person=table(value.sources?.person?.table_id);n('person-type').innerHTML=fieldOptions(person?.headers||[],value.person_type_field||'','No separate person-type rule');
  }
  function fillMapping(value){value=value||emptyMapping();C.restoring=true;renderMappingSources(value);n('map-title').value=value.title;n('key-format').value=value.key_format;n('key-missing').value=(value.key_missing_values||[]).filter(Boolean).join('\n');n('person-type').value=value.person_type_field||'';n('nonmotorist').value=(value.non_motorist_vehicle_values||[]).join('\n');n('parked-types').value=(value.parked_person_type_values||[]).join('\n');n('definition-url').value=value.definition_url||'';n('map-note').value=value.note||'';C.restoring=false;}
  function readMapping(){const sources={};for(const node of n('map-sources').querySelectorAll('[data-cr-map-family]')){const kind=node.dataset.crMapFamily,id=node.querySelector('[data-cr-map-table]').value;if(!id)continue;const keys={};for(const el of node.querySelectorAll('[data-cr-key]'))keys[el.dataset.crKey]=el.querySelector('[data-cr-key-mode]').value==='literal'?{literal:el.querySelector('[data-cr-key-literal]').value}:{field:el.querySelector('[data-cr-key-field]').value};sources[kind]={table_id:id,keys};}
    return {title:n('map-title').value,sources,key_format:n('key-format').value,person_type_field:n('person-type').value||null,non_motorist_vehicle_values:lines(n('nonmotorist').value),parked_person_type_values:lines(n('parked-types').value),key_missing_values:lines(n('key-missing').value),definition_url:n('definition-url').value,note:n('map-note').value};}
  function filterHtml(filter,fields,index){return '<div class="cr-condition" data-cr-filter="'+index+'"><div class="cr-grid"><label>Original column<select data-filter="field">'+fieldOptions(fields,filter.field||'')+'</select></label><label>Condition<select data-filter="op">'+[['in','Is one of these exact values'],['not_in','Is none of these exact values'],['range','Is within numeric bounds'],['missing','Is unavailable'],['present','Is available']].map(([v,label])=>'<option value="'+v+'"'+(v===(filter.op||'in')?' selected':'')+'>'+label+'</option>').join('')+'</select></label><label>Exact values, one per line<textarea data-filter="values">'+e((filter.values||[]).join('\n'))+'</textarea></label><label>Unavailable codes, one per line<textarea data-filter="missing_values">'+e((filter.missing_values||[]).filter(Boolean).join('\n'))+'</textarea></label><label>Minimum<input data-filter="min" value="'+e(filter.min??'')+'" type="number" step="any"></label><label>Maximum<input data-filter="max" value="'+e(filter.max??'')+'" type="number" step="any"></label></div><div class="actions"><button type="button" data-cr-filter-remove="'+index+'">Remove condition</button><button type="button" data-cr-filter-values="'+index+'">Inspect complete source values</button></div></div>';}
  function readFilters(parent){return [...parent.querySelectorAll(':scope > [data-cr-filter]')].map(row=>{const value=f=>row.querySelector('[data-filter="'+f+'"]').value;return {field:value('field'),op:value('op'),values:lines(value('values')),missing_values:lines(value('missing_values')),min:value('min'),max:value('max')};});}
  function renderGroups(groups){C.groups=clone(groups);n('groups').innerHTML=groups.map((g,i)=>'<div class="cr-condition-group" data-cr-group="'+i+'"><h4>Condition group '+(i+1)+'</h4><div class="cr-grid"><label>Original record family<select data-group="entity">'+kinds.filter(k=>map()?.sources[k]).map(k=>'<option value="'+k+'"'+(g.entity===k?' selected':'')+'>'+e(labels[k])+'</option>').join('')+'</select></label><label>Records satisfying every condition<select data-group="quantifier">'+[['any','At least one record'],['none','No record'],['all','Every record, with at least one present']].map(([v,label])=>'<option value="'+v+'"'+((g.quantifier||'any')===v?' selected':'')+'>'+label+'</option>').join('')+'</select></label></div><div data-cr-filters>'+g.filters.map((f,index)=>filterHtml(f,columns(g.entity),index)).join('')+'</div><div class="actions"><button type="button" data-cr-group-add="'+i+'">Add same-record condition</button><button type="button" data-cr-group-remove="'+i+'">Remove group</button></div></div>').join('');}
  function readGroups(){return [...n('groups').querySelectorAll('[data-cr-group]')].map(row=>({entity:row.querySelector('[data-group="entity"]').value,quantifier:row.querySelector('[data-group="quantifier"]').value,filters:readFilters(row.querySelector('[data-cr-filters]'))}));}
  function fillCohort(value){n('cohort-title').value=value?.title||'Original linked crash cohort';n('cohort-note').value=value?.note||'';renderGroups(value?.groups||[]);C.preview=value||null;C.previewSaved=!!value;n('cohort-edition').textContent=value?value.id+' · series '+value.series_id+' · edition '+value.edition:'New cohort series';}
  function readCohort(){if(!map())throw new Error('Save or choose an original source linkage');return {mapping_id:C.mapId,title:n('cohort-title').value,groups:readGroups(),note:n('cohort-note').value};}
  function measureGroupHtml(group,entity,index){
    const fields=group.scope==='crash'?columns('crash'):columns(entity);
    return '<div class="cr-grid" data-cr-measure-group="'+index+'"><label>Grouping source<select data-measure-group="scope"><option value="self"'+(group.scope!=='crash'?' selected':'')+'>This original record</option><option value="crash"'+(group.scope==='crash'?' selected':'')+'>Its one crash parent</option></select></label><label>Grouping column<select data-measure-group="field">'+fieldOptions(fields,group.field||'')+'</select></label><label>Grouping label<input data-measure-group="label" value="'+e(group.label||'')+'"></label><label>Unavailable grouping codes<textarea data-measure-group="missing_values">'+e((group.missing_values||[]).filter(Boolean).join('\n'))+'</textarea></label><button type="button" data-cr-measure-group-remove="'+index+'">Remove grouping</button></div>';
  }
  function renderMeasures(measures){C.measures=clone(measures);n('measures').innerHTML=measures.map((m,i)=>'<div class="cr-measure" data-cr-measure="'+i+'"><h4>Measure '+(i+1)+'</h4><div class="cr-grid"><label>Stable measure ID<input data-measure="id" value="'+e(m.id||'measure-'+(i+1))+'"></label><label>Label<input data-measure="label" value="'+e(m.label||'')+'"></label><label>Original record family<select data-measure="entity">'+kinds.filter(k=>map()?.sources[k]).map(k=>'<option value="'+k+'"'+(m.entity===k?' selected':'')+'>'+e(labels[k])+'</option>').join('')+'</select></label><label>Result<select data-measure="kind">'+[['count','Unique record count'],['distribution','Original value distribution'],['proportion','Share with selected original values'],['numeric','Numeric descriptive summary']].map(([v,label])=>'<option value="'+v+'"'+((m.kind||'count')===v?' selected':'')+'>'+label+'</option>').join('')+'</select></label><label>Original measure column<select data-measure="field">'+fieldOptions(columns(m.entity),m.field||'','Not needed for record count')+'</select></label><label>Original label column<select data-measure="label_field">'+fieldOptions(columns(m.entity),m.label_field||'','Optional source label')+'</select></label><label>Numeric unit<input data-measure="unit" value="'+e(m.unit||'')+'"></label><label>Unavailable original values<textarea data-measure="missing_values">'+e((m.missing_values||[]).filter(Boolean).join('\n'))+'</textarea></label><label>Numerator values, one per line<textarea data-measure="numerator_values">'+e((m.numerator_values||[]).join('\n'))+'</textarea></label><label>Denominator<select data-measure="denominator"><option value="all_records"'+(m.denominator!=='observed_values'?' selected':'')+'>All selected records of this family</option><option value="observed_values"'+(m.denominator==='observed_values'?' selected':'')+'>Records with available measure values</option></select></label><label>Valid numeric minimum<input data-measure="min" type="number" step="any" value="'+e(m.min??'')+'"></label><label>Valid numeric maximum<input data-measure="max" type="number" step="any" value="'+e(m.max??'')+'"></label></div><details><summary>Population conditions on this same original record</summary><div data-cr-measure-filters>'+(m.filters||[]).map((f,j)=>filterHtml(f,columns(m.entity),j)).join('')+'</div><button type="button" data-cr-measure-filter-add="'+i+'">Add population condition</button></details><details><summary>Group results by original columns</summary><div data-cr-measure-groups>'+(m.group_by||[]).map((g,j)=>measureGroupHtml(g,m.entity,j)).join('')+'</div><button type="button" data-cr-measure-group-add="'+i+'">Add result grouping</button></details><button type="button" data-cr-measure-remove="'+i+'">Remove measure</button></div>').join('');}
  function readMeasures(){return [...n('measures').querySelectorAll('[data-cr-measure]')].map(row=>{const v=field=>row.querySelector('[data-measure="'+field+'"]').value;return {id:v('id'),label:v('label'),entity:v('entity'),kind:v('kind'),field:v('field')||null,label_field:v('label_field')||null,unit:v('unit'),missing_values:lines(v('missing_values')),numerator_values:lines(v('numerator_values')),denominator:v('denominator'),min:v('min'),max:v('max'),
      filters:readFilters(row.querySelector('[data-cr-measure-filters]')),group_by:[...row.querySelectorAll('[data-cr-measure-group]')].map(el=>{const g=key=>el.querySelector('[data-measure-group="'+key+'"]').value;return {scope:g('scope'),field:g('field'),label:g('label'),missing_values:lines(g('missing_values'))};})};});}
  function fillPlan(value){n('plan-title').value=value?.title||'Linked cohort descriptive analysis';n('plan-note').value=value?.note||'';renderMeasures(value?.measures||[]);n('plan-edition').textContent=value?value.id+' · series '+value.series_id+' · edition '+value.edition+' · cohort '+value.cohort_id:'New analysis plan series';}
  function readPlan(){if(!cohort())throw new Error('Choose a saved cohort before defining its analysis');return {title:n('plan-title').value,cohort_id:C.cohortId,measures:readMeasures(),note:n('plan-note').value};}
  function sourceRows(){const t=table(n('source-table').value),q=n('source-query').value.toLowerCase();return !t?[]:t.rows.filter(r=>!q||r.id.toLowerCase().includes(q)||r.cells.some(v=>String(v??'').toLowerCase().includes(q)));}
  function renderSource(){const t=table(n('source-table').value);n('source-meta').textContent=t?t.filename+' · '+t.rows.length+' original rows · '+t.headers.length+' columns · SHA-256 '+trajectoryDigest(t.original_text)+'\n'+t.source_url:'Receive or choose a complete original source';
    n('source-column').innerHTML=fieldOptions(t?.headers||[],n('source-column').value||t?.headers[0]||'');
    const selectedColumn=n('source-column').value,index=t?.headers.indexOf(selectedColumn),headers=t?['Original row','Source location',...t.headers.slice(0,4),...(selectedColumn&&!t.headers.slice(0,4).includes(selectedColumn)?[selectedColumn]:[])]:['Original row'];
    n('source-rows').innerHTML=htmlTable(headers,paged(sourceRows(),'source').map(r=>'<tr><td>'+rowRefButton({table_id:t.id,row_id:r.id})+'</td>'+td(r.json_pointer??('line '+(r.physical_line??r.record)))+r.cells.slice(0,4).map(td).join('')+(selectedColumn&&!t.headers.slice(0,4).includes(selectedColumn)?td(r.cells[index]):'')+'</tr>'));
  }
  function renderValues(tableId,field){const t=table(tableId);if(!t||!t.headers.includes(field))throw new Error('Choose an original source column');const col=t.headers.indexOf(field),counts=new Map();
    for(const row of t.rows){const raw=row.cells[col],key=JSON.stringify(raw);if(!counts.has(key))counts.set(key,{raw,count:0,ref:{table_id:t.id,row_id:row.id}});counts.get(key).count++;}
    n('source-values').innerHTML='<p><strong>'+e(t.title+' · '+field)+'</strong> · '+counts.size+' original values across '+t.rows.length+' rows</p>'+htmlTable(['Original value','Rows','First original record'],[...counts.values()].sort((a,b)=>b.count-a.count||String(a.raw).localeCompare(String(b.raw))).map(v=>'<tr>'+td(v.raw===null?'[null]':v.raw===''?'[blank]':v.raw)+td(v.count)+'<td>'+rowRefButton(v.ref)+'</td></tr>'));n('source-values').scrollIntoView({block:'nearest'});}
  function renderLinks(){const index=getIndex();n('link-coverage').innerHTML=index?recordTable(['Original family','Source rows','Excluded','Unique identities','Unresolved identity','Matched crash','Unlinked crash','Non-occupants','Unlinked occupants'],Object.entries(index.coverage).map(([kind,v])=>[labels[kind],v.source_rows,v.excluded_rows,v.unique_records,v.unresolved_identity_rows,v.matched_crash_records,v.unlinked_crash_rows,v.not_vehicle_occupants,v.unlinked_occupant_rows])):'';
    n('link-findings').innerHTML=htmlTable(['Finding','Family','Original records','Detail'],paged(index?.findings||[],'findings').map(v=>'<tr>'+td(v.kind)+td(labels[v.entity]||v.entity)+'<td>'+(v.refs||[]).map(r=>rowRefButton(r)).join(' ')+'</td>'+td(v.detail)+'</tr>'));
  }
  function selectionRows(){const q=n('selection-query').value.toLowerCase(),filter=n('selection-status').value;return (C.preview?.selection||[]).filter(v=>(!filter||v.status===filter)&&(!q||v.crash_key.toLowerCase().includes(q)));}
  function renderSelection(){const value=C.preview;n('cohort-counts').innerHTML=value?[['Included crashes',value.included_crashes],['Excluded crashes',value.excluded_crashes],['Indeterminate crashes',value.indeterminate_crashes]].map(([label,num])=>'<div><strong>'+fmt(num,0)+'</strong><span>'+e(label)+'</span></div>').join(''):'';
    n('selection-table').innerHTML=htmlTable(['Composite crash key','Selection','Original crash','Linked records'],paged(selectionRows(),'selection').map(v=>'<tr><td><button data-cr-crash="'+e(v.crash_key)+'">'+e(v.crash_key)+'</button></td>'+td(v.status)+'<td>'+rowRefButton(v.crash_ref)+'</td>'+td(Object.entries(v.linked_records).filter(([,r])=>r.length).map(([k,r])=>labels[k]+': '+r.length).join(' · '))+'</tr>'));
  }
  function selectCrash(key){const v=C.preview?.selection.find(v=>v.crash_key===key);if(!v)throw new Error('Choose a crash in the current original selection');n('selected-crash').innerHTML='<p class="cr-code">'+e(v.crash_key+' · '+v.status)+'</p>'+v.groups.map(g=>'<h4>'+e(g.id+' · '+labels[g.entity]+' · '+g.quantifier+' · '+(g.result===null?'INDETERMINATE':g.result?'PASS':'DOES NOT MATCH'))+'</h4>'+[['matching_rows','Matching'],['nonmatching_rows','Nonmatching'],['unavailable_rows','Unavailable']].map(([key,label])=>'<p>'+label+': '+(g[key].length?g[key].map(row=>rowRefButton(row)).join(' '):'0')+'</p>').join('')).join('')+Object.entries(v.linked_records).filter(([,rows])=>rows.length).map(([kind,rows])=>'<h4>'+e(labels[kind])+' · '+rows.length+'</h4><div class="actions">'+rows.map(ref=>rowRefButton(ref)).join(' ')+'</div>').join('');n('selected-crash-details').open=true;}
  function pickRow(ref){const nextContext=C.mapId+'|'+ref.table_id+'|'+ref.row_id,changed=C.decisionContext!==nextContext;if(changed&&!C.restoring&&!C.received&&C.row)bankDraft('Before changing the original decision row');const value=crashSourceRow(doc(),ref);C.row={table_id:value.table_id,row_id:value.row.id};if(changed){resetDecisionForm();}const index=getIndex(),linked=Object.values(index?.rows||{}).flat().find(r=>r.ref.table_id===ref.table_id&&r.ref.row_id===ref.row_id);
    n('row-meta').textContent=value.filename+' · '+value.row.id+' · '+(value.row.json_pointer??('physical line '+(value.row.physical_line??value.row.record)))+'\nSource SHA-256 '+value.source_sha256+'\n'+(linked?linked.key+' · '+linked.identity_status+' · crash '+linked.crash_status+(linked.vehicle_status?' · vehicle '+linked.vehicle_status:''):'');
    n('row-values').innerHTML=recordTable(['Original column','Original value'],value.headers.map((h,i)=>[h,value.row.cells[i]===null?'[null]':value.row.cells[i]===''?'[blank]':value.row.cells[i]]));
    n('row-links').innerHTML=[linked?.crash_ref?rowRefButton(linked.crash_ref,'Open original crash'):null,linked?.vehicle_ref?rowRefButton(linked.vehicle_ref,'Open original vehicle'):null].filter(Boolean).join('');renderDecisions();syncControls();}
  function renderDecisions(){const rows=work().decisions.filter(v=>v.mapping_id===C.mapId&&(!C.row||v.table_id===C.row.table_id&&v.row_id===C.row.row_id));n('decisions').innerHTML=recordTable(['Original decision','Row','Use in later editions','Reviewer','Reason','Time'],rows.map(v=>[v.id,v.row_id,v.exclude?'Excluded':'Reinstated',v.reviewer,v.reason,v.at]));}
  function summaryResult(s){if(s.kind==='count')return String(s.count);if(s.kind==='proportion')return fmt(s.numerator,0)+' / '+fmt(s.denominator,0)+' · '+(s.proportion===null?'Unavailable':fmt(s.proportion*100,3)+'%');if(s.kind==='numeric')return 'Mean '+fmt(s.statistics?.mean)+' '+s.unit+' · SD '+fmt(s.statistics?.sd)+' · median '+fmt(s.statistics?.median)+' · numeric n '+fmt(s.statistics?.n,0);return (s.distribution||[]).map(v=>(v.value===null?'[null]':v.value===''?'[blank]':v.value)+' · '+v.count+' ['+v.status+']'+(v.labels?.length?' '+v.labels.join(' / '):'')).join('; ');}
  function renderAnalysis(){const a=analysis(),report=a?.report;n('analysis-meta').textContent=a?a.id+' · plan '+a.plan_id+' · '+a.at+'\nAnalysis SHA-256 '+crashAnalysisDigest(doc(),a.id):'Choose or run a saved analysis';n('analysis-method').textContent=report?.method||'';
    n('analysis-counts').innerHTML=report?Object.entries(report.populations).map(([kind,v])=>'<div><strong>'+fmt(v.records,0)+'</strong><span>'+e(labels[kind]+' records')+'</span></div>').join(''):'';
    n('summary').innerHTML=report?htmlTable(['Measure','Family','Group','Selected records','Observed','Unavailable','Declared denominator','Result'],report.summaries.map((s,i)=>'<tr><td><button data-cr-summary="'+i+'">'+e(s.label)+'</button></td>'+td(labels[s.entity])+td(s.group.map(g=>g.label+'='+(g.value??'Unavailable')).join('; '))+td(s.records)+td(s.observed_values)+td(s.unavailable_values)+td(s.denominator+' · '+(s.denominator_basis==='observed_values'?'available values':'all selected records'))+td(summaryResult(s))+'</tr>')):'';
    choose('observation-measure',(a?work().plans.find(p=>p.id===a.plan_id).measures:[]).map(m=>({id:m.id,label:m.label})),n('observation-measure').value,'Every measure');
    choose('export-family',Object.keys(report?.populations||{}).map(k=>({id:k,label:labels[k]})),n('export-family').value||'crash','Choose record family');renderObservations();renderReviews();
  }
  function renderObservations(){const a=analysis(),measure=n('observation-measure').value,filter=n('observation-status').value,rows=(a?.report.observations||[]).filter(v=>(!measure||v.measure_id===measure)&&(!filter||v.status===filter));
    n('observations').innerHTML=htmlTable(['Measure','Original row','Crash parent','Source value','Source label','Availability','Numeric value / numerator'],paged(rows,'observations').map(v=>'<tr>'+td(v.measure_id)+'<td>'+rowRefButton(v.ref)+'</td><td>'+(v.crash_ref?rowRefButton(v.crash_ref):'')+'</td>'+td(v.raw===null?'[null]':v.raw)+td(v.source_label||'')+td(v.status)+td(v.value??v.numerator??'')+'</tr>'));
    n('population-reviews').innerHTML=htmlTable(['Measure population condition','Original row','Availability'],(a?.report.population_reviews||[]).filter(v=>!measure||v.measure_id===measure).map(v=>'<tr>'+td(v.measure_id)+'<td>'+rowRefButton(v.ref)+'</td>'+td(v.status||v.result)+'</tr>'));
  }
  function renderReviews(){const a=analysis();n('review-binding').textContent=a?'Selected original analysis '+a.id+'\nSHA-256 '+crashAnalysisDigest(doc(),a.id):'Run and select the complete analysis to review';
    n('reviews').innerHTML=recordTable(['Review','Decision','Reviewer','Note','Time'],work().reviews.filter(v=>v.analysis_id===C.analysisId).map(v=>[v.id,v.status,v.reviewer,v.note,v.at]));
    choose('handover-select',work().handovers.map(v=>({id:v.id,label:v.id+' · '+v.title})),C.handoverId||work().handovers.at(-1)?.id||'','Choose retained handover');C.handoverId=n('handover-select').value;
    n('history').innerHTML=recordTable(['Original operation','Action','Time','Saved result'],(doc()?.operations||[]).filter(v=>v.type.startsWith('CRASH_')).map(v=>[v.id,v.type,v.at,JSON.stringify(v.output)]));
  }
  function syncControls(){
    const p=doc(),editable=!!project&&!C.received,blocked=operationRunning||!editable||!!C.pending,stale=C.draftDirty&&C.draftBase!==project?.revision;
    n('pending').hidden=!C.pending;n('pending-text').textContent=C.pending?C.pending.command.type+' · '+C.pending.command.operation_id+' · original study edition '+C.pending.expected_revision:'';
    n('received').hidden=!C.received;n('received-text').textContent=C.received?C.received.handover.handover.title+' · '+C.received.handover.handover.id+'\nFrozen SHA-256 '+C.received.handover.sha256:'';
    n('workspace').classList.toggle('cr-readonly',!!C.received);
    for(const node of n('workspace').querySelectorAll('[data-cr-mutate]'))node.disabled=blocked||stale;
    for(const node of n('workspace').querySelectorAll('[data-cr-edit]'))node.disabled=blocked;
    for(const node of n('workspace').querySelectorAll('[data-cr-draft],#cr-map-sources input,#cr-map-sources select,#cr-groups input,#cr-groups select,#cr-groups textarea,#cr-groups button,#cr-measures input,#cr-measures select,#cr-measures textarea,#cr-measures button'))node.disabled=operationRunning||!editable;
    for(const id of ['save-cohort','add-group','new-cohort'])n(id).disabled=n(id).disabled||!map();n('export-index').disabled=operationRunning||!map();
    for(const id of ['save-plan','add-measure','count-plan','fars-plan','new-plan'])n(id).disabled=n(id).disabled||!cohort();
    n('run-plan').disabled=blocked||stale||!plan();n('save-decision').disabled=blocked||stale||!C.row||!map()||!Object.values(map()?.sources||{}).some(s=>s.table_id===C.row.table_id);
    for(const id of ['save-review','freeze'])n(id).disabled=blocked||stale||!analysis();
    for(const id of ['export-summary','export-analysis','export-rows','compare'])n(id).disabled=operationRunning||!analysis();
    n('export-cohort').disabled=operationRunning||!cohort();for(const id of ['export-handover','export-report'])n(id).disabled=operationRunning||!C.handoverId;
    n('download-source').disabled=operationRunning||!table(n('source-table').value);n('show-values').disabled=operationRunning||!table(n('source-table').value);
    n('recover').disabled=operationRunning||!C.pending||!editable;n('export-pending').disabled=operationRunning||!C.pending;
    n('draft-banner').hidden=!C.draft||!!C.received;n('draft-text').textContent=C.draft?'Forms saved '+C.draft.saved_at+' against study edition '+C.draft.base_revision+(C.draft.applied_operation_id?' · original save '+C.draft.applied_operation_id:'')+(stale?' · reconciliation with current edition '+project.revision+' required':''):'';
    n('restore-draft').disabled=operationRunning||!editable||!C.draft;n('download-draft').disabled=operationRunning||!C.draft;n('reconcile-draft').disabled=operationRunning||!editable||!stale||!!C.pending;n('reopen').disabled=operationRunning||!editable;
    n('load-example').disabled=operationRunning||!globalThis.CRASH_DESK_EXAMPLE;
    n('import-buffer').hidden=!C.importBuffer;n('import-buffer').textContent=C.importBuffer?'Retained original file '+C.importBuffer.filename+' · request '+C.importBuffer.request_id+' · SHA-256 '+trajectoryDigest(C.importBuffer.text):'';
    n('open-draft-edition').disabled=operationRunning||!editable||!n('draft-select').value;
    n('download-draft-edition').disabled=operationRunning||!editable||!n('draft-select').value;
    for(const id of ['open-request','download-request'])n(id).disabled=operationRunning||!n('request-select').value;
    n('restore-request-forms').disabled=operationRunning||!editable||!n('request-select').value||!!C.pending;
    for(const id of ['source-prev','source-next','findings-prev','findings-next','selection-prev','selection-next','observations-prev','observations-next'])if(operationRunning)n(id).disabled=true;
  }
  function sync(force=false){
    try{
      const p=doc(),key=C.received?'received:'+C.received.handover.sha256:'project:'+p?.id,changed=C.context!==key;
      if(changed){bankSavedDraft(C.draft,'Before changing the study or received view');C.restoring=true;for(const [id,value] of Object.entries(defaultFormValues))document.getElementById(id).value=value;n('source-file').value='';C.importBuffer=null;C.context=key;C.mapId=work().mappings.at(-1)?.id||'';C.cohortId=work().cohorts.filter(c=>c.mapping_id===C.mapId).at(-1)?.id||'';C.planId=work().plans.filter(v=>v.cohort_id===C.cohortId).at(-1)?.id||'';selectAnalysis(work().analyses.filter(v=>v.plan_id===C.planId).at(-1)?.id||'');C.handoverId=work().handovers.at(-1)?.id||'';C.indexKey=null;C.row=null;C.draft=null;C.draftDirty=false;C.draftBase=project?.revision??null;C.preview=null;C.pages={source:0,findings:0,selection:0,observations:0};n('row-values').innerHTML='';n('row-links').innerHTML='';n('selected-crash').innerHTML='';n('comparison').innerHTML='';n('source-values').innerHTML='';n('row-meta').textContent='Choose an original row from the source or an analysis.';resetDecisionForm();C.restoring=false;refreshStored();}
      choose('source-table',(p?.tables||[]).map(t=>({id:t.id,label:t.id+' · '+t.title})),C.sourceChoice||n('source-table').value||(p?.tables[0]?.id||''),'Choose original source');C.sourceChoice=null;
      choose('map-select',work().mappings.map(v=>({id:v.id,label:v.id+' · '+v.title})),C.mapId,'New source linkage');
      choose('cohort-select',work().cohorts.filter(v=>v.mapping_id===C.mapId).map(v=>({id:v.id,label:v.id+' · edition '+v.edition+' · '+v.title})),C.cohortId,'New cohort series');
      choose('plan-select',work().plans.filter(v=>work().cohorts.find(c=>c.id===v.cohort_id)?.mapping_id===C.mapId).map(v=>({id:v.id,label:v.id+' · edition '+v.edition+' · '+v.title})),C.planId,'New plan series');
      choose('analysis-select',work().analyses.map(v=>({id:v.id,label:v.id+' · '+work().plans.find(p=>p.id===v.plan_id)?.title})),C.analysisId,'Choose saved analysis');
      choose('compare-select',work().analyses.map(v=>({id:v.id,label:v.id+' · '+v.at})),n('compare-select').value,'Choose another saved analysis');
      if(changed||force){fillMapping(map());fillCohort(cohort());fillPlan(plan());}
      renderSource();renderLinks();renderSelection();renderAnalysis();renderDecisions();syncControls();
    }catch(error){status(error.message,true);}
  }
  function adoptAnalysis(value,fill=true){if(!value)return;selectAnalysis(value.id);const savedPlan=work().plans.find(p=>p.id===value.plan_id),savedCohort=work().cohorts.find(c=>c.id===savedPlan.cohort_id);C.planId=savedPlan.id;C.cohortId=savedCohort.id;C.mapId=savedCohort.mapping_id;C.indexKey=null;C.preview=savedCohort;C.previewSaved=true;if(fill){fillMapping(map());fillCohort(savedCohort);fillPlan(savedPlan);}C.pages.observations=0;}
  function restoreForms(saved){
    if(saved.project_id!==project?.id)throw new Error('This draft belongs to a different study');const f=saved.forms;C.restoring=true;n('source-file').value='';C.importBuffer=null;
    try{C.mapId=f.map_id;C.cohortId=f.cohort_id;C.planId=f.plan_id;selectAnalysis(f.analysis_id);C.handoverId=f.handover_id;C.indexKey=null;sync();fillMapping(f.mapping);renderGroups(f.groups);renderMeasures(f.measures);if(f.row)pickRow(f.row);else{C.row=null;resetDecisionForm();}
      for(const [id,value] of Object.entries(f.values)){const el=document.getElementById(id);if(el){if(el.type==='checkbox')el.checked=!!value;else el.value=value;}}
      if(f.review_context&&f.review_context!==C.reviewContext){n('reviewer').value='';n('review-note').value='';}if(f.decision_context&&f.decision_context!==C.decisionContext)resetDecisionForm();C.preview=null;C.previewSaved=false;C.draft=clone(saved);C.draftDirty=true;C.draftBase=saved.base_revision;C.formGeneration=saved.generation;
    }finally{C.restoring=false;}renderSelection();syncControls();status('The complete saved form is restored. '+(C.draftBase===project.revision?'Save the reviewed definition when ready.':'It retains its original base edition; explicitly reconcile with the current saved study before saving.'));
  }
  function farsMapping(){
    const familyFields={crash:['ST_CASE','FATALS'],vehicle:['st_case','veh_no','body_typ'],person:['st_case','veh_no','per_no']},sources={};
    for(const kind of ['crash','vehicle','person']){const candidates=doc().tables.filter(t=>familyFields[kind].every(field=>t.headers.includes(field)));const current=map()?.sources[kind]?.table_id,selected=candidates.find(t=>t.id===current)||(candidates.length===1?candidates[0]:null);
      if(!selected)throw new Error('Choose the exact '+labels[kind]+' source: '+candidates.length+' possible FARS tables are present');
      const expected=kind==='crash'?{year:'CaseYear',state:'State',crash:'ST_CASE'}:{year:'caseyear',state:'state',crash:'st_case',vehicle:'veh_no',...(kind==='person'?{person:'per_no'}:{})};sources[kind]={table_id:selected.id,keys:expected};
    }
    return {title:'FARS explicit crash / vehicle / person linkage',sources,key_format:'integer_codes',person_type_field:'per_typ',non_motorist_vehicle_values:['0'],parked_person_type_values:['3'],key_missing_values:[],definition_url:'https://www.govinfo.gov/content/pkg/GOVPUB-TD8-PURL-gpo186377/pdf/GOVPUB-TD8-PURL-gpo186377.pdf',note:'Original year/state/crash keys; vehicle/person keys remain within their crash. Nonmotorists with vehicle0 have no occupied vehicle; person type3 requires a separate Parkwork table. Review the manual for the selected case year.'};
  }
  function countMeasures(){return kinds.filter(k=>map()?.sources[k]).map(k=>({id:k+'-count',label:labels[k]+' records',entity:k,kind:'count',filters:[],group_by:[]}));}
  function farsMeasures(){
    const measures=countMeasures();if(!columns('person').includes('inj_sev')||!columns('person').includes('age'))throw new Error('The selected original person source lacks the FARS injury and age columns');
    measures.push({id:'fatal-person',label:'Original Fatal Injury (K) records',entity:'person',kind:'proportion',field:'inj_sev',label_field:'inj_sevname',numerator_values:['4'],denominator:'all_records',missing_values:['9']},
      {id:'person-role',label:'Original person types',entity:'person',kind:'distribution',field:'per_typ',label_field:'per_typname',denominator:'all_records'},
      {id:'age',label:'Recorded age by person type',entity:'person',kind:'numeric',field:'age',unit:'years',missing_values:['998','999'],min:0,max:120,denominator:'observed_values',group_by:[{scope:'self',field:'per_typ',label:'Person type',missing_values:[]}]});
    return measures;
  }
  function exportKind(kind){if(!doc())throw new Error('Open a study or received handover');return crashExport(doc(),{kind,mapping_id:C.mapId,cohort_id:C.cohortId,analysis_id:C.analysisId,handover_id:C.handoverId,entity:n('export-family').value});}
  document.getElementById('cr-open-workspace').addEventListener('click',()=>{if(!operationRunning){showStudyWorkspace('crash');sync();}});
  bind('load-example',async()=>{await draftQueue;const example=globalThis.CRASH_DESK_EXAMPLE;if(!example)throw new Error('This distribution has no published crash example');const existing=await request(db.transaction('projects').objectStore('projects').get(example.id));if(!existing)await save(example);project=reopenCrashProject(existing||example);C.received=null;C.context=null;resetContext();await listProjects();render();showStudyWorkspace('crash');status('Original NHTSA example opened: three complete sources, two saved cohort editions and reviewed handovers.');});
  bind('import-source',async()=>{guardEditable();const selected=n('source-file').files[0],buffer=C.importBuffer?.project_id===project.id?C.importBuffer:null,file=selected||(buffer?{name:buffer.filename,text:async()=>buffer.text}:null);if(!file)throw new Error('Choose the complete original source file or restore its original retained request');const parser=n('source-format').value==='json'?{format:'json',rows_path:JSON.parse(n('source-path').value||'[]'),...(n('source-count').value.trim()?{count_path:JSON.parse(n('source-count').value)}:{})}:{format:'csv',delimiter:n('source-delimiter').value==='tab'?'\t':n('source-delimiter').value};
    await commit({type:'CRASH_IMPORT',title:n('source-title').value||file.name,filename:file.name,text:await file.text(),parser,source_url:n('source-url').value,license:n('source-license').value,source_note:n('source-note').value});});
  bind('download-source',()=>{const t=table(n('source-table').value);if(!t)throw new Error('Choose the original source');download(t.filename,t.original_text,t.format==='json'?'application/json':'text/csv');});
  bind('show-values',()=>renderValues(n('source-table').value,n('source-column').value));
  bind('new-map',async()=>{guardEditable();await bankDraft('Before starting a new linkage');C.mapId='';C.cohortId='';C.planId='';selectAnalysis('');C.indexKey=null;fillMapping(emptyMapping());fillCohort(null);fillPlan(null);sync();retainDraft();});
  bind('fars-map',async()=>{guardEditable();await bankDraft('Before preparing FARS linkage fields');fillMapping(farsMapping());retainDraft();status('FARS source fields prepared. Review each original table and key before saving.');});
  bind('save-map',()=>commit({type:'CRASH_MAP',previous_id:C.mapId||null,mapping:readMapping()}));
  bind('new-cohort',async()=>{guardEditable();await bankDraft('Before starting a new cohort series');C.cohortId='';C.planId='';selectAnalysis('');fillCohort(null);fillPlan(null);sync();retainDraft();});
  bind('add-group',()=>{guardEditable();const entity=map()?.sources.person?'person':'crash',groups=readGroups();groups.push({entity,quantifier:'any',filters:[{field:'',op:'in',values:[],missing_values:[]}]});renderGroups(groups);retainDraft();});
  bind('preview-cohort',()=>{C.preview=previewCrashCohort(doc(),readCohort());C.previewSaved=false;C.pages.selection=0;renderSelection();status('Complete original-row preview: '+C.preview.included_crashes+' included, '+C.preview.excluded_crashes+' excluded and '+C.preview.indeterminate_crashes+' indeterminate crashes.');});
  bind('save-cohort',()=>commit({type:'CRASH_COHORT',previous_id:C.cohortId||null,cohort:readCohort()}));
  bind('new-plan',async()=>{guardEditable();await bankDraft('Before starting a new analysis plan');C.planId='';selectAnalysis('');fillPlan(null);sync();retainDraft();});
  bind('count-plan',async()=>{guardEditable();await bankDraft('Before preparing count measures');renderMeasures(countMeasures());retainDraft();});
  bind('fars-plan',async()=>{guardEditable();await bankDraft('Before preparing FARS measures');renderMeasures(farsMeasures());n('plan-note').value='Descriptive results retain independent record-family denominators. Review FARS definitions for the selected case year. No traffic exposure or population risk denominator is supplied.';retainDraft();});
  bind('add-measure',()=>{guardEditable();const measures=readMeasures();measures.push({id:'measure-'+uid(),label:'',entity:'crash',kind:'count',filters:[],group_by:[]});renderMeasures(measures);retainDraft();});
  bind('save-plan',()=>commit({type:'CRASH_PLAN',previous_id:C.planId||null,plan:readPlan()}));
  bind('run-plan',()=>{if(!plan())throw new Error('Save and choose an analysis plan');return commit({type:'CRASH_RUN',plan_id:C.planId});});
  bind('save-decision',()=>{if(!C.row)throw new Error('Choose the exact original row');if(C.decisionContext!==C.mapId+'|'+C.row.table_id+'|'+C.row.row_id)throw new Error('Reopen the original row before recording its decision');return commit({type:'CRASH_DECISION',mapping_id:C.mapId,...C.row,exclude:n('decision-kind').value==='exclude',reviewer:n('decision-reviewer').value,reason:n('decision-reason').value});});
  bind('save-review',()=>{if(!analysis())throw new Error('Choose a saved analysis');if(C.reviewContext!==doc().id+'|'+C.analysisId)throw new Error('Reopen the selected analysis before recording its review');return commit({type:'CRASH_REVIEW',analysis_id:C.analysisId,expected_analysis_sha256:crashAnalysisDigest(doc(),C.analysisId),status:n('review-status').value,reviewer:n('reviewer').value,note:n('review-note').value});});
  bind('freeze',()=>commit({type:'CRASH_HANDOVER',analysis_id:C.analysisId,title:n('handover-title').value||plan()?.title+' · reviewed research handover'}));
  bind('recover',()=>commit(null,true));
  bind('export-pending',async()=>{const p=await readPending();if(!p)throw new Error('No pending original operation');download(p.command.operation_id+'.json',JSON.stringify(p,null,2)+'\n');});
  bind('restore-draft',async()=>{await bankDraft('Before restoring current saved forms');const saved=await auxGet(draftKey(project?.id));if(!saved)throw new Error('No retained form draft for this study');restoreForms(saved);});
  bind('reconcile-draft',()=>{if(!C.draftDirty)throw new Error('Restore the saved form before reconciling');if(C.pending)throw new Error('Resolve the original request first');C.draftBase=project.revision;retainDraft();status('The restored form now explicitly uses study edition '+project.revision+'. Review its selected source and previous cohort/plan edition before saving.');});
  bind('download-draft',async()=>{const draft=await auxGet(draftKey(project?.id));if(!draft)throw new Error('No retained form draft');download(project.id+'-cohort-draft.json',JSON.stringify(draft,null,2)+'\n');});
  bind('reopen',async()=>{await draftQueue;const id=project?.id;if(!id)throw new Error('Open a saved study');project=reopenCrashProject(await request(db.transaction('projects').objectStore('projects').get(id)));C.context=null;render();await listProjects();await refreshStored();status('Current study reopened. Its separately retained draft is available for deliberate reconciliation.');});
  bind('compare',()=>{if(!analysis()||!n('compare-select').value)throw new Error('Choose two original saved analyses');const comparisons=crashCompareAnalyses(doc(),n('compare-select').value,C.analysisId);n('comparison').innerHTML=htmlTable(['Analysis','Measure','Family','Group','Records','Denominator','Result'],comparisons.flatMap(a=>a.summaries.map(s=>'<tr>'+td(a.analysis_id)+td(s.label)+td(labels[s.entity])+td(s.group.map(g=>g.label+'='+(g.value??'Unavailable')).join('; '))+td(s.records)+td(s.denominator+' · '+s.denominator_basis)+td(summaryResult(s))+'</tr>')));});
  for(const [id,kind,extension,type] of [['export-index','crash_index','json','application/json'],['export-cohort','crash_cohort','json','application/json'],['export-summary','crash_summary','csv','text/csv'],['export-analysis','crash_analysis','json','application/json'],['export-rows','crash_rows','csv','text/csv'],['export-handover','crash_handover','json','application/json'],['export-report','crash_report','md','text/markdown']])bind(id,()=>{const text=kind==='crash_handover'&&C.received?C.received.text:exportKind(kind);download((kind==='crash_index'?C.mapId:kind==='crash_cohort'?C.cohortId:kind.includes('handover')||kind==='crash_report'?C.handoverId:C.analysisId)+'-'+kind+'.'+extension,text,type);status('Complete '+kind.replace('crash_','')+' exported.');});
  async function openReceived(record){const value=inspectCrashHandover(record.text),context=crashHandoverContext(value);C.received={handover:value,context,text:record.text};C.context=null;sync(true);showStudyWorkspace('crash');status('Received the complete original files, recomputed every saved cohort and analysis, and opened the frozen reviewed history.');}
  bind('receive',async()=>{const file=n('receive-file').files[0];if(!file)throw new Error('Choose the complete original handover JSON');const text=await file.text(),value=inspectCrashHandover(text),record={key:'received|'+trajectoryDigest(text),kind:'received',text,title:value.handover.title,handover_id:value.handover.id,project_id:value.handover.project_context.id,received_at:stamp(),filename:file.name};await auxWrite(store=>store.put(record));await openReceived(record);await refreshStored();});
  bind('open-received',async()=>{const record=await auxGet(n('received-select').value);if(!record||record.kind!=='received')throw new Error('Choose a retained handover');await openReceived(record);});
  bind('return-study',()=>{C.received=null;C.context=null;sync(true);status('Returned to the original editable study.');});
  function selectReceivedEdition(kind,id){
    try{
      if(!id)throw new Error('Choose an existing edition in this received handover');
      if(kind==='map'){
        if(!work().mappings.some(v=>v.id===id))throw new Error('Unknown received source linkage');
        C.mapId=id;C.cohortId=work().cohorts.filter(v=>v.mapping_id===id).at(-1)?.id||'';C.planId=work().plans.filter(v=>v.cohort_id===C.cohortId).at(-1)?.id||'';
      }else if(kind==='cohort'){
        const value=work().cohorts.find(v=>v.id===id);if(!value)throw new Error('Unknown received cohort edition');C.cohortId=id;C.mapId=value.mapping_id;C.planId=work().plans.filter(v=>v.cohort_id===id).at(-1)?.id||'';
      }else{
        const value=work().plans.find(v=>v.id===id);if(!value)throw new Error('Unknown received analysis plan');C.planId=id;C.cohortId=value.cohort_id;C.mapId=cohort().mapping_id;
      }
      selectAnalysis(work().analyses.filter(v=>v.plan_id===C.planId).at(-1)?.id||'');C.row=null;resetDecisionForm();C.indexKey=null;fillMapping(map());fillCohort(cohort());fillPlan(plan());sync();
      status('Opened original received '+kind+' edition '+id+'. Exports use this selected saved history.');
    }catch(error){sync();status(error.message,true);}
  }
  async function originalRequest(){
    const id=n('request-select').value;if(!id)throw new Error('Choose an original browser request');
    const record=await auxGet(operationKey(id));if(!record||record.project_id!==doc()?.id)throw new Error('This request does not belong to the selected study');C.requestId=id;return record;
  }
  async function selectedDraftEdition(){
    const value=await auxGet(n('draft-select').value);if(!value||value.project_id!==project?.id||!value.key.startsWith('draft-edition|'))throw new Error('Choose a prior form edition belonging to this study');return value;
  }
  bind('open-draft-edition',async()=>{if(C.received)throw new Error('Return to the editable study to restore forms');await bankDraft('Before restoring a prior form edition');restoreForms(await selectedDraftEdition());});
  bind('download-draft-edition',async()=>{const value=await selectedDraftEdition();download(value.project_id+'-draft-'+value.id+'.json',JSON.stringify(value,null,2)+'\n');});
  bind('open-request',async()=>{const record=await originalRequest(),display=clone(record);if(typeof display.command.text==='string'){display.original_text={filename:display.command.filename,bytes:new TextEncoder().encode(display.command.text).length,sha256:trajectoryDigest(display.command.text)};display.command.text='Complete original source text is retained in the downloadable request.';}n('request-detail').textContent=JSON.stringify(display,null,2);});
  bind('download-request',async()=>{const record=await originalRequest();download(record.command.operation_id+'-complete-request.json',JSON.stringify(record,null,2)+'\n');});
  bind('restore-request-forms',async()=>{
    if(C.received)throw new Error('Return to the editable study to restore authored inputs');
    const record=await originalRequest();if(record.state==='pending')throw new Error('Use Recover original operation to continue this retained pending request');
    const saved={schema:'tjlabs.crash-form-draft/v1',id:uid(),project_id:record.project_id,base_revision:record.expected_revision,saved_at:stamp(),generation:0,forms:clone(record.submitted_forms)};
    await bankDraft('Before restoring original submitted forms');restoreForms(saved);
    if(record.command.type==='CRASH_IMPORT'){
      C.importBuffer={project_id:project.id,request_id:record.command.operation_id,filename:record.command.filename,text:record.command.text};n('source-file').value='';
    }
    retainDraft();syncControls();status('The exact submitted forms'+(C.importBuffer?' and complete original source bytes':'')+' are restored. Reconcile their original base edition before saving revised inputs.');
  });
  n('draft-select').addEventListener('change',syncControls);n('request-select').addEventListener('change',()=>{C.requestId=n('request-select').value;syncControls();});
  n('source-file').addEventListener('change',()=>{if(n('source-file').files[0]){C.importBuffer=null;syncControls();}});
  n('source-table').addEventListener('change',()=>{C.pages.source=0;n('source-values').innerHTML='';renderSource();syncControls();});
  n('source-query').addEventListener('input',()=>{C.pages.source=0;renderSource();});
  n('source-column').addEventListener('change',renderSource);
  n('map-select').addEventListener('change',()=>{const selected=n('map-select').value;runSelection(async()=>{if(C.received){selectReceivedEdition('map',selected);return;}if(!project)return;await bankDraft('Before selecting another map edition');C.mapId=selected;C.cohortId=work().cohorts.filter(v=>v.mapping_id===C.mapId).at(-1)?.id||'';C.planId=work().plans.filter(v=>v.cohort_id===C.cohortId).at(-1)?.id||'';selectAnalysis(work().analyses.filter(v=>v.plan_id===C.planId).at(-1)?.id||'');C.indexKey=null;C.row=null;C.draftBase=project.revision;fillMapping(map());fillCohort(cohort());fillPlan(plan());sync();retainDraft();await draftQueue;});});
  n('cohort-select').addEventListener('change',()=>{const selected=n('cohort-select').value;runSelection(async()=>{if(C.received){selectReceivedEdition('cohort',selected);return;}if(!project)return;await bankDraft('Before selecting another cohort edition');C.cohortId=selected;C.planId=work().plans.filter(v=>v.cohort_id===C.cohortId).at(-1)?.id||'';selectAnalysis(work().analyses.filter(v=>v.plan_id===C.planId).at(-1)?.id||'');fillCohort(cohort());fillPlan(plan());C.pages.selection=0;sync();retainDraft();await draftQueue;});});
  n('plan-select').addEventListener('change',()=>{const selected=n('plan-select').value;runSelection(async()=>{if(C.received){selectReceivedEdition('plan',selected);return;}if(!project)return;await bankDraft('Before selecting another plan edition');C.planId=selected;if(plan()){C.cohortId=plan().cohort_id;C.mapId=cohort().mapping_id;fillMapping(map());fillCohort(cohort());}selectAnalysis(work().analyses.filter(v=>v.plan_id===C.planId).at(-1)?.id||'');fillPlan(plan());sync();retainDraft();await draftQueue;});});
  n('analysis-select').addEventListener('change',()=>{const selected=n('analysis-select').value;runSelection(async()=>{if(!C.received)await bankDraft('Before selecting another saved analysis');selectAnalysis(selected);adoptAnalysis(analysis());n('comparison').innerHTML='';sync();if(!C.received){retainDraft();await draftQueue;}});});
  n('handover-select').addEventListener('change',()=>{C.handoverId=n('handover-select').value;syncControls();});
  for(const id of ['selection-status','selection-query'])n(id).addEventListener(id.endsWith('query')?'input':'change',()=>{C.pages.selection=0;renderSelection();});
  for(const id of ['observation-measure','observation-status'])n(id).addEventListener('change',()=>{C.pages.observations=0;renderObservations();});
  for(const [kind,renderPage] of [['source',renderSource],['findings',renderLinks],['selection',renderSelection],['observations',renderObservations]])for(const [suffix,step] of [['prev',-1],['next',1]])bind(kind+'-'+suffix,()=>{C.pages[kind]+=step;renderPage();});
  n('workspace').addEventListener('input',event=>{if(operationRunning||C.received)return;const target=event.target;if(target.matches('[data-cr-draft]')||target.closest('#cr-map-sources,#cr-groups,#cr-measures')){if(target.closest('#cr-groups')){C.preview=null;C.previewSaved=false;renderSelection();}retainDraft();}});
  n('workspace').addEventListener('change',event=>{
    if(operationRunning||C.received)return;const target=event.target;
    if(target.matches('[data-cr-map-table]'))edit(()=>{const value=readMapping();renderMappingSources(value);});
    else if(target.matches('[data-group="entity"]'))edit(()=>renderGroups(readGroups()));
    else if(target.matches('[data-measure="entity"],[data-measure-group="scope"]'))edit(()=>renderMeasures(readMeasures()));
    else if(target.matches('[data-cr-draft]')||target.closest('#cr-map-sources,#cr-groups,#cr-measures'))retainDraft();
  });
  n('workspace').addEventListener('click',event=>{
    const button=event.target.closest('button');if(!button||operationRunning)return;
    try{
      if(button.dataset.crRow){const ref={table_id:button.dataset.crRow,row_id:button.dataset.crRowId};runSelection(async()=>{if(!C.received)await bankDraft('Before selecting another original row');pickRow(ref);if(!C.received){retainDraft();await draftQueue;}n('row-meta').scrollIntoView({block:'nearest'});});return;}
      if(button.dataset.crCrash){selectCrash(button.dataset.crCrash);return;}
      if(button.dataset.crSummary!==undefined){const s=analysis()?.report.summaries[Number(button.dataset.crSummary)];if(!s)return;n('observation-measure').value=s.measure_id;n('observation-status').value='';C.pages.observations=0;renderObservations();n('observations').closest('details').open=true;return;}
      if(C.received||!project)return;
      const group=button.closest('[data-cr-group]'),measure=button.closest('[data-cr-measure]');
      if(button.dataset.crFilterValues!==undefined){const filter=button.closest('[data-cr-filter]'),field=filter.querySelector('[data-filter="field"]').value,entity=group?group.querySelector('[data-group="entity"]').value:measure.querySelector('[data-measure="entity"]').value;renderValues(map()?.sources[entity]?.table_id,field);return;}
      if(group)edit(()=>{const groups=readGroups(),index=Number(group.dataset.crGroup);
        if(button.dataset.crGroupAdd!==undefined)groups[index].filters.push({field:'',op:'in',values:[],missing_values:[]});
        else if(button.dataset.crGroupRemove!==undefined)groups.splice(index,1);
        else if(button.dataset.crFilterRemove!==undefined)groups[index].filters.splice(Number(button.dataset.crFilterRemove),1);
        else return;renderGroups(groups);C.preview=null;renderSelection();
      });
      if(measure)edit(()=>{const measures=readMeasures(),index=Number(measure.dataset.crMeasure);
        if(button.dataset.crMeasureRemove!==undefined)measures.splice(index,1);
        else if(button.dataset.crMeasureFilterAdd!==undefined)measures[index].filters.push({field:'',op:'in',values:[],missing_values:[]});
        else if(button.dataset.crFilterRemove!==undefined)measures[index].filters.splice(Number(button.dataset.crFilterRemove),1);
        else if(button.dataset.crMeasureGroupAdd!==undefined)measures[index].group_by.push({scope:'self',field:'',label:'',missing_values:[]});
        else if(button.dataset.crMeasureGroupRemove!==undefined)measures[index].group_by.splice(Number(button.dataset.crMeasureGroupRemove),1);
        else return;renderMeasures(measures);
      });
    }catch(error){status(error.message,true);}
  });
  document.addEventListener('study-workspace-render',()=>{if(C.projectId!==project?.id){C.projectId=project?.id;C.received=null;C.context=null;}sync();});
  document.addEventListener('study-workspace-ready',()=>{renderSource();renderLinks();renderSelection();renderObservations();syncControls();});
  document.addEventListener('study-view-changed',event=>{if(event.detail==='crash')sync();});
  window.addEventListener('focus',()=>{refreshStored();});
  auxReady.then(()=>{sync();refreshStored();}).catch(error=>status('The component operation store could not be opened: '+error.message,true));
})();
