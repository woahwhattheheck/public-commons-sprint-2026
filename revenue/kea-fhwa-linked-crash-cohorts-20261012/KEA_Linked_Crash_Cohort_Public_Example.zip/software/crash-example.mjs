import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { createProject } from './core.mjs';
import { applyCrashCommand, reopenCrashProject, materializeCrashHandover, inspectCrashHandover, crashSummaryCSV, crashRowsCSV, crashReportMarkdown } from './crash_core.mjs';
const sourceBase=new URL('./example/crash/',import.meta.url);
export async function loadCrashExample(){
  const spec=JSON.parse(await readFile(new URL('commands.json',sourceBase),'utf8'));
  const manifest=JSON.parse(await readFile(new URL('source.json',sourceBase),'utf8'));
  let project=createProject(spec.project);const outcomes=[],commands=[];
  for(const original of spec.commands){
    const command={...original};
    if(command.type==='CRASH_IMPORT'){
      const raw=await readFile(new URL(command.file,sourceBase)),source=manifest.files.find(s=>s.file===command.file);
      if(!source||raw.length!==source.bytes||createHash('sha256').update(raw).digest('hex')!==source.sha256)throw new Error('The complete original source differs: '+command.file);
      command.text=raw.toString('utf8');delete command.file;
    }
    const result=applyCrashCommand(project,command);project=result.project;commands.push(command);outcomes.push(result.output);
  }
  reopenCrashProject(project);
  for(const handover of project.crash.handovers)inspectCrashHandover(materializeCrashHandover(project,handover.id));
  return {project,commands,outcomes,manifest};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const destination=resolve(process.argv[2]||'crash-example-output'),result=await loadCrashExample();
  await mkdir(destination,{recursive:true,mode:0o700});
  const outputs={'study-project.json':JSON.stringify(result.project,null,2)+'\n','source.json':JSON.stringify(result.manifest,null,2)+'\n','operation-results.json':JSON.stringify(result.outcomes,null,2)+'\n'};
  for(const handover of result.project.crash.handovers){
    const runId=handover.analysis_id;outputs[handover.id+'.json']=JSON.stringify(materializeCrashHandover(result.project,handover.id),null,2)+'\n';
    outputs[handover.id+'.md']=crashReportMarkdown(result.project,handover.id);outputs[runId+'-summary.csv']=crashSummaryCSV(result.project,runId);
    for(const entity of ['crash','vehicle','person'])outputs[runId+'-'+entity+'.csv']=crashRowsCSV(result.project,runId,entity);
  }
  for(const [name,text] of Object.entries(outputs)){
    const path=resolve(destination,name);try{await writeFile(path,text,{flag:'wx',mode:0o600});}
    catch(error){if(error.code!=='EEXIST'||await readFile(path,'utf8')!==text)throw error;}
  }
  process.stdout.write(JSON.stringify({project_id:result.project.id,revision:result.project.revision,operations:result.outcomes.length,analyses:result.project.crash.analyses.map(a=>({id:a.id,crashes:a.report.populations.crash.records,vehicles:a.report.populations.vehicle.records,people:a.report.populations.person.records})),files:Object.keys(outputs).map(name=>resolve(destination,name))})+'\n');
}
