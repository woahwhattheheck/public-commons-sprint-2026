
const $=id=>document.getElementById(id), escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let project=null,metricDraft=[],db;
const stamp=()=>new Date().toISOString(), uid=()=>globalThis.crypto?.randomUUID?.()||Date.now()+'-'+Math.random().toString(36).slice(2);
const notice=t=>$('notice').textContent=t, selected=id=>[...$(id).selectedOptions].map(o=>o.value);
function option(items,id,label){return items.map(x=>'<option value="'+escape(x.id)+'">'+escape(label(x))+'</option>').join('');}
function tableView(headers,rows){return '<table><thead><tr>'+headers.map(x=>'<th>'+escape(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(x=>'<td class="wrap">'+escape(typeof x==='object'&&x!==null?JSON.stringify(x):x)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';}
function download(name,text,type='application/json'){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
const source=()=>project?.tables.find(t=>t.id===$('table-select').value);
const run=()=>project?.runs.find(r=>r.id===$('run-select').value);
const handover=()=>{const h=project?.handovers.find(h=>h.id===$('handover-select').value);return h?materializeHandover(project,h.id):undefined;};
function request(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async function openDatabase(){db=await new Promise((resolve,reject)=>{const r=indexedDB.open('tjlabs-study-data-desk',1);r.onupgradeneeded=()=>r.result.createObjectStore('projects',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function listProjects(){const all=await request(db.transaction('projects').objectStore('projects').getAll());$('project-select').innerHTML='<option value="">Choose a project</option>'+option(all,null,p=>p.title+' · edition '+p.revision);if(project)$('project-select').value=project.id;}
async function save(p,expected=null){await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readwrite'),s=tx.objectStore('projects'),r=s.get(p.id);let why;
 r.onsuccess=()=>{const existing=r.result;if(expected===null?!!existing:!existing||existing.revision!==expected){why=Object.assign(new Error('This project changed in another window. Reopen its saved edition before continuing.'),{code:'study_changed'});tx.abort();return;}s.put(p);};
 tx.oncomplete=resolve;tx.onerror=()=>reject(why||tx.error);tx.onabort=()=>reject(why||tx.error||new Error('Project save was interrupted'));});}
async function act(c){if(!project)throw new Error('Create or open a study first');const before=project.revision,result=applyCommand(project,{...c,operation_id:uid(),at:stamp()});await save(result.project,before);project=result.project;await listProjects();render();return result.output;}
function remember(id,html){const old=$(id).value;$(id).innerHTML=html;if([...$(id).options].some(x=>x.value===old))$(id).value=old;}
function resetPlan(){metricDraft=[];renderMetrics();for(const id of ['participant-fields','group-fields','scenario-fields','key-fields'])for(const o of $(id).options)o.selected=false;for(const id of ['plan-title','expected-scenarios','plan-note'])$(id).value='';$('missing-values').value='NA,N/A,NaN';$('plan-select').value='';}
function resetContext(){for(const id of ['table-select','plan-select','run-select','handover-select'])$(id).innerHTML='';resetPlan();for(const id of ['decision-row','decision-reviewer','decision-reason','reviewer','review-note','handover-title','table-title','source-url','source-license','source-note','source-file'])$(id).value='';}
function loadPlan(p){if(!p){resetPlan();return;}$('table-select').value=p.table_id;renderSource();$('plan-title').value=p.title;
for(const [id,field] of [['participant-fields','participant_fields'],['group-fields','group_fields'],['scenario-fields','scenario_fields'],['key-fields','row_key_fields']])for(const o of $(id).options)o.selected=p[field].includes(o.value);
$('expected-scenarios').value=p.expected_scenarios??'';$('missing-values').value=p.missing_values.filter(Boolean).join(',');$('plan-note').value=p.note;metricDraft=p.metrics.map(m=>({...m}));renderMetrics();}
function render(){if(!project)return;$('project-label').textContent=project.title+' · edition '+project.revision;
$('project-counts').innerHTML='<dl><dt>Source tables</dt><dd>'+project.tables.length+'</dd><dt>Plans</dt><dd>'+project.plans.length+'</dd><dt>Analyses</dt><dd>'+project.runs.length+'</dd><dt>Handovers</dt><dd>'+project.handovers.length+'</dd></dl>';
remember('table-select',option(project.tables,null,t=>t.title+' · '+t.rows.length+' rows'));renderSource();
remember('plan-select','<option value="">New plan</option>'+option(project.plans,null,p=>p.id+' · '+p.title));
remember('run-select',option(project.runs,null,r=>r.id+' · '+r.at));
remember('handover-select',option(project.handovers,null,h=>h.id+' · '+h.title));renderRun();document.dispatchEvent(new Event('study-workspace-render'));}
function renderSource(){const t=source();if(!t){for(const id of ['source-meta','column-profile','source-preview'])$(id).textContent='';for(const id of ['participant-fields','group-fields','scenario-fields','key-fields','metric-column'])$(id).innerHTML='';return;}$('source-meta').textContent=t.filename+' · '+t.rows.length+' rows · '+t.headers.length+' columns · received '+t.at+' · preview shows '+Math.min(100,t.rows.length)+' rows; analysis uses the complete table';
$('column-profile').innerHTML=tableView(['Column','Present','Blank','Numeric','Distinct','Examples'],tableProfile(t).columns.map(c=>[c.name,c.present,c.blank,c.numeric,c.distinct,c.examples.join(' / ')]));
$('source-preview').innerHTML=tableView(['Row ID',...t.headers],t.rows.slice(0,100).map(r=>[r.id,...r.cells]));
for(const id of ['participant-fields','group-fields','scenario-fields','key-fields','metric-column']){const old=selected(id);$(id).innerHTML=t.headers.map(h=>'<option value="'+escape(h)+'">'+escape(h)+'</option>').join('');for(const o of $(id).options)o.selected=old.includes(o.value);}
$('table-title').placeholder=t.title;$('plan-title').placeholder=t.title+' analysis';}
function renderMetrics(){$('metrics').innerHTML=metricDraft.map((m,i)=>'<div class="metric" data-metric="'+i+'"><strong>'+escape(m.column)+'</strong><div class="fields">'+[['label','Label'],['unit','Output unit'],['scale','Scale'],['offset','Offset'],['min','Minimum'],['max','Maximum']].map(([key,label])=>'<label>'+label+'<input data-field="'+key+'" value="'+escape(m[key]??'')+'"></label>').join('')+'</div><button data-remove="'+i+'">Remove measure</button></div>').join('');}
function readMetrics(){return [...$('metrics').querySelectorAll('[data-metric]')].map(el=>({...metricDraft[Number(el.dataset.metric)],...Object.fromEntries([...el.querySelectorAll('[data-field]')].map(x=>[x.dataset.field,x.value]))}));}
function renderRun(){const r=run();if(!r){$('coverage').textContent='Run a saved plan to inspect its complete source cohort.';$('summary').innerHTML='';$('issues').innerHTML='';$('reviews').innerHTML='';return;}const a=r.analysis;
$('coverage').innerHTML='<p><strong>'+a.participants.length+' participants</strong> · '+a.source_rows+' original rows · '+a.included_rows+' included · '+a.excluded_rows+' excluded · '+a.invalid_identity_rows+' invalid identity</p><p class="muted">'+escape(a.method)+'</p>';
const fmt=v=>v===null?'—':Number(v).toFixed(4);
$('summary').innerHTML=tableView(['Group','Scenario','Measure','Unit','Participants','Mean','SD','Median','Unavailable rows'],a.summaries.map(s=>[s.group.join(' / '),s.scenario===null?'All observed':s.scenario.join(' / '),s.label,s.unit,s.participant_statistics.n,fmt(s.participant_statistics.mean),fmt(s.participant_statistics.sd),fmt(s.participant_statistics.median),s.unavailable_rows]));
$('issues').innerHTML=tableView(['Finding','Row / participant','Column','Detail'],a.issues.map(i=>[i.kind,i.row_id||i.participant,i.column||'',i.detail]));
$('reviews').innerHTML=tableView(['Review','Decision','Reviewer','Note'],project.reviews.filter(v=>v.run_id===r.id).map(v=>[v.id,v.status,v.reviewer,v.note]));}
let operationRunning=false;
function wire(id,fn){$(id).addEventListener('click',async()=>{
 if(operationRunning)return;operationRunning=true;document.dispatchEvent(new Event('study-workspace-busy'));
 const controls=[...document.querySelectorAll('button,input,select,textarea')].map(node=>[node,node.disabled]);
 controls.forEach(([node])=>{node.disabled=true;});
 try{notice('');await fn();}catch(error){notice(error.message);}
 finally{controls.forEach(([node,disabled])=>{node.disabled=disabled;});operationRunning=false;document.dispatchEvent(new Event('study-workspace-ready'));}
});}
wire('new-project',async()=>{const p=createProject({id:'study-'+uid(),title:$('project-title').value,case_id:$('project-case').value,source_note:$('project-note').value,at:stamp()});await save(p);project=p;resetContext();await listProjects();render();notice('Study created and saved.');});
wire('open-project',async()=>{const id=$('project-select').value;if(!id)throw new Error('Choose a saved project');project=reopenCrashProject(await request(db.transaction('projects').objectStore('projects').get(id)));resetContext();render();notice('Saved study reopened.');});
wire('restore-project',async()=>{const file=$('project-file').files[0];if(!file)throw new Error('Choose a complete project JSON file');const p=reopenCrashProject(await file.text());const existing=await request(db.transaction('projects').objectStore('projects').get(p.id));if(existing){if(JSON.stringify(existing)!==JSON.stringify(p))throw new Error('A different saved edition already uses this study ID. Export the existing project and restore in a separate browser workspace.');}else await save(p);project=p;resetContext();await listProjects();render();notice('Complete study restored.');});
wire('backup-project',async()=>{if(!project)throw new Error('Open a study');download(project.id+'.json',JSON.stringify(project,null,2)+'\n');});
wire('import-source',async()=>{const f=$('source-file').files[0];if(!f)throw new Error('Choose the original data file');const out=await act({type:'IMPORT',title:$('table-title').value||f.name,filename:f.name,text:await f.text(),format:/\.json$/i.test(f.name)?'json':'csv',delimiter:$('delimiter').value==='tab'?'\t':$('delimiter').value,source_url:$('source-url').value,license:$('source-license').value,source_note:$('source-note').value});$('table-select').value=out.table_id;resetPlan();renderSource();notice('Received '+out.rows+' complete source records.');});
$('table-select').addEventListener('change',()=>{resetPlan();renderSource();});
wire('add-metric',async()=>{metricDraft=readMetrics();const column=$('metric-column').value;if(!column)throw new Error('Choose a source measure');if(metricDraft.some(m=>m.column===column))throw new Error('That measure is already selected');metricDraft.push({column,label:column,unit:'',scale:1,offset:0,min:'',max:''});renderMetrics();});
$('metrics').addEventListener('click',e=>{if(e.target.dataset.remove!==undefined){metricDraft=readMetrics();metricDraft.splice(Number(e.target.dataset.remove),1);renderMetrics();}});
$('plan-select').addEventListener('change',()=>loadPlan(project?.plans.find(p=>p.id===$('plan-select').value)));
wire('save-plan',async()=>{const out=await act({type:'PLAN',previous_id:$('plan-select').value||null,plan:{title:$('plan-title').value,table_id:$('table-select').value,participant_fields:selected('participant-fields'),group_fields:selected('group-fields'),scenario_fields:selected('scenario-fields'),row_key_fields:selected('key-fields'),metrics:readMetrics(),missing_values:['',...$('missing-values').value.split(',').map(x=>x.trim()).filter(Boolean)],expected_scenarios:$('expected-scenarios').value,note:$('plan-note').value}});$('plan-select').value=out.plan_id;notice('Analysis edition saved.');});
wire('run-analysis',async()=>{if(!$('plan-select').value)throw new Error('Save or select an analysis plan');const out=await act({type:'RUN',plan_id:$('plan-select').value});$('run-select').value=out.run_id;renderRun();notice('Saved '+out.run_id+': '+out.participants+' participants; '+out.issues+' review findings.');});
$('run-select').addEventListener('change',()=>{for(const id of ['reviewer','review-note','decision-row','decision-reason'])$(id).value='';const r=run();if(r){$('plan-select').value=r.plan.id;loadPlan(r.plan);}renderRun();});
wire('save-decision',async()=>{const t=source();if(!t)throw new Error('Choose the source table');await act({type:'DECISION',table_id:t.id,row_id:$('decision-row').value,exclude:$('decision-kind').value==='exclude',reviewer:$('decision-reviewer').value,reason:$('decision-reason').value});notice('Source decision saved. Run the plan again to calculate a new edition.');});
wire('export-summary',async()=>{if(!run())throw new Error('Choose an analysis');download(run().id+'-summary.csv',summaryCSV(run()),'text/csv');});
wire('export-reduced',async()=>{if(!run())throw new Error('Choose an analysis');download(run().id+'-rows.csv',reducedCSV(run()),'text/csv');});
wire('save-review',async()=>{if(!run())throw new Error('Choose an analysis');await act({type:'REVIEW',run_id:run().id,status:$('review-status').value,reviewer:$('reviewer').value,note:$('review-note').value});notice('Review saved against the selected analysis edition.');});
wire('freeze',async()=>{if(!run())throw new Error('Choose an analysis');const out=await act({type:'HANDOVER',run_id:run().id,title:$('handover-title').value||project.title+' research handover'});$('handover-select').value=out.handover_id;notice('Reviewed handover frozen.');});
wire('export-report',async()=>{if(!handover())throw new Error('Choose a handover');download(handover().id+'.md',handoverReport(handover()),'text/markdown');});
wire('export-handover',async()=>{if(!handover())throw new Error('Choose a handover');download(handover().id+'.json',JSON.stringify(handover(),null,2)+'\n');});
const EXAMPLE=globalThis.STUDY_DESK_EXAMPLE||null;
$('example-note').textContent=EXAMPLE?EXAMPLE.title+' — '+EXAMPLE.source_note:'Load a published study or your original authorized data files.';
$('load-example').disabled=!EXAMPLE;
wire('load-example',async()=>{if(!EXAMPLE)throw new Error('This distribution has no embedded example');const existing=await request(db.transaction('projects').objectStore('projects').get(EXAMPLE.id));if(!existing)await save(EXAMPLE);project=reopenCrashProject(existing||EXAMPLE);resetContext();await listProjects();render();notice('Original complete study example opened. Its retained source and analysis editions are available for continuation.');});
try{await openDatabase();await listProjects();}catch(error){notice('Browser storage is unavailable: '+error.message);}

function showStudyWorkspace(name){
  if(!['analysis','trajectory','crash'].includes(name))name='analysis';
  for(const section of document.querySelectorAll('.stack>section')){
    const kind=section.id==='trj-workspace'?'trajectory':section.id==='cr-workspace'?'crash':'analysis';
    section.hidden=kind!==name;
  }
  for(const [id,kind] of [['trj-open-analysis','analysis'],['trj-open-workspace','trajectory'],['cr-open-workspace','crash']]){
    const button=document.getElementById(id);if(button)button.setAttribute('aria-pressed',String(kind===name));
  }
  try{localStorage.setItem('tjlabs.study-workspace-view',name);}catch{}
  document.dispatchEvent(new CustomEvent('study-view-changed',{detail:name}));
}
