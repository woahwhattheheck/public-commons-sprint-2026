// Study Data Desk. Pure data operations shared by the browser and CLI.
export const SCHEMA = 'tjlabs.study-data-desk/v1';
const copy = value => JSON.parse(JSON.stringify(value));
const fail = message => { throw new Error(message); };
const required = (value, label) => typeof value === 'string' && value.trim() ? value.trim() : fail(label + ' is required');
const key = values => JSON.stringify(values);
const find = (items, id, label) => items.find(item => item.id === id) || fail(label + ' was not found');
const now = c => required(c.at, 'Operation time');
function canonical(v) { return JSON.stringify(v, (_, x) => x && !Array.isArray(x) && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k => [k, x[k]])) : x); }
export function createProject({ id, title, at, case_id = '', source_note = '' }) {
  return { schema: SCHEMA, id: required(id, 'Project ID'), title: required(title, 'Title'), case_id,
    source_note, revision: 0, created_at: required(at, 'Creation time'), tables: [], plans: [], decisions: [], runs: [], reviews: [], handovers: [], operations: [] };
}
export function reopenProject(value) {
  const p = typeof value === 'string' ? JSON.parse(value) : copy(value);
  if (p?.schema !== SCHEMA || !p.id || !Number.isSafeInteger(p.revision) || p.revision < 0) fail('Unsupported project');
  for (const field of ['tables','plans','decisions','runs','reviews','handovers','operations']) if (!Array.isArray(p[field])) fail('Incomplete project: ' + field);
  for(const field of ['tables','plans','decisions','runs','reviews','handovers','operations'])if(p[field].some(v=>!v||typeof v.id!=='string'||!v.id)||new Set(p[field].map(v=>v.id)).size!==p[field].length)fail('Invalid or repeated saved identity in '+field);
  for (const t of p.tables) {
    if (!Array.isArray(t.headers) || !Array.isArray(t.rows) || t.headers.some(h=>typeof h!=='string'||!h)||new Set(t.headers).size !== t.headers.length) fail('Invalid table');
    for (const r of t.rows) if (!Array.isArray(r.cells) || r.cells.length !== t.headers.length||typeof r.id!=='string') fail('Invalid saved row');
    if(new Set(t.rows.map(r=>r.id)).size!==t.rows.length)fail('Repeated saved row identity');
  }
  for(const h of p.handovers)if(!(h.table&&h.run&&h.review)){
    const t=find(p.tables,h.table_id,'Handover source'),r=find(p.runs,h.run_id,'Handover analysis'),v=find(p.reviews,h.review_id,'Handover review');
    if(r.analysis.table_id!==t.id||v.run_id!==r.id||v.status!=='ACCEPTED')fail('Invalid saved handover references');
  }
  return p;
}
export function parseCSV(text, delimiter = ',') {
  if (![',','\t',';'].includes(delimiter)) fail('Choose comma, tab or semicolon');
  text = String(text).replace(/^\uFEFF/, '');
  const rows = []; let row = [], cell = '', quoted = false, closed = false;
  for (let i=0;i<text.length;i++) {
    const ch = text[i];
    if (quoted) { if (ch === '"') { if (text[i+1] === '"') { cell += '"'; i++; } else { quoted = false; closed = true; } } else cell += ch; continue; }
    if (ch === '"') { if (cell || closed) fail('Quote inside an unquoted CSV field'); quoted = true; continue; }
    if (closed && ch !== delimiter && ch !== '\r' && ch !== '\n') fail('Text after a closing CSV quote');
    if (ch === delimiter) { row.push(cell); cell=''; closed=false; continue; }
    if (ch === '\r' || ch === '\n') { if(ch === '\r' && text[i+1] === '\n') i++; row.push(cell); rows.push(row); row=[];cell='';closed=false;continue; }
    cell += ch;
  }
  if (quoted) fail('Unclosed CSV quote');
  if (cell || row.length || closed) { row.push(cell); rows.push(row); }
  if (!rows.length) fail('The source has no header');
  const headers = rows.shift().map(s => s.trim());
  if (headers.some(h => !h) || new Set(headers).size !== headers.length) fail('CSV headers must be nonempty and unique');
  const data = rows.filter(r => !(r.length === 1 && r[0] === ''));
  data.forEach((r,i) => { if(r.length !== headers.length) fail('CSV record ' + (i+2) + ' has ' + r.length + ' fields; expected ' + headers.length); });
  return { headers, data };
}
export function tableProfile(table) {
  return { id: table.id, title: table.title, rows: table.rows.length,
    columns: table.headers.map((name, index) => { const values=table.rows.map(r=>r.cells[index]);const filled=values.filter(v=>String(v).trim()!=='');return {
      name, present: filled.length, blank: values.length-filled.length,
      numeric: filled.filter(v=>/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(String(v).trim()) && Number.isFinite(Number(v))).length,
      distinct: new Set(values).size, examples: [...new Set(filled)].slice(0,5) }; }) };
}
function normalizePlan(p, project) {
  const t=find(project.tables,p.table_id,'Source table');
  const fields = (v,label,allowEmpty=false) => { if (!Array.isArray(v) || (!v.length&&!allowEmpty) || new Set(v).size!==v.length || v.some(x=>!t.headers.includes(x))) fail('Choose existing ' + label); return [...v]; };
  const metrics = (p.metrics || []).map(m => {
    if(!t.headers.includes(m.column)) fail('Metric column is missing');
    const scale=m.scale===undefined?1:Number(m.scale), offset=m.offset===undefined?0:Number(m.offset);
    if(!Number.isFinite(scale)||scale===0||!Number.isFinite(offset)) fail('Metric conversion must be finite and scale nonzero');
    const lower=m.min===undefined||m.min===null||m.min===''?null:Number(m.min),upper=m.max===undefined||m.max===null||m.max===''?null:Number(m.max);
    if((lower!==null&&!Number.isFinite(lower))||(upper!==null&&!Number.isFinite(upper))||(lower!==null&&upper!==null&&lower>upper)) fail('Invalid metric range');
    return {column:m.column,label:required(m.label||m.column,'Metric label'),unit:required(m.unit,'Metric unit'),scale,offset,min:lower,max:upper};
  });
  if(!metrics.length || new Set(metrics.map(m=>m.column)).size!==metrics.length) fail('Choose distinct measures');
  return { title:required(p.title,'Analysis title'),table_id:t.id,
    participant_fields:fields(p.participant_fields,'participant columns'),
    group_fields:fields(p.group_fields||[],'group columns',true),
    scenario_fields:fields(p.scenario_fields||[],'scenario columns',true),
    row_key_fields:fields(p.row_key_fields,'row key columns'),
    metrics,missing_values:(p.missing_values||['','NA','N/A','NaN']).map(String),
    expected_scenarios:p.expected_scenarios===undefined||p.expected_scenarios===null||p.expected_scenarios===''?null:Number(p.expected_scenarios),
    note:String(p.note||'') };
}
export function summarize(values) {
  if(!values.length) return {n:0,mean:null,sd:null,min:null,q1:null,median:null,q3:null,max:null};
  const sorted=[...values].sort((a,b)=>a-b); let mean=0,m2=0,n=0;
  for(const x of values) {n++;const delta=x-mean;mean+=delta/n;m2+=delta*(x-mean);}
  const quantile=p=>{const i=(n-1)*p,lo=Math.floor(i),hi=Math.ceil(i);return sorted[lo]+(sorted[hi]-sorted[lo])*(i-lo);};
  return {n,mean,sd:n>1?Math.sqrt(m2/(n-1)):null,min:sorted[0],q1:quantile(.25),median:quantile(.5),q3:quantile(.75),max:sorted[n-1]};
}
export function analyze(project, planId) {
  const plan=find(project.plans,planId,'Analysis plan'), table=find(project.tables,plan.table_id,'Source table');
  const indices = cols => cols.map(c=>table.headers.indexOf(c));
  const partI=indices(plan.participant_fields),groupI=indices(plan.group_fields),scenarioI=indices(plan.scenario_fields),keyI=indices(plan.row_key_fields);
  const vals=(r,is)=>is.map(i=>String(r.cells[i]).trim());
  const latest=new Map(project.decisions.filter(d=>d.table_id===table.id).map(d=>[d.row_id,d]));
  const seen=new Map(),participants=new Map(),groups=new Map(),scenarios=new Map(),issues=[];
  const rowResults=[]; let excluded=0, included=0, invalidKeys=0;
  for(const r of table.rows) {
    const decision=latest.get(r.id);
    if(decision?.exclude) {excluded++;rowResults.push({row_id:r.id,status:'EXCLUDED',reason:decision.reason});continue;}
    const pv=vals(r,partI),gv=vals(r,groupI),sv=vals(r,scenarioI),kv=vals(r,keyI),pid=key(pv),gid=key(gv),sid=key(sv),rk=key(kv);
    if([...pv,...gv,...sv,...kv].some(v=>!v)) {invalidKeys++;issues.push({row_id:r.id,kind:'MISSING_IDENTITY',detail:'A configured identity cell is blank'});rowResults.push({row_id:r.id,status:'INVALID_IDENTITY'});continue;}
    if(seen.has(rk)) issues.push({row_id:r.id,kind:'DUPLICATE_KEY',related_row_id:seen.get(rk),detail:rk});
    else seen.set(rk,r.id);
    included++;
    if(!participants.has(pid)) participants.set(pid,{id:pv,groups:new Set(),scenarios:new Set(),rows:0});
    const participant=participants.get(pid);participant.groups.add(gid);participant.scenarios.add(sid);participant.rows++;
    if(!groups.has(gid)) groups.set(gid,gv);if(!scenarios.has(sid))scenarios.set(sid,sv);
    const measures={};
    for(const m of plan.metrics) {
      const raw=String(r.cells[table.headers.indexOf(m.column)]).trim();let value=null,status='VALID';
      if(plan.missing_values.includes(raw))status='MISSING';
      else if(!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(raw)||!Number.isFinite(Number(raw)))status='NONNUMERIC';
      else { value=Number(raw)*m.scale+m.offset;if(!Number.isFinite(value))status='NONFINITE';else if((m.min!==null&&value<m.min)||(m.max!==null&&value>m.max))status='OUT_OF_RANGE'; }
      if(status!=='VALID') {issues.push({row_id:r.id,kind:status,column:m.column,detail:raw});value=null;}
      measures[m.column]={value,status,raw};
    }
    rowResults.push({row_id:r.id,status:'INCLUDED',participant:pv,group:gv,scenario:sv,measures});
  }
  const participantResults=[...participants.values()].map(p=>({id:p.id,groups:[...p.groups].map(g=>groups.get(g)),scenario_count:p.scenarios.size,rows:p.rows}));
  for(const p of participantResults) {
    if(p.groups.length>1) issues.push({kind:'PARTICIPANT_MULTIPLE_GROUPS',participant:p.id,detail:'Review whether group membership should change within participant'});
    if(plan.expected_scenarios!==null && p.scenario_count!==plan.expected_scenarios) issues.push({kind:'SCENARIO_COVERAGE',participant:p.id,detail:p.scenario_count+' observed; '+plan.expected_scenarios+' expected'});
  }
  const summaries=[];
  function addSummary(gid, sid, m) {
    const rows=rowResults.filter(r=>r.status==='INCLUDED'&&key(r.group)===gid&&(sid===null||key(r.scenario)===sid));
    const valid=rows.filter(r=>r.measures[m.column].value!==null),perPerson=new Map();
    for(const r of valid) {const p=key(r.participant);if(!perPerson.has(p))perPerson.set(p,[]);perPerson.get(p).push(r.measures[m.column].value);}
    const units=[...perPerson.values()].map(v=>summarize(v).mean);
    summaries.push({group:groups.get(gid),scenario:sid===null?null:scenarios.get(sid),metric:m.column,label:m.label,unit:m.unit,
      rows:rows.length,valid_rows:valid.length,unavailable_rows:rows.length-valid.length,
      participant_statistics:summarize(units),row_statistics:summarize(valid.map(r=>r.measures[m.column].value))});
  }
  for(const gid of groups.keys())for(const m of plan.metrics) {addSummary(gid,null,m);for(const sid of scenarios.keys())if(rowResults.some(r=>r.status==='INCLUDED'&&key(r.group)===gid&&key(r.scenario)===sid))addSummary(gid,sid,m);}
  return {plan_id:plan.id,table_id:table.id,source_rows:table.rows.length,included_rows:included,excluded_rows:excluded,invalid_identity_rows:invalidKeys,
    participants:participantResults,groups:[...groups.values()],scenarios:[...scenarios.values()],issues,summaries,rows:rowResults,
    method:'Within each group and scenario, rows are averaged within participant first. Participant summaries weight each observed participant equally; row summaries are descriptive acquisition summaries. Missing, nonnumeric and out-of-range measures are unavailable, with their original values retained. Duplicate keys remain visible until an explicit source correction or exclusion.'};
}
export function materializeHandover(project, handoverId) {
  const h=find(project.handovers,handoverId,'Handover');
  if(h.table&&h.run&&h.review)return copy(h);
  const table=find(project.tables,h.table_id,'Handover source'),run=find(project.runs,h.run_id,'Handover analysis'),review=find(project.reviews,h.review_id,'Handover review');
  if(run.analysis.table_id!==table.id||review.run_id!==run.id||review.status!=='ACCEPTED')fail('The saved handover references a different source or review');
  return {...copy(h),table:copy(table),run:copy(run),review:copy(review)};
}
export function applyCommand(project, command) {
  reopenProject(project);const c=copy(command),op=required(c.operation_id,'Operation ID');
  const fullPayload=canonical({...c,at:undefined}),payload=c.type==='IMPORT'?canonical({...c,at:undefined,text:undefined}):fullPayload;
  const existing=project.operations.find(o=>o.id===op);
  if(existing) {
    const same=existing.payload===fullPayload||(c.type==='IMPORT'&&existing.payload===payload&&find(project.tables,existing.output.table_id,'Original imported table').original_text===String(c.text));
    if(!same)fail('Operation ID was already used for different input');return {project,output:copy(existing.output),reused:true};
  }
  const p=copy(project),at=now(c);let output;
  if(c.type==='IMPORT') {
    let headers,data;
    if(c.format==='json') {
      const input=JSON.parse(c.text);if(!Array.isArray(input)||!input.length||input.some(r=>!r||Array.isArray(r)||typeof r!=='object'))fail('JSON input must contain row objects');
      headers=[...new Set(input.flatMap(r=>Object.keys(r)))];data=input.map(r=>headers.map(h=>r[h]===null||r[h]===undefined?'':typeof r[h]==='object'?fail('Nested JSON cells are unsupported'):String(r[h])));
    } else ({headers,data}=parseCSV(c.text,c.delimiter||','));
    const id='table-'+(p.tables.length+1);
    const table={id,title:required(c.title,'Table title'),filename:required(c.filename,'Original filename'),source_url:String(c.source_url||''),source_note:String(c.source_note||''),license:String(c.license||''),at,
      original_text:String(c.text),format:c.format||'csv',delimiter:c.delimiter||',',headers,rows:data.map((cells,i)=>({id:id+':'+(i+1),record:i+2,cells}))};
    p.tables.push(table);output={table_id:id,rows:data.length,columns:headers.length};
  } else if(c.type==='PLAN') {
    const plan=normalizePlan(c.plan,p);
    if(c.previous_id && find(p.plans,c.previous_id,'Previous plan').table_id!==plan.table_id)fail('A plan revision must use its original table; choose New plan for another source');
    if(plan.expected_scenarios!==null&&(!Number.isSafeInteger(plan.expected_scenarios)||plan.expected_scenarios<1))fail('Expected scenario count must be a positive integer');
    const id='plan-'+(p.plans.length+1);p.plans.push({...plan,id,at,previous_id:c.previous_id||null});output={plan_id:id};
  } else if(c.type==='DECISION') {
    const t=find(p.tables,c.table_id,'Table');find(t.rows,c.row_id,'Source row');
    if(typeof c.exclude!=='boolean')fail('Decision must include exclude true or false');
    const id='decision-'+(p.decisions.length+1);p.decisions.push({id,table_id:t.id,row_id:c.row_id,exclude:c.exclude,reason:required(c.reason,'Decision reason'),reviewer:required(c.reviewer,'Reviewer'),at});output={decision_id:id};
  } else if(c.type==='RUN') {
    const analysis=analyze(p,c.plan_id),id='run-'+(p.runs.length+1);
    p.runs.push({id,at,project_revision:p.revision,plan:copy(find(p.plans,c.plan_id,'Plan')),decisions:copy(p.decisions.filter(d=>d.table_id===analysis.table_id)),analysis});output={run_id:id,included_rows:analysis.included_rows,participants:analysis.participants.length,issues:analysis.issues.length};
  } else if(c.type==='REVIEW') {
    find(p.runs,c.run_id,'Analysis run');if(!['ACCEPTED','CORRECTIONS_REQUESTED'].includes(c.status))fail('Choose a review decision');
    const id='review-'+(p.reviews.length+1);p.reviews.push({id,run_id:c.run_id,status:c.status,reviewer:required(c.reviewer,'Reviewer'),note:required(c.note,'Review note'),at});output={review_id:id};
  } else if(c.type==='HANDOVER') {
    const run=find(p.runs,c.run_id,'Analysis run'),review=[...p.reviews].reverse().find(r=>r.run_id===run.id);
    if(!review || review.status!=='ACCEPTED')fail('Accept this analysis edition before freezing its handover');
    const id='handover-'+(p.handovers.length+1),table=find(p.tables,run.analysis.table_id,'Source table');
    p.handovers.push({id,at,title:required(c.title,'Handover title'),project_id:p.id,case_id:p.case_id,source_note:p.source_note,
      table_id:table.id,run_id:run.id,review_id:review.id});output={handover_id:id};
  } else fail('Unknown operation');
  p.revision++;p.updated_at=at;p.operations.push({id:op,type:c.type,at,payload,output:copy(output)});
  return {project:p,output,reused:false};
}
const csvCell = value => {let s=value===null||value===undefined?'':typeof value==='object'?JSON.stringify(value):String(value);if(typeof value==='string'&&/^[\t\r\n ]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
export function toCSV(headers,rows) {return [headers,...rows].map(row=>row.map(csvCell).join(',')).join('\r\n')+'\r\n';}
export function summaryCSV(run) {
  return toCSV(['group','scenario','measure','unit','source_rows','valid_rows','unavailable_rows','participants','participant_mean','participant_sd','participant_median','participant_q1','participant_q3'],
    run.analysis.summaries.map(s=>[s.group,s.scenario,s.label,s.unit,s.rows,s.valid_rows,s.unavailable_rows,s.participant_statistics.n,s.participant_statistics.mean,s.participant_statistics.sd,s.participant_statistics.median,s.participant_statistics.q1,s.participant_statistics.q3]));
}
export function reducedCSV(run) {
  const m=run.plan.metrics;
  return toCSV(['row_id','status','participant','group','scenario',...m.flatMap(x=>[x.column+' ['+x.unit+']',x.column+' status'])],
    run.analysis.rows.map(r=>[r.row_id,r.status,r.participant,r.group,r.scenario,...m.flatMap(x=>[r.measures?.[x.column]?.value,r.measures?.[x.column]?.status])]));
}
export function handoverReport(h) {
  const fmt=x=>x===null?'—':Number(x).toFixed(4),a=h.run.analysis;
  const cell=v=>String(v??'').replace(/\|/g,'/').replace(/[\r\n]+/g,' ');
  return '# '+h.title+'\n\nProject: '+h.project_id+'\n\nCase: '+(h.case_id||'Unassigned')+'\n\nSource: '+h.table.filename+' — '+h.table.source_url+'\n\n'+h.table.source_note+'\n\nLicense: '+h.table.license+'\n\nAnalysis: '+h.run.id+'; '+h.run.at+'\n\nReviewed by '+h.review.reviewer+': '+h.review.note+'\n\n## Data coverage\n\nOriginal rows: '+a.source_rows+'; included: '+a.included_rows+'; excluded: '+a.excluded_rows+'; invalid identity: '+a.invalid_identity_rows+'. Observed participants: '+a.participants.length+'.\n\n## Method\n\n'+a.method+'\n\nPlan: '+h.run.plan.note+'\n\n## Participant summaries\n\n| Group | Scenario | Measure | Unit | Participants | Mean | SD | Median |\n| --- | --- | --- | --- | ---: | ---: | ---: | ---: |\n'+a.summaries.map(s=>'| '+[s.group.join(' / '),s.scenario===null?'All observed':s.scenario.join(' / '),s.label,s.unit,s.participant_statistics.n,fmt(s.participant_statistics.mean),fmt(s.participant_statistics.sd),fmt(s.participant_statistics.median)].map(cell).join(' | ')+' |').join('\n')+'\n\n## Review findings\n\n'+(a.issues.length?a.issues.map(i=>'- '+cell(i.kind)+'; '+cell(i.row_id||JSON.stringify(i.participant))+'; '+cell(i.column||'')+'; '+cell(i.detail)).join('\n'):'No configured data issues were observed.')+'\n\n## Retained decisions\n\n'+(h.run.decisions.length?h.run.decisions.map(d=>'- '+d.row_id+': '+(d.exclude?'exclude':'include')+' — '+cell(d.reason)+' ('+cell(d.reviewer)+', '+d.at+')').join('\n'):'The analysis uses the original rows without operator exclusions.')+'\n';
}
