# Linked crash cohort workspace

Study Data Desk now carries a complete linked-record research workflow alongside its original source-analysis and observed-scenario workspaces. The browser, Node CLI and portable receiving use the same source definitions and calculation engine.

The published example contains the complete NHTSA FARS 2020 District of Columbia exports received on October 12, 2026: **34 crash records, 50 in-transport vehicles and 83 person records**. Its second saved cohort selects crashes with an original pedestrian or bicyclist record and retains **11 crashes, 15 vehicles and 30 people**. Every original file and record remains available.

## Run the complete desk

Use a current Node runtime. There are no external JavaScript packages or hosted services.

~~~sh
node build.mjs
node serve.mjs 8765
~~~

Open the URL printed by the maintained local server, then choose **Linked crash cohorts**. **Open original FARS example** opens the complete published source, linkage, both cohort and plan editions, analyses, named reviews and handovers. The original NGSIM study and observed-scenario workspace remain in the same distribution.

The browser uses the maintained Study Data Desk project database. A component operation store retains original request bodies, unfinished forms and received handovers. Source text in a pending import is retained before the study mutation. No source is uploaded by the browser.

## Source intake and linkage

Receive complete CSV, TSV or JSON files. A JSON source may retain a publisher envelope: give the exact row-array path, such as \`["Results",0]\`, and optionally its declared count path, such as \`["Count"]\`. The declared count must match the complete selected array. A root array uses \`[]\`. Original file text, scalar values, row locations, field order, source URL and usage context are preserved.

The source browser searches every original cell, pages the displayed records, inventories all distinct values of a selected column, and downloads the exact input text. Opening a row shows all original columns and values, its physical CSV line or JSON pointer, and its linked original parents.

Choose one source for each required record family:

| Family | Composite identity | Relationship |
| --- | --- | --- |
| Crash | year, state, crash | One original crash |
| In-transport vehicle | year, state, crash, vehicle | Its one crash parent |
| Person | year, state, crash, vehicle, person | Its one crash parent and, where applicable, its occupied vehicle |
| Parked or working vehicle | year, state, crash, vehicle | A separate original family for parked/working vehicle references |

Each key can use an explicit source column or a recorded fixed value. Choose integer-code normalization only when the source uses integer identifiers; otherwise keep exact text. Source keys with missing values or duplicate complete identities remain visible and unresolved. They are not silently collapsed into an arbitrary record.

For the FARS example, the mapping uses the original year/state/ST_CASE and VEH_NO/PER_NO fields. Nonmotorist VEH_NO=0 has no occupied vehicle. PER_TYP=3 refers to the separate Parkwork family. A person can retain a unique crash-level identity while its occupied-vehicle reference is unresolved; the coverage and findings show that distinction.

**Prepare FARS field mapping** proposes only fields present in the selected original tables. Review its case-year definitions and source choice before saving. If multiple possible original tables exist, choose the intended source rather than assuming the first table is correct.

## Cohort selection

A cohort contains explicit condition groups. Every condition inside one group must apply to the **same original record**. Separate groups are combined with AND.

For example, a person group with PER_TYP in 5 or 6 selects crashes with an original pedestrian or bicyclist record. Adding AGE between 18 and 120 to that same group requires one qualifying pedestrian/bicyclist who also has that available age. Two different people cannot satisfy the two halves of that same-record group.

A group may require:

- **At least one:** a definite matching record establishes the group.
- **None:** a definite matching record rejects the group; unresolved records prevent an unsupported negative conclusion.
- **Every:** every examined record must qualify and at least one record must exist.

Blank or explicitly unavailable codes retain their unavailable state. A condition that cannot resolve because of missing data or ambiguous identity produces an indeterminate result unless another definite condition decides the group. Preview displays the complete included, excluded and indeterminate crash lists, each original row used by a condition, and every related record.

Saving a cohort freezes its mapping, complete source bindings, effective row decisions and original selection. Editing a saved cohort creates its next edition. A historical edition that already has a successor cannot silently become a competing successor: reopen the current edition or deliberately start another cohort series.

## Measures and denominators

Every measure names its own original record family. Vehicle and person rows are never multiplied by a cross-product join. A selected crash has one crash denominator, its original vehicles have a vehicle denominator, and its original people have a person denominator.

The operator supports:

- Unique record counts.
- Distributions preserving raw source codes, publisher labels, availability and original row references.
- Shares using explicitly named numerator codes and either all selected records or available measure values.
- Numeric summaries with declared units, unavailable codes, valid ranges, sample counts, means, sample standard deviations, quartiles and original unavailable observations.

Population conditions apply to the same original record being measured. Grouping may use that record's own columns or its one original crash parent. Every measure keeps its selected population, definite condition exclusions and unavailable condition records. The result table displays both the record count and the chosen denominator. Selecting a measure opens all of its original observations.

For the published 2020 example, injury code 4 is Fatal Injury (K), injury code 9 is unavailable, and age codes 998/999 are unavailable. The complete cohort contains **36 source person fatalities**, equal to the original crash-level FATALS sum. There are 83 original people and 82 available injury classifications. The example's fatal-person share explicitly uses all 83 selected person records; changing to available values would use 82 and must be a separately saved plan.

These are descriptive results from the selected fatal-crash records. FARS record counts do not provide traffic exposure, general-population crash risk or causal effects. Research design, eligibility and interpretation stay with the study owner.

## Decisions, editions and review

Select an exact original row from the source browser, a linkage finding, a cohort or a measure observation. A named exclusion or reinstatement records its original table/row identity, reviewer and reason. Original file bytes stay intact. Save a new cohort edition to use changed decisions; earlier cohorts and analyses retain their saved selection.

A saved analysis names the exact saved plan and cohort. Review uses the full immutable analysis SHA-256 displayed in the operator. An accepted review is required before a handover can be frozen. The handover freezes the project context, original source files, relevant operation identities, mapping/decision/cohort/plan history and selected analysis/review. Later ordinary edits leave its bytes and digest stable.

Use the complete CSV exports for every selected original crash, vehicle or person row. The report and analysis JSON retain the denominator, source links and unavailable values. The full project backup additionally preserves the broader editable study and every handover.

## Interrupted work and saved forms

Before changing a study, the operator durably saves its complete original request, UUID, time, expected study edition and submitted forms. The project save uses the maintained database's expected-revision transaction.

If a response is interrupted, **Recover original operation** first opens the actual saved study. An already committed UUID reuses its original result. An uncommitted request can continue only against its original expected edition. Another window's later edition therefore remains intact.

Definitive local validation or edition errors settle that unsaved attempt and retain the complete forms and request history. They do not leave an invalid operation locking the editor forever. Unknown storage outcomes keep the original UUID available for recovery.

**Restore saved forms** restores the draft's original source/edition references. If its base edition differs from the current study, **Use restored forms on current edition** is an explicit reconciliation step; the final save still checks all selected source, parent-edition and review bindings. Downloadable drafts and pending requests preserve complete authored inputs.

## Portable receiving

Download the **complete frozen handover** and receive it in another browser through the receiving panel. Receiving:

1. Checks the entire packet digest and original file parse.
2. Restores its original table, row, mapping and operation identities.
3. Recomputes every retained cohort against its original frozen decisions.
4. Recomputes every retained analysis from the complete source rows and declared measure definitions.
5. Opens the received history with its exact accepted review and handover.

The received view is retained separately from the editable study. It can inspect sources, compare retained analyses and export complete data. Return to the editable study to continue authoring, or restore its complete project backup in a new browser workspace.

### Node receiving and command interface

The original transactional CLI accepts one command file and an original project path:

~~~sh
node cli.mjs /absolute/study.json /absolute/command.json
~~~

An initialization command is \`{"type":"INIT","id":"study-id","title":"Study title","at":"2026-10-12T15:00:00Z"}\`.

Crash operations use \`CRASH_IMPORT\`, \`CRASH_MAP\`, \`CRASH_DECISION\`, \`CRASH_COHORT\`, \`CRASH_PLAN\`, \`CRASH_RUN\`, \`CRASH_REVIEW\` and \`CRASH_HANDOVER\`. Preserve the original \`operation_id\` and \`at\` for retries. A \`CRASH_IMPORT.file\` path is resolved relative to its command file; inline \`text\` is also supported.

The complete original fourteen commands are in [example/crash/commands.json](example/crash/commands.json). Their three file paths are relative to that folder. The runnable example verifies each original input SHA and replays all fourteen commands:

~~~sh
node crash-example.mjs /absolute/new-example-output
~~~

It writes the complete editable project, both frozen handovers and reports, complete per-family row CSVs, summary CSVs, source manifest and original operation outcomes. Existing differing output files are preserved.

A receiving command in a command file is:

~~~json
{"type":"RECEIVE_CRASH_HANDOVER","file":"crash-handover-2.json"}
~~~

Use a new destination project path. The CLI recomputes the complete packet and stores its frozen receiving context. Repeating the same received packet reopens that context; a different packet requires another destination. The receiving file supports complete exports and preserves its read-only handover state.

Exports use \`{"type":"EXPORT","kind":"crash_handover","handover_id":"crash-handover-2","out":"/absolute/output.json"}\`. Other kinds are \`crash_index\` (\`mapping_id\`), \`crash_cohort\` (\`cohort_id\`), \`crash_analysis\` or \`crash_summary\` (\`analysis_id\`), \`crash_rows\` (\`analysis_id\` and \`entity\`), and \`crash_report\` (\`handover_id\`). Output paths must be new files; the original project lock, complete write, rename and directory sync remain in place.

## Published originals

The [source manifest](example/crash/source.json) retains the exact original URL, byte length, SHA-256, row count, column count, selected parser and attribution for each file.

| Original file | Complete rows | Bytes | SHA-256 |
| --- | ---: | ---: | --- |
| Accident JSON | 34 | 66,919 | fb402bff9bc99386016957daf7d0d105757b0b90512297c730e9f0e6e90150f0 |
| Vehicle CSV | 50 | 104,066 | d2006fef129c8d9f29c3ea735ea636b585003d9c5d80bf644bafb3ab134695f3 |
| Person CSV | 83 | 114,402 | fa5c18fdfea837d3a8bd517afdead62d415d32a7270415a8a4e8cb716088ec0b |

Primary references:

- [NHTSA CrashAPI](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI).
- [Original Accident query](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Accident&format=json&state=11).
- [Original Vehicle query](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Vehicle&format=csv&state=11).
- [Original Person query](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Person&format=csv&state=11).
- [NHTSA FARS Analytical User's Manual, 1975–2020, DOT HS 813 254, revised August 2022](https://www.govinfo.gov/content/pkg/GOVPUB-TD8-PURL-gpo186377/pdf/GOVPUB-TD8-PURL-gpo186377.pdf), especially Person data and its linkage, person-type, age and injury-severity definitions.

Attribution: National Highway Traffic Safety Administration, Fatality Analysis Reporting System, case year 2020. Original United States government data is retained with its publisher attribution. The example retains every returned field; no inferred geocoding or altered original records are introduced.

### Numeric sample size and restored source files

Numeric results display `statistics.n` as **numeric n** alongside the mean, standard deviation and quantiles. That sample size includes only valid numeric observations under the saved unavailable-code and range rules. A custom plan’s declared population denominator remains visible separately. CSV exports retain the separate `numeric_n` and `denominator` fields.

Switching studies, opening a received context or restoring another complete form clears the prior file chooser and pending in-memory import. Restoring an original failed import request deliberately reattaches only that request’s retained complete source bytes; an unrelated file selection cannot silently replace them.

## Complete original operating run

The maintained native caller uses the complete published original files and the same fourteen example operation IDs. It operates the actual CLI, verifies full portable receiving, builds the combined offline browser, saves the complete command-line workspace, then runs the mounted browser through a new source-defined pedestrian cohort, named review, original finalization recovery and frozen receiving. The browser uses its own retained profile; its accepted command-line work is preserved before browser startup.

```sh
python3 acquisition/operate_crash_native.py --source-dir /ABS/Study_Data_Desk --root /ABS/Owned_Operation --source-pin EXACT_COMMIT --node /ABS/node --node-modules /ABS/node_modules --chromium /ABS/chromium --browser
```

A completed `outputs/operation.json` points to the full source/workspace ZIP and final browser result. `--resume-browser` reopens the accepted command-line study; retain its original directory and browser profile when continuing an interrupted browser step. An already completed browser result is adopted without repeating its business actions. The shared `e9b2-native-browser.lock` is only used by this coordinated operating caller.
