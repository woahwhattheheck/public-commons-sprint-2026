import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
const port=Number(process.argv[2]||8708);
if(!Number.isInteger(port)||port<1||port>65535)throw new Error('Port must be between 1 and 65535');
const html=await readFile(new URL('./Study_Data_Desk.html',import.meta.url));
const server=createServer((req,res)=>{
  if(!['127.0.0.1:'+port,'localhost:'+port,...(port===80?['127.0.0.1','localhost']:[])].includes(req.headers.host)){res.writeHead(403);res.end('Local workspace only');return;}
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'});res.end();return;}
  if(req.url!=='/'&&req.url!=='/Study_Data_Desk.html'){res.writeHead(404);res.end();return;}
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':html.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"});res.end(req.method==='HEAD'?undefined:html);
});
server.listen(port,'127.0.0.1',()=>process.stdout.write('Study Data Desk: http://127.0.0.1:'+port+'\n'));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close());
