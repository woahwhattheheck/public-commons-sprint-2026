import { readFile, open, rename, unlink, mkdir } from 'node:fs/promises';
import { resolve, dirname, basename } from 'node:path';
import { randomUUID } from 'node:crypto';
import { createProject, reopenProject, applyCommand, summaryCSV, reducedCSV, handoverReport, materializeHandover } from './core.mjs';
import { reopenTrajectoryProject, applyTrajectoryCommand, trajectoryExport } from './trajectory.mjs';
import { reopenCrashProject, applyCrashCommand, crashExport, crashHandoverContext, inspectCrashHandover } from './crash_core.mjs';
const [projectFile,commandFile]=process.argv.slice(2);
if(!projectFile||!commandFile)throw new Error('Usage: node cli.mjs /path/study.json /path/command.json');
const target=resolve(projectFile), command=JSON.parse(await readFile(commandFile,'utf8'));
await mkdir(dirname(target),{recursive:true,mode:0o700});
const lock=await open(target+'.lock','wx',0o600);
let temporary;
try {
  await lock.writeFile(JSON.stringify({pid:process.pid,started_at:new Date().toISOString(),project:target})+'\n');await lock.sync();
  let project;try{project=reopenCrashProject(await readFile(target,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
  let result;
  if(command.type==='RECEIVE_CRASH_HANDOVER') {
    if(!command.file)throw new Error('Receiving requires the complete original handover file');
    const received=inspectCrashHandover(await readFile(resolve(dirname(resolve(commandFile)),command.file),'utf8'));
    if(project){
      if(!project.received_handover||project.received_handover.sha256!==received.sha256)throw new Error('This destination already contains another study; choose a new receiving file');
      if(crashExport(project,{kind:'crash_handover',handover_id:received.handover.id})!==JSON.stringify(received,null,2)+'\n')throw new Error('The retained receiving workspace differs from the original handover');
    }else{project=crashHandoverContext(received);project.received_handover={sha256:received.sha256,handover_id:received.handover.id,read_only:true};}
    result={received:true,project_id:project.id,handover_id:received.handover.id,analysis_id:received.handover.analysis_id,sha256:received.sha256,recomputed:true};
  } else if(command.type==='INIT') {
    if(project)throw new Error('Project already exists; continue its original file');
    project=createProject({...command,at:command.at||new Date().toISOString()});result={project_id:project.id};
  } else {
    if(!project)throw new Error('Initialize the study first');
    if(command.type==='EXPORT') {
      const kind=command.kind||'project',run=project.runs.find(r=>r.id===command.run_id),selectedH=project.handovers.find(h=>h.id===command.handover_id),h=selectedH?materializeHandover(project,selectedH.id):null;
      let text=kind.startsWith('crash_')?crashExport(project,command):kind.startsWith('trajectory_')?trajectoryExport(project,command):kind==='project'?JSON.stringify(project,null,2)+'\n':kind==='summary'&&run?summaryCSV(run):kind==='rows'&&run?reducedCSV(run):kind==='report'&&h?handoverReport(h):kind==='handover'&&h?JSON.stringify(h,null,2)+'\n':null;
      if(text===null)throw new Error('Choose an existing run or handover for this export');
      if(!command.out)throw new Error('Export out filename is required');
      const output=resolve(command.out),handle=await open(output,'wx',0o600);try{await handle.writeFile(text);await handle.sync();}finally{await handle.close();}
      process.stdout.write(JSON.stringify({file:output,bytes:Buffer.byteLength(text),revision:project.revision})+'\n');process.exitCode=0;
    } else {
      if(project.received_handover?.read_only)throw new Error('This received handover is frozen. Restore a full editable project backup to continue the study.');
      const c={...command,at:command.at||new Date().toISOString(),operation_id:command.operation_id||randomUUID()};
      if(c.type==='CRASH_IMPORT'&&c.file){c.text=await readFile(resolve(dirname(resolve(commandFile)),c.file),'utf8');c.filename=c.filename||basename(c.file);delete c.file;}
      if(c.type==='IMPORT'&&c.file){c.text=await readFile(c.file,'utf8');c.filename=c.filename||basename(c.file);delete c.file;}
      const changed=c.type.startsWith('CRASH_')?applyCrashCommand(project,c):c.type.startsWith('TRAJECTORY_')?applyTrajectoryCommand(project,c):applyCommand(project,c);project=changed.project;result={...changed.output,operation_id:c.operation_id,reused:changed.reused};
    }
  }
  if(result) {
    temporary=target+'.'+randomUUID()+'.tmp';const file=await open(temporary,'wx',0o600);
    try{await file.writeFile(JSON.stringify(project,null,2)+'\n');await file.sync();}finally{await file.close();}
    await rename(temporary,target);temporary=null;const dir=await open(dirname(target),'r');try{await dir.sync();}finally{await dir.close();}
    process.stdout.write(JSON.stringify({...result,revision:project.revision,project:target})+'\n');
  }
} finally {
  if(temporary)await unlink(temporary).catch(()=>{});await lock.close();await unlink(target+'.lock');
}
