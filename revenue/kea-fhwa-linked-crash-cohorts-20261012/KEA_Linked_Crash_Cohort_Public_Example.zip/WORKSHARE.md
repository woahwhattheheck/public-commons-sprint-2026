# Linked crash cohort receiving and analyst handover

**Prepared for:** KEA Technologies Inc.  
**Prepared by:** TokenJunkie Labs  
**Proposed fixed fee:** USD 4,800  
**Delivery:** 10 business days after agreed source and scope intake, reviewer and kickoff  
**Case:** kea-fhwa-linked-crash-cohorts-20261012  
**Preparation date:** October 12, 2026  
**Status:** Proposed workshare.

## Result KEA receives

Turn one agreed crash cohort into a complete, editable study project. The handover retains the original crash, vehicle and person files, shows how their records link, carries every duplicate or unmatched row into an explicit exception view, and records the cohort definitions and denominators behind each descriptive output. A named review freezes the selected edition. Another analyst can receive the complete package, reproduce the selected outputs and continue the editable project.

The workshare covers one agreed source edition and cohort, up to three linked entity tables in CSV or flat JSON, the record volume established at intake, and two consolidated review rounds. The accepted source manifest fixes the geographic and year coverage, complete files, table grain and available fields before the ten-day period begins.

## Why this is a relevant conversation

FHWA's current contract-vehicle list names KEA Technologies under HRDS technical-services-support IDIQ **693JJ322D000001**, with a listed expiry of **September 15, 2027**, and invites prospective subcontractors to contact listed prime contractors. KEA's own FHWA announcement describes crash occurrence, severity and injury research across human, vehicle, roadway and demographic factors. This workshare supports that research practice with source receiving, complete linkage reconciliation and an analyst-ready handover.

Sources: [FHWA contract vehicles](https://highways.dot.gov/cfo/task-and-delivery-order-and-blanket-purchase-agreement-vehicles) and [KEA's original FHWA announcement](https://keatechinc.com/press-release/kea-technologies-awarded-federal-highway-administration-technical-support-services-contract/).

## Work and acceptance

| Phase | Planned days | Work | Acceptance |
| --- | --- | --- | --- |
| Receive and map | 1–2 | Retain complete originals and file hashes. Inventory the agreed entity tables, edition, geography/years, source fields, table grain, composite keys, code conventions and missing values. Configure the source's permitted treatment of people without a vehicle record. | Every agreed file is accounted for. Original columns and rows remain recoverable, and KEA can review the documented table and key mapping. |
| Link and define | 3–5 | Reconcile complete tables, retaining duplicates, invalid or absent keys and unmatched records. Save cohort inclusion rules, descriptive measures and explicit crash, vehicle and person denominators. Carry unknown values and exclusions into outputs. | Every input row has an accounted-for role or exception. Entity counts are not inflated by joining finer-grained tables. Each result identifies the entity, included denominator, source edition and agreed treatment. |
| Review and revise | 6–8 | Present the complete first edition for consolidated review. Save agreed corrections and reasons as a new edition. Complete the second consolidated review and retain the named reviewer and exact source/mapping/cohort binding. | In-scope exceptions have documented dispositions or an explicit unresolved status accepted for the output. The selected edition has a named review; earlier editions and decisions remain available. |
| Handover and reopen | 9–10 | Deliver the editable project, frozen handover, original-file inventory, mappings/dictionary notes, complete exception and descriptive outputs, printable summary and operating guide. Reopen in a separate local workspace and reproduce the selected exports. | The recipient verifies the complete package, inspects original exceptions, reproduces the reviewed counts and continues an editable edition while the original frozen handover stays intact. |

The day allocations total ten business days. They begin from the agreed intake and kickoff rather than a government programme date. Consolidated review responses must arrive on the agreed dates. A change in source availability or review timing is recorded with its delivery effect.

## Division of work

TokenJunkie Labs completes the source receiving, mapping, linkage reconciliation, exception investigation, descriptive cohort configuration, review revisions, operator configuration and complete receiving handover.

KEA provides the study question, authorized original files and dictionary, source key/code conventions, expected coverage and a designated reviewer. KEA decides cohort membership, exception policy, analytical definitions and intended use. KEA retains study design, statistical inference, exposure estimation, scientific interpretation, its agency/client relationship, prime-contract responsibilities and production approvals.

The intake checks the agreed record volume in the selected customer environment. The public example demonstrates a source contract and receiving workflow; it is not evidence of unbounded performance for an unspecified corpus.

## Complete deliverables

- Unchanged original input files in the agreed authorized package, with a complete file/byte/hash inventory and source attribution.
- Source-specific table grain, composite-key, field/code, missing-value and nonmotorist handling notes.
- Complete linked entity views and original-row exceptions, including duplicate, absent-key, unmatched and excluded records.
- Saved cohort and descriptive-measure definitions with explicit entity denominators and source bindings.
- Versioned corrections and named review records for the selected edition.
- Complete descriptive/exception exports, printable summary and frozen handover.
- The editable project, original history, operating guide and a demonstrated independent receive/reopen.

## Proposed fee and payments

The proposed fixed fee is **USD 4,800**:

| Milestone | Amount | Trigger |
| --- | ---: | --- |
| Start | USD 2,400 | Source manifest, cohort scope, dictionary, review owner, delivery capacity and kickoff are agreed. |
| Accepted handover | USD 2,400 | KEA accepts the agreed linkage/exception review, descriptive outputs, complete editable project, frozen handover and independent reopen. |

The two proposed milestones total the fixed fee. The accepted workshare will record the agreed kickoff, review dates and payment terms.

## Scope changes and limits

The workshare includes one source edition, one agreed cohort, up to three entity tables, CSV or flat-JSON input, the accepted record volume and two consolidated reviews. Additional editions, cohorts, tables, source formats, metric families, integrations or review rounds require a retained scope revision with agreed fee and timing before the added work begins.

The scope does not include new data collection, fieldwork, participant recruitment, instrument/media processing, restricted-data purchases, production hosting, ongoing refresh, live agency integration or ongoing support. Exposure estimation, population risk rates, causal conclusions, hypothesis testing and statistical model fitting remain with KEA unless separately scoped.

## Rights and custody

KEA receives the study-specific configuration, documented methods, review records, derived outputs, complete editable project and operating guide. Original data, third-party materials and existing software retain their applicable ownership, licensing and attribution. Customer inputs and workspaces stay in the agreed authorized environment. Any exclusive ownership or additional licensing terms are agreed before kickoff.

## Retained public example

The preparation uses the complete original NHTSA FARS 2020 District of Columbia returns: **34 crash records, 50 vehicle records and 83 person records**. The three unchanged files total **285,387 bytes**, and their manifest retains every source URL, byte count and SHA-256 value. The authoritative FARS analytical manual is identified with its edition and relevant linkage/code pages.

This selected fatal-crash extract supports descriptive entity counts. It supplies no traffic-exposure denominator and does not establish a population risk rate or causal effect.

The package includes the complete original source manifest. Publisher originals: [crash records](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Accident&format=json&state=11), [vehicle records](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Vehicle&format=csv&state=11), [person records](https://crashviewer.nhtsa.dot.gov/crashviewer/CrashAPI/FARSData/GetFARSData?FromYear=2020&ToYear=2020&dataset=Person&format=csv&state=11), and the [FARS analytical manual, DOT HS 813 254](https://www.govinfo.gov/content/pkg/GOVPUB-TD8-PURL-gpo186377/pdf/GOVPUB-TD8-PURL-gpo186377.pdf).

## Starting decision

Which current KEA study or analyst team would benefit from this one-cohort handover? The useful first discussion identifies the exact source edition and record volume, the responsible study lead, the desired descriptive outputs and the environment receiving the project.

