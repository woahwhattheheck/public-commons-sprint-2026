# Get Connected coverage workspace

This download contains the complete maintained coordinator application, its original source contract and a worked operating cohort. Source commit: `77a337de930b39ed0ba4e81272e7845a3d2aabd3`.

## Open the worked example

Install Python 3.10 or later, Node 22.16 or later and the site's IANA time-zone data. Open a terminal in `source/workspace` inside this extracted folder. Choose a private writable workspace location, then run:

    python3 -B create_example.py --db /absolute/private/path/shiftloom-example.sqlite
    python3 -B app.py --db /absolute/private/path/shiftloom-example.sqlite --port 8802

Open the local address printed by the second command. Use `--port 0` if port 8802 is occupied. The example launcher accepts a fresh workspace and preserves the original source and explicit coordinator recipe.

Review the first target shift: two vacancies, one additional team reservation, and original candidate reasons. Create a plan, record a named decision and undo it. The operating guide explains the corrected availability and qualification imports that lead to the successor plan.

## Configure the organization's real source

For a new workspace, run `app.py` with a new SQLite filename. Follow `source/workspace/WORKFLOW.md` for source-role intake, actual headers and status maps, coordinator availability/eligibility/qualification rules and complete coverage review. `source/workspace/README.md` includes the documented Get Connected capture command and interruption/resume workflow. Original request bytes and source IDs remain retained beside each projection.

## Handover

Download the selected board's complete ZIP to transfer its original inputs, mappings, roster, named decisions and predecessor history. Download the full SQLite backup to reopen all retained source versions and work in the same application. Keep that working file with the organization's private records.

`WORKSHARE.md` and `Get_Connected_Coverage_Workshare.pdf` define the one-site implementation scope, ten-business-day delivery and USD 6,400 fee. `SOURCE_MANIFEST.json` identifies each included source file and the exact maintained commit. `source/workspace/VALIDATION.md` describes the completed coordinator, capture/recovery and priced-cohort journeys.

Maintained source: https://github.com/woahwhattheheck/public-commons-sprint-2026/tree/77a337de930b39ed0ba4e81272e7845a3d2aabd3/amazon-shiftloom-2026/workspace
