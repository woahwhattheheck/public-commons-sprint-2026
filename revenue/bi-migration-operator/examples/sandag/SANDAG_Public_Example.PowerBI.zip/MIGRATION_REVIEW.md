# Migration review: SANDAG_Published_Offense_Counts

Review these retained source findings in the migration workspace and Power BI Desktop.
Resolve the relevant bindings, calculations, prompts, filters and report behavior; rebuild
and compare the resulting query outputs with the original Cognos results before rollout.
Original findings and query metadata remain in MIGRATION_PLAN.json and the metadata files.

| Severity | Code | Message | Source |
| --- | --- | --- | --- |
| info | PUBLIC_SOURCE_SCOPE | This example specification was authored for the published SANDAG aggregate tables; it is not an agency Cognos production export. |  |
| warning | COUNTING_UNITS | Group A counting units differ by category; Group B is arrest-based. These are published offense counts, not unique incidents or people. See counting-basis.json. |  |
| warning | PUBLISHER_CONTROL_DIFFERENCES | The retained summary controls cover Group A only. The 66 detailed-versus-summary comparison observations and coverage differences remain in published_table_comparison.json. Preserve the publisher's values; do not infer corrections. |  |
| warning | SOURCE_NULL_AND_HIERARCHY | Retain unreported, partial-year and blank source states. Twelve original unlabeled cells retain their source-row IDs. Regional totals use Sheriff-Total once and exclude its children. |  |
| info | POPULATION_PERIOD | Population observations use the issuer's original 2021 and combined 2023/2024 periods. The reference page shows Year Label and Applicable Years; no active single-year relationship discards or duplicates the combined-period observation. |  |
