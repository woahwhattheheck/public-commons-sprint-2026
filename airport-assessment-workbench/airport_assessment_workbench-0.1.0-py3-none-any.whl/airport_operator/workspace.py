"""Durable airport workpapers, exact source imports and retained decisions.

The SQLite revision/request/archive envelope follows the original PLAN
workbench. Domain calculations belong to engine.py; source interpretation uses
the original CSV/JSON/XLSX intake module without a second parser.
"""
from __future__ import annotations

import base64
import hashlib
import json
import mimetypes
import os
import re
import sqlite3
import uuid
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

if __package__:
    from . import engine, intake
else:
    import engine
    import intake

SCHEMA = "acrp.operator-workspace.v1"
COLLECTIONS = tuple(engine.schema()["collections"])
MAX_SOURCE_BYTES = 32 * 1024 * 1024
MAX_PROJECT_SOURCE_BYTES = 128 * 1024 * 1024
MAX_STATE_BYTES = 48 * 1024 * 1024
MAX_COLLECTION_ROWS = 100000
canonical, digest = engine._json, engine._hash


class Conflict(ValueError):
    def __init__(self, message, current_revision=None):
        super().__init__(message)
        self.current_revision = current_revision


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def required(value, label, limit=20000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or "\x00" in value:
        raise ValueError(f"{label} must be nonempty text of at most {limit:,} characters.")
    return value


def identifier(value, label="Record ID"):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", value):
        raise ValueError(label + " must use 1–200 letters, digits, dots, colons, underscores or hyphens, beginning with a letter or digit.")
    return value


def _json(raw):
    return json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("JSON cannot contain non-finite numbers.")))


def _record(state, collection, record_id):
    if collection not in COLLECTIONS:
        raise ValueError("Select an airport workpaper collection.")
    row = next((item for item in state[collection] if item["id"] == record_id), None)
    if row is None:
        raise KeyError("Record not found: " + collection + "/" + str(record_id))
    return row


def _filename(value):
    required(value, "Original filename", 240)
    if value != Path(value).name or value in (".", "..") or "\\" in value or any(ord(c) < 32 for c in value):
        raise ValueError("Use a plain original filename without a path or control characters.")
    return value


def _file_record(raw, filename, media_type=None):
    filename = _filename(filename)
    if not isinstance(raw, bytes) or len(raw) > MAX_SOURCE_BYTES:
        raise ValueError("One retained original may contain at most 32 MiB.")
    sha = hashlib.sha256(raw).hexdigest()
    return {"id": "file-" + digest({"sha256": sha, "filename": filename})[:32], "filename": filename,
            "sha256": sha, "bytes": len(raw), "media_type": media_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"}


class Workspace:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        created = not self.path.exists()
        with self.connect() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,revision INTEGER NOT NULL,state TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS raw_sources(sha256 TEXT PRIMARY KEY,data BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS events(project_id TEXT NOT NULL,revision INTEGER NOT NULL,record TEXT NOT NULL,PRIMARY KEY(project_id,revision));
            CREATE TABLE IF NOT EXISTS requests(project_id TEXT NOT NULL,request_id TEXT NOT NULL,digest TEXT NOT NULL,result TEXT NOT NULL,PRIMARY KEY(project_id,request_id));
            """)
        if created:
            os.chmod(self.path, 0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=20000")
        try:
            yield db
        finally:
            db.close()

    def _state(self, db, project_id):
        row = db.execute("SELECT state FROM projects WHERE id=?", (project_id,)).fetchone()
        if row is None:
            raise KeyError("Project not found.")
        return _json(row[0])

    def _event(self, state, actor, kind, payload, previous="", request_id=None, request_digest=None):
        event = {"project_id": state["id"], "revision": state["revision"], "at": state["updated_at"],
                 "actor": required(actor, "Operator", 200), "kind": kind, "payload": payload,
                 "state_hash": digest(state), "previous_hash": previous,
                 "request_id": request_id, "request_digest": request_digest}
        event["hash"] = digest(event)
        return event

    def _new_state(self, title, project_id=None, domain_state=None):
        project_id = identifier(project_id or "airport-" + uuid.uuid4().hex, "Project ID")
        state = deepcopy(domain_state) if domain_state is not None else engine.initial_state(project_id, title)
        state["project"] = {**state.get("project", {}), "id": project_id, "title": required(title, "Project title", 240)}
        now = utc()
        state.update({"workspace_schema": SCHEMA, "id": project_id, "revision": 1,
                      "created_at": now, "updated_at": now, "files": [], "source_files": {}, "imports": []})
        return state

    def create(self, title, actor="Operator", project_id=None):
        state = self._new_state(title, project_id)
        return self._insert_new(state, {}, actor, "project.created", {"title": title})

    def adopt_seed(self, domain_state, originals, *, project_id, title, actor="Public example loader", seed_sha256=None):
        """Atomically adopt the frozen example without rewriting reviewed inputs.

        originals maps an existing domain source ID to (filename, raw bytes).
        Additional public reference files may be retained as unbound file records.
        """
        state = self._new_state(title, project_id, domain_state)
        state["seed"] = {"sha256": seed_sha256 or digest(domain_state), "original_project_id": domain_state["project"]["id"]}
        raw_by_sha = {}
        for source_id, original in originals.items():
            filename, raw = original
            record = _file_record(raw, filename)
            if source_id is not None:
                source = _record(state, "sources", source_id)
                if source.get("sha256") != record["sha256"]:
                    raise ValueError("A frozen example source differs from its retained original bytes.")
                state["source_files"][source_id] = record["id"]
            if not any(item["id"] == record["id"] for item in state["files"]):
                state["files"].append(record)
            raw_by_sha[record["sha256"]] = raw
        with self.connect() as db:
            existing = db.execute("SELECT state FROM projects WHERE id=?", (project_id,)).fetchone()
        if existing:
            prior = _json(existing[0])
            if prior.get("seed") != state["seed"]:
                raise Conflict("This example ID contains a different source package. Preserve the project and choose a distinct ID.", prior["revision"])
            return {"id": project_id, "revision": prior["revision"], "status": "already_present"}
        return self._insert_new(state, raw_by_sha, actor, "example.adopted", {"seed": state["seed"], "source_count": len(originals)})

    def _insert_new(self, state, originals, actor, kind, payload):
        self.validate_state(state)
        event = self._event(state, actor, kind, payload)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                if db.execute("SELECT 1 FROM projects WHERE id=?", (state["id"],)).fetchone():
                    raise Conflict("That project ID already exists. Open its current work.")
                for sha, raw in originals.items():
                    self._store_raw(db, sha, raw)
                db.execute("INSERT INTO projects VALUES(?,?,?)", (state["id"], state["revision"], canonical(state)))
                db.execute("INSERT INTO events VALUES(?,?,?)", (state["id"], state["revision"], canonical(event)))
                db.commit()
            except Exception:
                db.rollback()
                raise
        return {"id": state["id"], "revision": state["revision"], "status": "created"}

    def list_projects(self):
        with self.connect() as db:
            states = [_json(row[0]) for row in db.execute("SELECT state FROM projects")]
        return [{"id": row["id"], "title": row["project"]["title"], "revision": row["revision"],
                 "created_at": row["created_at"], "updated_at": row["updated_at"],
                 "airport_count": len(row["airports"]), "use_case_count": len(row["use_cases"]), "source_count": len(row["sources"])}
                for row in sorted(states, key=lambda item: item["updated_at"], reverse=True)]

    def _preview(self, state):
        result = deepcopy(state)
        result["computed"] = engine.analyze(state)
        result["collection_counts"] = {key: len(state[key]) for key in COLLECTIONS}
        result["collection_limit"] = 100
        for collection in COLLECTIONS:
            result[collection] = result[collection][:100]
        # Decision snapshots remain available through the complete record route.
        for decision in result["decisions"]:
            if "input_snapshot" in decision:
                decision.pop("input_snapshot")
                decision["snapshot_available"] = True
        result["computed_counts"] = {}
        for key, value in result["computed"].items():
            if isinstance(value, list):
                result["computed_counts"][key] = len(value)
                result["computed"][key] = value[:100]
        result["import_count"] = len(result["imports"])
        result["imports"] = [{key: value for key, value in item.items() if key not in ("adopted", "unselected", "source_rows")}
                             for item in result["imports"][-20:]]
        return result

    def get(self, project_id):
        with self.connect() as db:
            state = self._state(db, project_id)
        return self._preview(state)

    def record(self, project_id, collection, record_id):
        with self.connect() as db:
            return deepcopy(_record(self._state(db, project_id), collection, record_id))

    def records(self, project_id, collection, offset=0, limit=100, airport_id=None, use_case_id=None):
        if collection not in COLLECTIONS:
            raise ValueError("Unknown workpaper collection.")
        offset, limit = max(0, int(offset)), min(500, max(1, int(limit)))
        with self.connect() as db:
            state = self._state(db, project_id)
        rows = state[collection]
        if airport_id or use_case_id:
            if __package__:
                from .exports import project_projection
            else:
                from exports import project_projection
            projected = project_projection(state, "use_case" if use_case_id else "airport", airport_id, use_case_id)
            rows = projected["data"][collection]
        return {"collection": collection, "revision": state["revision"], "offset": offset, "total": len(rows), "rows": deepcopy(rows[offset:offset+limit])}

    def history(self, project_id, offset=0, limit=100):
        offset, limit = max(0, int(offset)), min(500, max(1, int(limit)))
        with self.connect() as db:
            state = self._state(db, project_id)
            events = [_json(row[0]) for row in db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision LIMIT ? OFFSET ?", (project_id, limit, offset))]
        return {"revision": state["revision"], "offset": offset, "total": state["revision"], "rows": events}

    def import_record(self, project_id, import_id):
        with self.connect() as db:
            state = self._state(db, project_id)
        record = next((item for item in state["imports"] if item["id"] == import_id), None)
        if record is None:
            raise KeyError("Import record not found.")
        return record

    def original(self, project_id, file_id):
        with self.connect() as db:
            state = self._state(db, project_id)
            record = next((item for item in state["files"] if item["id"] == file_id), None)
            if record is None:
                raise KeyError("Original file is outside this project.")
            raw = self._raw(db, record)
        return raw, record

    def _raw(self, db, record):
        row = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (record["sha256"],)).fetchone()
        if row is None:
            raise ValueError("Retained original bytes are missing.")
        raw = bytes(row[0])
        if len(raw) != record["bytes"] or hashlib.sha256(raw).hexdigest() != record["sha256"]:
            raise ValueError("Original bytes differ from their declared identity.")
        return raw

    def _store_raw(self, db, sha, raw):
        old = db.execute("SELECT data FROM raw_sources WHERE sha256=?", (sha,)).fetchone()
        if old is not None and bytes(old[0]) != raw:
            raise Conflict("This original byte identity already contains different content.")
        db.execute("INSERT OR IGNORE INTO raw_sources VALUES(?,?)", (sha, raw))

    def validate_state(self, state):
        if state.get("schema") != engine.SCHEMA or state.get("workspace_schema") != SCHEMA:
            raise ValueError("Unsupported airport project schema.")
        identifier(state.get("id"), "Project ID")
        if state.get("project", {}).get("id") != state["id"]:
            raise ValueError("Workspace and domain project identities differ.")
        required(state["project"].get("title"), "Project title", 240)
        if type(state.get("revision")) is not int or not 1 <= state["revision"] <= 2147483647:
            raise ValueError("Project revision must be a positive integer.")
        for field in ("created_at", "updated_at"):
            try:
                moment = datetime.fromisoformat(state[field])
                if moment.tzinfo is None:
                    raise ValueError()
            except (ValueError, TypeError, KeyError) as exc:
                raise ValueError("Project timestamps must retain explicit time zones.") from exc
        indexes = {}
        for collection in COLLECTIONS:
            rows = state.get(collection)
            if not isinstance(rows, list) or len(rows) > MAX_COLLECTION_ROWS:
                raise ValueError("Workpaper collection is missing or exceeds 100,000 records: " + collection)
            indexes[collection] = engine._index(state, collection)
        for collection in COLLECTIONS:
            for record in state[collection]:
                identifier(record["id"])
                if type(record.get("revision")) is not int or record["revision"] < 1:
                    raise ValueError("Each saved workpaper must retain its positive integer revision.")
                engine.validate_record(collection, record, state)
                use_case = indexes["use_cases"].get(record.get("use_case_id"))
                if use_case and record.get("airport_id") and use_case["airport_id"] != record["airport_id"]:
                    raise ValueError("This record's airport and use case refer to different airports.")
                option = indexes["options"].get(record.get("option_id"))
                if option and use_case and option["use_case_id"] != use_case["id"]:
                    raise ValueError("This option belongs to a different use case.")
                decision = indexes["decisions"].get(record.get("decision_id"))
                if decision and use_case and decision["use_case_id"] != use_case["id"]:
                    raise ValueError("This roadmap decision belongs to a different use case.")
        if not isinstance(state.get("files"), list) or not isinstance(state.get("source_files"), dict) or not isinstance(state.get("imports"), list):
            raise ValueError("Retain the project original-file inventory, source bindings and import history.")
        files = {}
        for record in state["files"]:
            filename = _filename(record.get("filename"))
            sha = record.get("sha256")
            if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{64}", sha):
                raise ValueError("Original file SHA-256 must contain 64 lowercase hexadecimal characters.")
            if record.get("id") != "file-" + digest({"sha256": sha, "filename": filename})[:32] or record["id"] in files:
                raise ValueError("Original file identity is inconsistent or repeated.")
            if type(record.get("bytes")) is not int or not 0 <= record["bytes"] <= MAX_SOURCE_BYTES:
                raise ValueError("Original byte length is outside the supported range.")
            files[record["id"]] = record
        if sum({row["sha256"]: row["bytes"] for row in files.values()}.values()) > MAX_PROJECT_SOURCE_BYTES:
            raise ValueError("Project originals exceed 128 MiB.")
        for source_id, file_id in state["source_files"].items():
            source, original = indexes["sources"].get(source_id), files.get(file_id)
            if source is None or original is None or source.get("sha256") != original["sha256"]:
                raise ValueError("Source metadata and retained original-file identity disagree.")
        for collection in COLLECTIONS:
            for record in state[collection]:
                ref = record.get("source_ref")
                if isinstance(ref, dict) and ref.get("source_file_id"):
                    original = files.get(ref["source_file_id"])
                    if original is None or original["sha256"] != ref.get("source_sha256"):
                        raise ValueError("An imported row no longer has its exact retained original source.")
        if len(canonical(state).encode()) > MAX_STATE_BYTES:
            raise ValueError("Project state exceeds 48 MiB; use explicitly scoped source cohorts.")

    def _save_record(self, state, collection, record, *, allow_decision=False):
        if collection not in COLLECTIONS or not isinstance(record, dict):
            raise ValueError("Select a known collection and a complete record.")
        if collection == "decisions" and not allow_decision:
            raise ValueError("Record the decision through decision.record to retain its exact reviewed inputs. Prior decisions stay available.")
        record = deepcopy(record)
        record["id"] = identifier(record.get("id") or collection + "-" + uuid.uuid4().hex)
        prior = next((item for item in state[collection] if item["id"] == record["id"]), None)
        if prior is not None and collection == "decisions":
            raise ValueError("A saved decision is retained unchanged. Record the new review as a distinct decision.")
        if record.get("snapshot_available"):
            raise ValueError("Open the complete record before saving; a preview cannot replace retained inputs.")
        if collection == "sources" and prior and record["id"] in state["source_files"] and record.get("sha256") != prior.get("sha256"):
            raise ValueError("A retained source keeps its byte identity. Attach the new original as a separate source record.")
        record["revision"] = prior["revision"] + 1 if prior else 1
        engine.validate_record(collection, record, state)
        if prior:
            state[collection] = [record if item["id"] == record["id"] else item for item in state[collection]]
        else:
            state[collection].append(record)
        return {"collection": collection, "id": record["id"], "record_revision": record["revision"],
                "previous_content_hash": digest(prior) if prior else None, "content_hash": digest(record)}

    def apply(self, project_id, operation, payload, expected_revision, request_id, actor="Operator"):
        required(request_id, "Request ID", 200)
        required(actor, "Operator", 200)
        if not isinstance(payload, dict):
            raise ValueError("Operation payload must be an object.")
        request_hash = digest({"operation": operation, "payload": payload, "expected_revision": expected_revision, "actor": actor})
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                previous_request = db.execute("SELECT digest,result FROM requests WHERE project_id=? AND request_id=?", (project_id, request_id)).fetchone()
                if previous_request:
                    if previous_request["digest"] != request_hash:
                        raise Conflict("This request ID already has different input. Use a new ID for the new action.")
                    return _json(previous_request["result"])
                state = self._state(db, project_id)
                if type(expected_revision) is not int or expected_revision != state["revision"]:
                    raise Conflict("The project changed. Reload the current revision and retain this edit for reconciliation.", state["revision"])
                event_payload, resource = self._change(db, state, operation, payload, actor)
                state["revision"] += 1
                state["updated_at"] = utc()
                self.validate_state(state)
                previous = _json(db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision DESC LIMIT 1", (project_id,)).fetchone()[0])["hash"]
                event = self._event(state, actor, operation, event_payload, previous, request_id, request_hash)
                result = {"project_id": project_id, "revision": state["revision"], "operation": operation, "event_hash": event["hash"], "resource": resource}
                db.execute("UPDATE projects SET revision=?,state=? WHERE id=?", (state["revision"], canonical(state), project_id))
                db.execute("INSERT INTO events VALUES(?,?,?)", (project_id, state["revision"], canonical(event)))
                db.execute("INSERT INTO requests VALUES(?,?,?,?)", (project_id, request_id, request_hash, canonical(result)))
                db.commit()
                return result
            except Exception:
                db.rollback()
                raise

    def _change(self, db, state, operation, payload, actor):
        if operation == "record.save":
            saved = self._save_record(state, payload.get("collection"), payload.get("record"))
            return saved, saved
        if operation == "record.delete":
            collection = payload.get("collection")
            if collection == "decisions":
                raise ValueError("Prior decisions remain in the workpapers. Record a new decision to change the current direction.")
            record = _record(state, collection, payload.get("id"))
            state[collection] = [item for item in state[collection] if item["id"] != record["id"]]
            if collection == "sources":
                state["source_files"].pop(record["id"], None)
            return {"collection": collection, "id": record["id"], "previous_content_hash": digest(record)}, {"id": record["id"], "status": "deleted"}
        if operation == "project.rename":
            state["project"]["title"] = required(payload.get("title"), "Project title", 240)
            return {"title": state["project"]["title"]}, {"id": state["id"]}
        if operation == "source.add":
            encoded = payload.get("content_base64")
            if not isinstance(encoded, str) or len(encoded) > ((MAX_SOURCE_BYTES + 2) // 3) * 4:
                raise ValueError("Attach an original file of at most 32 MiB as content_base64.")
            try:
                raw = base64.b64decode(encoded, validate=True)
            except (ValueError, TypeError) as exc:
                raise ValueError("Original content must contain valid base64.") from exc
            original = _file_record(raw, payload.get("filename"), payload.get("media_type"))
            metadata = deepcopy(payload.get("metadata", {}))
            if not isinstance(metadata, dict):
                raise ValueError("Source metadata must be an object.")
            if metadata.get("id") and any(item["id"] == metadata["id"] for item in state["sources"]):
                raise Conflict("That source ID already exists. Edit its metadata or attach a distinct source version.", state["revision"])
            metadata.update({"id": metadata.get("id") or "source-" + uuid.uuid4().hex,
                             "title": metadata.get("title") or original["filename"], "sha256": original["sha256"], "filename": original["filename"]})
            saved = self._save_record(state, "sources", metadata)
            if not any(item["id"] == original["id"] for item in state["files"]):
                state["files"].append(original)
            state["source_files"][saved["id"]] = original["id"]
            self._store_raw(db, original["sha256"], raw)
            return saved | {"file": original}, {**saved, "file_id": original["id"], "sha256": original["sha256"]}
        if operation == "decision.record":
            record = engine.freeze_decision(state, payload.get("use_case_id"), payload.get("option_id"), actor,
                                            payload.get("action"), required(payload.get("rationale"), "Decision rationale"),
                                            decision_id=payload.get("id"), conditions=payload.get("conditions"),
                                            decided_at=utc(), next_review=payload.get("next_review"))
            saved = self._save_record(state, "decisions", record, allow_decision=True)
            return saved | {"input_sha256": record["input_sha256"], "action": record["action"]}, saved
        if operation == "records.import":
            return self._adopt_import(db, state, payload, actor)
        raise ValueError("Unknown airport operation: " + str(operation))

    def _stage_import(self, db, state, specification):
        allowed = {"source_id", "parse_options", "mapper", "table_id", "collection", "mapping", "constants", "key_field", "calendar_year"}
        if not isinstance(specification, dict) or set(specification) - allowed:
            raise ValueError("Use the documented explicit source parsing and mapping fields.")
        specification = deepcopy(specification)
        source = _record(state, "sources", specification.get("source_id"))
        file_id = state["source_files"].get(source["id"])
        original = next((item for item in state["files"] if item["id"] == file_id), None)
        if original is None:
            raise ValueError("Attach the exact original source bytes before previewing an import.")
        parsed = intake.parse_source(self._raw(db, original), original["filename"], specification.get("parse_options"))
        mapper = specification.get("mapper", "inspect")
        if mapper == "inspect":
            staged = {"records": [], "findings": [], "collection": None, "row_count": sum(len(table["rows"]) for table in parsed["tables"])}
        elif mapper == "faa":
            staged = intake.faa_airports(parsed, specification.get("calendar_year"), specification.get("table_id"))
            staged["records"] = staged.pop("airports")
            staged["collection"] = "airports"
        elif mapper == "fields":
            collection = specification.get("collection")
            if collection not in COLLECTIONS or collection in ("sources", "decisions"):
                raise ValueError("Map an editable domain collection; original sources and retained decisions use their dedicated operations.")
            staged = intake.map_records(parsed, specification.get("table_id"), specification.get("mapping"), collection=collection,
                                        constants=specification.get("constants"), key_field=specification.get("key_field"))
        else:
            raise ValueError("Select inspect, faa or fields as the source mapper.")
        for record in staged["records"]:
            record["source_id"] = source["id"]
            record["source_ref"].update({"parsed_source_id": parsed["id"], "source_id": source["id"], "source_file_id": original["id"]})
        binding = {"source_id": source["id"], "source_revision": source["revision"], "source_record_sha256": digest(source),
                   "source_file_id": original["id"], "source_sha256": original["sha256"], "parsed_source_id": parsed["id"],
                   "specification": specification, "staged_sha256": digest(staged)}
        return parsed, staged, binding, digest(binding)

    def intake_preview(self, project_id, specification, offset=0, limit=100):
        offset, limit = max(0, int(offset)), min(500, max(1, int(limit)))
        with self.connect() as db:
            db.execute("BEGIN")
            state = self._state(db, project_id)
            parsed, staged, binding, preview_digest = self._stage_import(db, state, specification)
        tables = []
        for table in parsed["tables"]:
            tables.append({**{key: deepcopy(value) for key, value in table.items() if key not in ("rows", "row_origins")},
                           "row_count": len(table["rows"]), "offset": offset, "rows": table["rows"][offset:offset+limit],
                           "row_origins": table["row_origins"][offset:offset+limit]})
        collection, existing = staged.get("collection"), {}
        if collection:
            existing = {row["id"]: row["revision"] for row in state[collection]}
        validation = []
        for row in staged["records"][offset:offset+limit]:
            try:
                identifier(row["id"])
                engine.validate_record(collection, row, state)
                validation.append({"row_index": row["source_ref"]["row_index"], "id": row["id"], "valid": True,
                                   "existing_record_revision": existing.get(row["id"])})
            except ValueError as exc:
                validation.append({"row_index": row["source_ref"]["row_index"], "id": row["id"], "valid": False, "error": str(exc)})
        return {"project_id": project_id, "revision": state["revision"], "preview_digest": preview_digest, "binding": binding,
                "source": {key: value for key, value in parsed.items() if key != "tables"}, "tables": tables,
                "collection": collection, "offset": offset, "staged_count": len(staged["records"]), "records": staged["records"][offset:offset+limit],
                "validation": validation, **{key: value for key, value in staged.items() if key not in ("records", "collection", "schema", "source_id", "mapping", "constants")}}

    def _adopt_import(self, db, state, payload, actor):
        parsed, staged, binding, preview_digest = self._stage_import(db, state, payload.get("specification"))
        if payload.get("preview_digest") != preview_digest:
            raise Conflict("The source or mapping differs from the reviewed preview. Preview its current exact contents before adoption.", state["revision"])
        collection = staged.get("collection")
        if not collection:
            raise ValueError("Choose an explicit FAA or field mapper before adopting rows.")
        rows = staged["records"]
        all_rows = payload.get("all_rows") is True
        indices = payload.get("row_indices")
        if all_rows and indices is not None or not all_rows and not isinstance(indices, list):
            raise ValueError("Select all_rows:true or an explicit row_indices list, not both.")
        available = {row["source_ref"]["row_index"] for row in rows}
        selected = available if all_rows else set(indices)
        if not selected or any(type(index) is not int or index < 0 for index in selected) or not selected <= available:
            raise ValueError("Select one or more actual staged source row indices.")
        if indices is not None and len(indices) != len(selected):
            raise ValueError("The source row selection repeats an index.")
        chosen = [row for row in rows if row["source_ref"]["row_index"] in selected]
        if len({row["id"] for row in chosen}) != len(chosen):
            raise ValueError("Selected source rows repeat record IDs. Resolve the key mapping or select an explicit distinct subset.")
        policy = payload.get("conflict_policy", "reject")
        expected = payload.get("expected_record_revisions", {})
        if policy not in ("reject", "replace") or not isinstance(expected, dict):
            raise ValueError("Import conflict_policy is reject or explicit replace with expected_record_revisions.")
        existing = {row["id"]: row for row in state[collection]}
        for row in chosen:
            prior = existing.get(row["id"])
            if prior and (policy != "replace" or type(expected.get(row["id"])) is not int or expected[row["id"]] != prior["revision"]):
                raise Conflict("Import collides with " + collection + "/" + row["id"] + ". Supply its exact current record revision for an intentional replacement.", state["revision"])
        # Validate the complete candidate set together, allowing explicit same-import references.
        candidate = deepcopy(state)
        chosen_ids = {row["id"] for row in chosen}
        replacements = []
        for row in chosen:
            saved = deepcopy(row)
            saved["revision"] = existing[saved["id"]]["revision"] + 1 if saved["id"] in existing else 1
            replacements.append(saved)
        candidate[collection] = [row for row in candidate[collection] if row["id"] not in chosen_ids] + replacements
        self.validate_state(candidate)
        state[collection] = candidate[collection]
        import_id = "import-" + uuid.uuid4().hex
        adopted = [{"id": row["id"], "row_index": row["source_ref"]["row_index"], "record_revision": row["revision"],
                    "content_hash": digest(row), "previous_content_hash": digest(existing[row["id"]]) if row["id"] in existing else None} for row in replacements]
        receipt = {"id": import_id, "at": utc(), "actor": actor, "collection": collection, "preview_digest": preview_digest,
                   "binding": binding, "conflict_policy": policy, "adopted": adopted,
                   "unselected": [{"row_index": row["source_ref"]["row_index"], "id": row["id"], "reason": "outside_explicit_selection"}
                                  for row in rows if row["source_ref"]["row_index"] not in selected],
                   "source_rows": {key: deepcopy(staged[key]) for key in ("summary_rows", "blank_rows", "unclassified_rows") if key in staged},
                   "findings": staged.get("findings", [])}
        state["imports"].append(receipt)
        result = {"id": import_id, "collection": collection, "adopted_count": len(adopted), "unselected_count": len(receipt["unselected"]),
                  "source_sha256": binding["source_sha256"], "import_sha256": digest(receipt)}
        return result, result

    def snapshot(self, project_id):
        with self.connect() as db:
            db.execute("BEGIN")
            state = self._state(db, project_id)
            raw = {record["sha256"]: self._raw(db, record) for record in state["files"]}
            events = [_json(row[0]) for row in db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision", (project_id,))]
            requests = [dict(row) for row in db.execute("SELECT request_id,digest,result FROM requests WHERE project_id=? ORDER BY request_id", (project_id,))]
        return {"state": state, "raw": raw, "events": events, "requests": requests}

    def projection(self, project_id, audience="project", airport_id=None, use_case_id=None):
        if __package__:
            from .exports import project_projection
        else:
            from exports import project_projection
        with self.connect() as db:
            state = self._state(db, project_id)
        return project_projection(state, audience, airport_id, use_case_id)

    def restore_snapshot(self, snapshot):
        state, events, requests = snapshot["state"], snapshot["events"], snapshot["requests"]
        self.validate_state(state)
        if not isinstance(events, list) or len(events) != state["revision"]:
            raise ValueError("Archived revision and event history disagree.")
        previous, event_requests = "", {}
        for revision, event in enumerate(events, 1):
            if event.get("project_id") != state["id"] or event.get("revision") != revision or event.get("previous_hash") != previous or digest({key: value for key, value in event.items() if key != "hash"}) != event.get("hash"):
                raise ValueError("Archived event chain is incomplete or has different content.")
            previous = event["hash"]
            if event.get("request_id"):
                if event["request_id"] in event_requests:
                    raise ValueError("Archived history repeats a request identity.")
                event_requests[event["request_id"]] = event
        if events[-1].get("state_hash") != digest(state):
            raise ValueError("Archived state differs from the state bound to its last event.")
        if not isinstance(requests, list) or len({row.get("request_id") for row in requests}) != len(requests) or {row.get("request_id") for row in requests} != set(event_requests):
            raise ValueError("Saved request results do not exactly cover the archived request events.")
        for request in requests:
            result = _json(request["result"])
            event = event_requests[request["request_id"]]
            if result.get("project_id") != state["id"] or result.get("revision") != event["revision"] or result.get("event_hash") != event["hash"] or result.get("operation") != event["kind"] or request.get("digest") != event.get("request_digest"):
                raise ValueError("A saved result is not bound to its original event.")
        expected = {record["sha256"] for record in state["files"]}
        if set(snapshot["raw"]) != expected:
            raise ValueError("Archived originals do not exactly match the project inventory.")
        for record in state["files"]:
            raw = snapshot["raw"][record["sha256"]]
            if not isinstance(raw, bytes) or len(raw) != record["bytes"] or hashlib.sha256(raw).hexdigest() != record["sha256"]:
                raise ValueError("An archived original differs from its declared bytes or SHA-256.")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                old = db.execute("SELECT state FROM projects WHERE id=?", (state["id"],)).fetchone()
                if old:
                    old_events = [_json(row[0]) for row in db.execute("SELECT record FROM events WHERE project_id=? ORDER BY revision", (state["id"],))]
                    old_requests = [dict(row) for row in db.execute("SELECT request_id,digest,result FROM requests WHERE project_id=? ORDER BY request_id", (state["id"],))]
                    if old[0] != canonical(state) or old_events != events or old_requests != requests:
                        raise Conflict("This project ID contains different work. Restore into a separate workspace database to retain both branches.")
                    for record in state["files"]:
                        if self._raw(db, record) != snapshot["raw"][record["sha256"]]:
                            raise Conflict("Existing project originals differ; use a separate workspace for recovery.")
                    return {"id": state["id"], "revision": state["revision"], "status": "already_present"}
                for sha, raw in snapshot["raw"].items():
                    self._store_raw(db, sha, raw)
                db.execute("INSERT INTO projects VALUES(?,?,?)", (state["id"], state["revision"], canonical(state)))
                for event in events:
                    db.execute("INSERT INTO events VALUES(?,?,?)", (state["id"], event["revision"], canonical(event)))
                for request in requests:
                    db.execute("INSERT INTO requests VALUES(?,?,?,?)", (state["id"], request["request_id"], request["digest"], request["result"]))
                db.commit()
                return {"id": state["id"], "revision": state["revision"], "status": "restored"}
            except Exception:
                db.rollback()
                raise
