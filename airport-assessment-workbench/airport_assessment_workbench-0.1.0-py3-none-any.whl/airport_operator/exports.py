"""Editable airport handover reports and complete private continuation ZIPs."""
from __future__ import annotations

import csv
import hashlib
import html
import io
import json
import re
import zipfile
from copy import deepcopy
from decimal import Decimal
from pathlib import PurePosixPath

if __package__:
    from . import engine
    from .workspace import COLLECTIONS, _json, _record, canonical, digest
else:
    import engine
    from workspace import COLLECTIONS, _json, _record, canonical, digest

PRIVATE_SCHEMA = "acrp.private-continuation.v1"
RECIPIENT_SCHEMA = "acrp.airport-handover.v1"
MAX_ARCHIVE_BYTES = 192 * 1024 * 1024


def safe_name(value):
    return re.sub(r"[^A-Za-z0-9._-]", "_", str(value))[:180] or "file"


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def csv_bytes(rows, columns):
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(columns)
    for row in rows:
        values = []
        for column in columns:
            value = row.get(column)
            if isinstance(value, (list, dict)):
                value = canonical(value)
            if value is None:
                value = ""
            # Spreadsheet presentation only; exact typed values remain in JSON.
            if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")):
                value = "'" + value
            values.append(value)
        writer.writerow(values)
    return output.getvalue().encode("utf-8-sig")


def _refs(records):
    result = set()
    for record in records:
        if record.get("source_id"):
            result.add(record["source_id"])
        ref = record.get("source_ref")
        if isinstance(ref, dict) and ref.get("source_id"):
            result.add(ref["source_id"])
    return result


def project_projection(state, audience="project", airport_id=None, use_case_id=None):
    """Project, airport or use-case workpapers without private revision history.

    Original attachments are never appended implicitly. Shared costs retain the
    selected allocation fractions; outside dependencies retain timing impacts
    without copying unrelated airport records into this report.
    """
    if audience not in ("project", "airport", "use_case"):
        raise ValueError("Choose project, airport or use_case for a recipient handover.")
    if audience == "use_case":
        selected_use_case = _record(state, "use_cases", use_case_id)
        if airport_id and selected_use_case["airport_id"] != airport_id:
            raise ValueError("The selected use case belongs to a different airport.")
        airport_id = selected_use_case["airport_id"]
    if audience in ("airport", "use_case"):
        _record(state, "airports", airport_id)
    data = {"schema": engine.SCHEMA, "project": deepcopy(state["project"]), **{name: [] for name in COLLECTIONS}}
    scoped = audience != "project"
    if not scoped:
        for collection in COLLECTIONS:
            data[collection] = deepcopy(state[collection])
    else:
        data["airports"] = [deepcopy(_record(state, "airports", airport_id))]
        data["use_cases"] = [deepcopy(row) for row in state["use_cases"] if row["airport_id"] == airport_id and (audience == "airport" or row["id"] == use_case_id)]
        use_cases = {row["id"] for row in data["use_cases"]}
        for collection in ("organizations", "parameters", "capabilities"):
            data[collection] = [deepcopy(row) for row in state[collection] if row.get("airport_id") == airport_id]
        data["data_assets"] = [deepcopy(row) for row in state["data_assets"] if row.get("use_case_id") in use_cases or row.get("airport_id") == airport_id and not row.get("use_case_id")]
        for collection in ("assessments", "risks", "options", "decisions", "roadmap", "measures"):
            data[collection] = [deepcopy(row) for row in state[collection] if row.get("use_case_id") in use_cases]
        options = {row["id"] for row in data["options"]}
        measures = {row["id"] for row in data["measures"]}
        data["observations"] = [deepcopy(row) for row in state["observations"] if row.get("measure_id") in measures]
        for row in state["cost_items"]:
            if row.get("option_id") in options:
                data["cost_items"].append(deepcopy(row))
            elif any(allocation.get("option_id") in options for allocation in row.get("allocations") or []):
                retained = deepcopy(row)
                selected = [allocation for allocation in retained["allocations"] if allocation.get("option_id") in options]
                retained["original_record_sha256"] = digest(row)
                retained["outside_scope_allocation_fraction"] = str(sum((Decimal(str(a["fraction"])) for a in retained["allocations"] if a.get("option_id") not in options), Decimal(0)))
                retained["allocations"] = selected
                data["cost_items"].append(retained)
        rubric_ids = {row.get("rubric_id") for name in ("options", "assessments") for row in data[name]}
        data["rubrics"] = [deepcopy(row) for row in state["rubrics"] if row["id"] in rubric_ids]
        pool_ids = {demand.get("pool_id") for row in data["roadmap"] for demand in row.get("demands") or [] if isinstance(demand, dict)}
        data["capacity_pools"] = [deepcopy(row) for row in state["capacity_pools"] if row["id"] in pool_ids]
        data["research"] = [deepcopy(row) for row in state["research"] if row.get("airport_id") == airport_id or row.get("use_case_id") in use_cases]
        source_ids = _refs([row for collection in COLLECTIONS if collection != "sources" for row in data[collection]])
        data["sources"] = [deepcopy(row) for row in state["sources"] if row["id"] in source_ids]
    full_analysis = engine.analyze(state)
    selected_decisions = {row["id"] for row in data["decisions"]}
    retained_decision_status = [deepcopy(row) for row in full_analysis["decisions"] if row["decision_id"] in selected_decisions]
    for collection in COLLECTIONS:
        for row in data[collection]:
            if collection == "decisions":
                row.pop("input_snapshot", None)
                row["snapshot_location"] = "Complete original reviewed inputs are retained in the private continuation archive. This recipient workpaper retains their original digest and current review status."
            if isinstance(row.get("source_ref"), dict):
                row["source_ref"].pop("source_values", None)
            row.pop("retained_file", None)
    # Preserve external prerequisite timing while excluding outside records/IDs.
    roadmap_ids = {row["id"] for row in data["roadmap"]}
    all_roadmap = {row["id"]: row for row in state["roadmap"]}
    for row in data["roadmap"]:
        outside = [key for key in row.get("predecessors") or [] if key not in roadmap_ids]
        if outside:
            row["outside_scope_prerequisites"] = [
                {"status": all_roadmap[key].get("status"), "due_date": all_roadmap[key].get("due_date"),
                 "timing_conflict": bool(row.get("start_date") and all_roadmap[key].get("due_date") and all_roadmap[key]["due_date"] > row["start_date"])}
                if key in all_roadmap else {"status": "missing_from_original_project"} for key in outside]
            row["predecessors"] = [key for key in row.get("predecessors") or [] if key in roadmap_ids]
    computed = engine.analyze(data)
    computed["decisions"] = retained_decision_status
    if scoped:
        pools = {row["id"] for row in data["capacity_pools"]}
        scope_capacity = {(row["pool_id"], row["period"]): row for row in computed["roadmap"]["capacity"]}
        for row in full_analysis["roadmap"].get("capacity", []):
            if row["pool_id"] in pools:
                own = scope_capacity.get((row["pool_id"], row["period"]))
                if own is not None:
                    own["outside_scope_committed_demand"] = str(Decimal(row["committed_demand"]) - Decimal(own["committed_demand"]))
                    own["remaining_after_all_project_commitments"] = row["remaining"]
                    own["project_pool_oversubscribed"] = row["oversubscribed"]
    source_ids = {row["id"] for row in data["sources"]}
    return {"schema": RECIPIENT_SCHEMA, "audience": audience, "project_id": state["id"], "revision": state["revision"],
            "airport_id": airport_id if scoped else None, "use_case_id": use_case_id if audience == "use_case" else None,
            "data": data, "computed": computed, "included_source_ids": sorted(source_ids),
            "available_originals": [{"source_id": source_id, "file_id": state["source_files"][source_id],
                                      **{key: original[key] for key in ("filename", "sha256", "bytes")}}
                                     for source_id in sorted(source_ids) if source_id in state["source_files"]
                                     for original in state["files"] if original["id"] == state["source_files"][source_id]],
            "notes": ["This report preserves published context, supplied observations and explicitly authored planning assumptions as separate inputs.",
                      "Original attachments require an explicit source selection; one source file can contain rows for more than this report's airport.",
                      "The complete private archive retains reviewed snapshots, all original cells, revision history and saved request results.",
                      "A scoped report retains selected workpaper records; review free-text content and chosen originals for the intended recipient."]}


def esc(value):
    if isinstance(value, (list, dict)):
        value = json.dumps(value, ensure_ascii=False, indent=2)
    return html.escape("" if value is None else str(value))


def table(headers, rows):
    return "<div class='table-wrap'><table><thead><tr>" + "".join("<th>" + esc(value) + "</th>" for value in headers) + "</tr></thead><tbody>" + "".join("<tr>" + "".join("<td>" + esc(value) + "</td>" for value in row) + "</tr>" for row in rows) + "</tbody></table></div>"


def report_html(projection):
    data, computed = projection["data"], projection["computed"]
    sections = ["<h1>" + esc(data["project"]["title"]) + "</h1><p>Airport assessment and implementation workpapers · " + esc(projection["audience"]) + " · revision " + str(projection["revision"]) + "</p>"]
    sections.append("<h2>Airport context</h2>" + table(["Airport", "Location ID", "Source period", "Enplanements", "Owner/operator records"],
                    [[a["name"], a["locid"], a.get("calendar_year"), a.get("enplanements"), "; ".join(o["name"] + " — " + o["relationship"] for o in data["organizations"] if o["airport_id"] == a["id"])] for a in data["airports"]]))
    sections.append("<p>Enplanements are boarded revenue passengers in the stated FAA calendar year. Published traffic and ownership records do not establish local AI readiness, staffing, budgets or operating improvements.</p>")
    sections.append("<h2>Use cases and evidence</h2>" + table(["Use case", "Input basis", "Problem", "Objective", "Cohort", "Owner"],
                    [[r["name"], r["basis_kind"], r.get("problem"), r.get("objective"), r.get("cohort"), r.get("owner")] for r in data["use_cases"]]))
    sections.append("<h2>Readiness</h2>" + table(["Airport", "Evidence present", "Domains"], [[r["airport_id"], str(r["evidenced_domains"]) + "/" + str(r["domain_count"]), r["domains"]] for r in computed["readiness"]]))
    sections.append("<h2>Delivery alternatives</h2>" + table(["Alternative", "Model", "Cost calculation", "Benefit assumptions", "Preference calculation"],
                    [[r["name"], r["model"], r.get("cost"), r.get("benefit"), r.get("preference")] for r in computed["option_comparisons"]]))
    statuses = {r["decision_id"]: r for r in computed["decisions"]}
    sections.append("<h2>Retained decisions</h2>" + table(["Action", "Operator", "Rationale", "Review state", "Original input SHA-256"],
                    [[r["action"], r["actor"], r["rationale"], statuses.get(r["id"], {}).get("status"), r.get("input_sha256")] for r in data["decisions"]]))
    sections.append("<h2>Implementation and operations</h2>" + table(["Work package", "Status", "Owner", "Dates", "Predecessors", "Acceptance", "Maintenance / exit"],
                    [[r["name"], r["status"], r.get("owner"), str(r.get("start_date") or "") + " – " + str(r.get("due_date") or ""), r.get("predecessors"), r.get("acceptance"), str(r.get("maintenance_owner") or "") + " / " + str(r.get("exit_owner") or "")] for r in data["roadmap"]]))
    sections.append("<h3>Shared capacity</h3>" + table(["Pool", "Period", "Unit", "Available", "Committed", "Proposed", "Other project commitments", "Remaining after all commitments"],
                    [[r["pool_id"], r["period"], r["unit"], r["available"], r["committed_demand"], r["proposed_demand"], r.get("outside_scope_committed_demand"), r.get("remaining_after_all_project_commitments", r.get("remaining"))] for r in computed["roadmap"]["capacity"]]))
    sections.append("<h2>Outcomes and cohorts</h2>" + table(["Measure", "Results"], [[r.get("measure_id"), r] for r in computed["measurement"]]))
    sections.append("<h2>Source register</h2>" + table(["Title", "Period", "URL", "SHA-256", "Rights / use"],
                    [[r["title"], r.get("period"), r.get("url"), r.get("sha256"), r.get("rights")] for r in data["sources"]]))
    sections.append("<h2>Interpretation and handover</h2><ul>" + "".join("<li>" + esc(note) + "</li>" for note in projection["notes"]) + "</ul>")
    return ("<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Airport assessment handover</title><style>body{font:15px/1.5 system-ui,sans-serif;color:#222;background:#fff;max-width:1280px;margin:auto;padding:36px}h1{font-size:28px}h2{margin-top:40px;border-top:1px solid #bbb;padding-top:16px}h3{margin-top:28px}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #bbb;padding:8px;text-align:left;vertical-align:top;white-space:pre-wrap;overflow-wrap:anywhere}th{background:#eee}p{max-width:1000px}@media print{body{padding:0}thead{display:table-header-group}tr{break-inside:avoid}}</style><main>" + "".join(sections) + "</main></html>").encode()


def _workpapers(files, projection):
    files["report.html"] = report_html(projection)
    files["handover.json"] = json_bytes(projection)
    schema = engine.schema()
    for collection in COLLECTIONS:
        rows = projection["data"][collection]
        files["workpapers/" + collection + ".json"] = json_bytes(rows)
        columns = ["id", "revision", *schema["collections"][collection]["fields"]]
        # The private archive carries full historical material; recipient decisions use hashes.
        columns = [key for key in columns if key != "input_snapshot"]
        files["workpapers/" + collection + ".csv"] = csv_bytes(rows, columns)
    files["workpapers/calculations.json"] = json_bytes(projection["computed"])
    files["workpapers/field-dictionary.json"] = json_bytes(schema)
    files["implementation-memo.md"] = implementation_memo(projection)


def implementation_memo(projection):
    """Editable implementation material derived only from retained workpapers."""
    data, computed = projection["data"], projection["computed"]
    def cell(value):
        if isinstance(value, (dict, list)):
            value = canonical(value)
        return str(value if value is not None and value != "" else "Not recorded").replace("|", "\\|").replace("\r", "").replace("\n", "<br>")
    def md_table(headers, rows):
        return "| " + " | ".join(cell(h) for h in headers) + " |\n| " + " | ".join("---" for _ in headers) + " |\n" + "".join("| " + " | ".join(cell(v) for v in row) + " |\n" for row in rows) + "\n"
    lines = ["# Implementation of Research Findings and Products\n",
             "## Working material and scope\n",
             f"Project: {cell(data['project']['title'])}. Saved revision: {projection['revision']}. Audience: {projection['audience']}.\n",
             "This editable memo is assembled from the retained assessment workpapers. It supports preparation of the ACRP implementation memorandum; it does not assert completed research, airport participation or an adopted deployment. Every missing owner, institutional role, outcome or research result remains available for the responsible research team to complete from its actual sources.\n",
             "Source structure: [ACRP implementation memorandum template](https://onlinepubs.trb.org/onlinepubs/acrp/ACRP_Implementation_TechMemo_Template_2019.pdf).\n",
             "## A. Tactics to facilitate implementation\n"]
    if data["roadmap"]:
        lines.append(md_table(["Work package", "Status / decision", "Owner", "Dates", "Dependencies", "Acceptance", "Maintenance / exit"],
                              [[r["name"], {"status": r["status"], "decision_id": r.get("decision_id")}, r.get("owner"),
                                {"start": r.get("start_date"), "due": r.get("due_date")},
                                {"within_scope": r.get("predecessors"), "outside_scope_impacts": r.get("outside_scope_prerequisites")},
                                r.get("acceptance"), {"maintenance": r.get("maintenance_owner"), "exit": r.get("exit_owner")}] for r in data["roadmap"]]))
    else:
        lines.append("No implementation work packages have been recorded. Use the saved opportunity and decision workpapers to assign source-supported tactics, owners, dependencies and acceptance.\n")
    lines.append("## B. Institutions and potential implementation roles\n")
    lines.append("The following rows preserve recorded organizational relationships. An owner, operator or other published relationship does not by itself establish a commitment to this research or authority over a proposed implementation.\n")
    lines.append(md_table(["Organization", "Airport", "Recorded relationship", "Authority scope", "Source"],
                          [[r["name"], r["airport_id"], r["relationship"], r.get("authority_scope"), r.get("source_id")] for r in data["organizations"]]))
    lines.append("## C. Potential impediments and treatment\n")
    lines.append(md_table(["Risk / capability", "Exposure or gap", "Control / proposed action", "Owner", "Remaining exposure / review"],
                          [[r["name"], r.get("failure_mode"), r.get("control") or r.get("treatment"), r.get("owner"),
                            {"remaining": r.get("remaining_exposure"), "review": r.get("review_date")}] for r in data["risks"]]
                          + [[r["domain"], r.get("gap"), r.get("proposed_action"), r.get("owner"),
                              {"status": r["status"], "review": r.get("review_date")}] for r in data["capabilities"] if r.get("gap") or r["status"] != "established"]))
    lines.append("### Capacity and dependency findings\n")
    lines.append("```json\n" + json.dumps(computed["roadmap"], ensure_ascii=False, indent=2) + "\n```\n")
    lines.append("## D. Measures of use and benefit\n")
    lines.append("Targets and observations retain their saved cohort, unit, time window and basis. Authored calculator scenarios remain planning assumptions. Product-use measures must be supplied explicitly by the research team; no usage or adoption count is inferred from opening this application.\n")
    lines.append(md_table(["Measure", "Definition", "Cohort / window", "Unit", "Exclusions / failure", "Target and basis", "Owner"],
                          [[r["name"], r.get("definition"), {"cohort": r["cohort"], "window": r.get("window_basis")}, r["unit"],
                            {"exclusions": r.get("exclusion_rule"), "failure": r.get("failure_criterion")},
                            {"target": r.get("target"), "direction": r.get("desired_direction"), "basis": r.get("target_basis")}, r.get("owner")] for r in data["measures"]]))
    lines.append("```json\n" + json.dumps(computed["measurement"], ensure_ascii=False, indent=2) + "\n```\n")
    lines.append("## E. Related FAA source material\n")
    faa = [r for r in data["sources"] if re.match(r"https?://(?:[^/]+\.)?faa\.gov(?:/|$)", r.get("url") or "")]
    lines.append(md_table(["Source", "Period", "URL", "Retained SHA-256"], [[r["title"], r.get("period"), r.get("url"), r.get("sha256")] for r in faa]))
    lines.append("These references identify related retained FAA material. The record does not establish that a source is an approval, an applicable requirement or a completed compliance assessment. Record the applicability judgment in the research workpapers.\n")
    lines.append("## F. Research record and remaining gaps\n")
    lines.append(md_table(["Record / method", "Finding", "Limitations", "Guide section", "Gap", "Participant status", "Source"],
                          [[r["name"] + " / " + r["method"], r.get("finding"), r.get("limitations"), r.get("guide_section"), r.get("gap"), r.get("participant_status"), r.get("source_id")] for r in data["research"]]))
    lines.append("## Appendices and continuation\n")
    lines.append("`handover.json` binds this material to the saved project and report scope. `workpapers/` contains editable records, the complete field dictionary and calculation outputs. Original source attachments appear only when explicitly selected. The separate private continuation archive retains complete historical decision inputs and revision/request history for continued work.\n")
    return ("\n".join(lines)).encode()


def export_project(workspace, project_id, audience="private_restore", airport_id=None, use_case_id=None, include_source_ids=None):
    snapshot = workspace.snapshot(project_id)
    state = snapshot["state"]
    files, originals = {}, []
    if audience == "private_restore":
        schema = PRIVATE_SCHEMA
        included_files = state["files"]
        files.update({"project.json": json_bytes(state), "history/events.json": json_bytes(snapshot["events"]),
                      "history/requests.json": json_bytes(snapshot["requests"]), "calculations.json": json_bytes(engine.analyze(state))})
        files["README.txt"] = b"Airport assessment private continuation archive\n\nThis archive contains the complete project, original bytes, all imported source rows and selection receipts, full reviewed decision snapshots, revision chain and saved request outcomes. Restore into the local application to continue. Recipient handovers are separate scoped exports.\n"
    else:
        schema = RECIPIENT_SCHEMA
        projection = project_projection(state, audience, airport_id, use_case_id)
        selected = include_source_ids or []
        if not isinstance(selected, list) or any(not isinstance(item, str) for item in selected) or len(set(selected)) != len(selected):
            raise ValueError("Choose explicit unique source IDs for recipient originals.")
        if not set(selected) <= set(projection["included_source_ids"]):
            raise ValueError("An original source selection is outside this report's source register.")
        if any(item not in state["source_files"] for item in selected):
            raise ValueError("A selected source has no retained original bytes.")
        file_ids = {state["source_files"][source_id] for source_id in selected}
        included_files = [item for item in state["files"] if item["id"] in file_ids]
        projection["selected_original_source_ids"] = selected
        _workpapers(files, projection)
        files["README.txt"] = ("Airport assessment recipient handover\n\nOpen report.html. The workpapers directory contains editable JSON and spreadsheet-safe CSV; JSON retains exact values and nulls. Original files are included only for the explicit selected_original_source_ids in handover.json. One original can contain more rows than the selected airport scope; review the source selection for the recipient. Private revision/request history and complete historical decision snapshots are omitted. This bundle cannot restore the working project.\n").encode()
    for original in included_files:
        raw = snapshot["raw"][original["sha256"]]
        if len(raw) != original["bytes"] or hashlib.sha256(raw).hexdigest() != original["sha256"]:
            raise ValueError("Retained original source bytes have a different identity.")
        path = "originals/" + original["id"] + "/" + safe_name(original["filename"])
        files[path] = raw
        originals.append({"file_id": original["id"], "filename": original["filename"], "sha256": original["sha256"], "bytes": original["bytes"], "path": path})
    manifest = {"schema": schema, "audience": audience, "project_id": state["id"], "revision": state["revision"],
                "airport_id": airport_id, "use_case_id": use_case_id, "sources": originals,
                "files": {path: {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)} for path, raw in sorted(files.items())}}
    files["manifest.json"] = json_bytes(manifest)
    if len(files) > 4096 or sum(len(raw) for raw in files.values()) > MAX_ARCHIVE_BYTES:
        raise ValueError("The handover exceeds 192 MiB or 4,096 files. Choose an explicit smaller source cohort or airport scope.")
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, raw in sorted(files.items()):
            archive.writestr(path, raw)
    return output.getvalue(), manifest


def import_project(workspace, raw):
    if not raw or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError("Private continuation ZIP is empty or exceeds 192 MiB.")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            if len(entries) > 4096 or sum(item.file_size for item in entries) > MAX_ARCHIVE_BYTES or len({item.filename for item in entries}) != len(entries):
                raise ValueError("Archive expands beyond the supported limit or repeats a path.")
            for item in entries:
                path = PurePosixPath(item.filename)
                if path.is_absolute() or ".." in path.parts or "\\" in item.filename or item.is_dir() or str(path) != item.filename:
                    raise ValueError("Private archive contains an invalid path.")
            files = {item.filename: archive.read(item) for item in entries}
    except (zipfile.BadZipFile, RuntimeError, OSError) as exc:
        raise ValueError("Unable to read the private continuation ZIP.") from exc
    try:
        manifest = _json(files["manifest.json"])
        if manifest.get("schema") != PRIVATE_SCHEMA or manifest.get("audience") != "private_restore":
            raise ValueError("Only a complete private continuation archive can restore a project. Recipient handovers intentionally omit working records.")
        if set(manifest["files"]) != set(files) - {"manifest.json"}:
            raise ValueError("Archive files do not exactly match their manifest.")
        for path, identity in manifest["files"].items():
            if len(files[path]) != identity["bytes"] or hashlib.sha256(files[path]).hexdigest() != identity["sha256"]:
                raise ValueError("Archive content hash or byte length differs: " + path)
        state = _json(files["project.json"])
        if state["id"] != manifest["project_id"] or state["revision"] != manifest["revision"]:
            raise ValueError("Archive and project identities disagree.")
        source_records = {record["id"]: record for record in state["files"]}
        if len(manifest["sources"]) != len(source_records) or {item["file_id"] for item in manifest["sources"]} != set(source_records):
            raise ValueError("Private source inventory differs from the complete original-file register.")
        originals = {}
        for entry in manifest["sources"]:
            source = source_records[entry["file_id"]]
            if any(entry[key] != source[key] for key in ("filename", "sha256", "bytes")):
                raise ValueError("Original file metadata differs from the archived identity.")
            content = files[entry["path"]]
            if entry["sha256"] in originals and originals[entry["sha256"]] != content:
                raise ValueError("Repeated original identity has different bytes.")
            originals[entry["sha256"]] = content
        return workspace.restore_snapshot({"state": state, "raw": originals, "events": _json(files["history/events.json"]), "requests": _json(files["history/requests.json"])})
    except (KeyError, TypeError, json.JSONDecodeError, IndexError) as exc:
        raise ValueError("Private archive contains malformed or missing required records.") from exc
