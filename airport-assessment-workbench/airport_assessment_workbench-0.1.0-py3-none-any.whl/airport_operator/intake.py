"""Airport source intake over the unchanged NEKCV CSV/JSON/XLSX parser.

The caller retains original bytes. This module returns complete parsed tables and
explicitly mapped records; it neither changes saved projects nor infers authority.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from decimal import Decimal, InvalidOperation

if __package__:
    from .source_intake import IntakeError, parse_source as _parse_source
else:
    from source_intake import IntakeError, parse_source as _parse_source

SCHEMA = "acrp.airport-intake.v1"
FAA_SERVICE = {"P", "CS", "GA"}
FAA_FOOTERS = {"Large Count", "Medium Count", "Small Count", "Nonhub Count",
               "Nonprimary Commercial Service", "None Count"}


def parse_source(raw: bytes, filename: str, options: dict | None = None) -> dict:
    """Full native source parser; values and original coordinates remain intact."""
    return _parse_source(raw, filename, options)


def _table(source, table_id=None):
    tables = source.get("tables", [])
    if table_id is None and len(tables) == 1:
        return tables[0]
    found = [t for t in tables if t.get("id") == table_id]
    if len(found) != 1:
        raise IntakeError("Select one exact table_id from the parsed source.")
    return found[0]


def _number(value, field, integer=False, nonnegative=False):
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise IntakeError(f"{field} must be a number, not a boolean.")
    try:
        number = Decimal(str(value))
    except InvalidOperation as exc:
        raise IntakeError(f"{field} is not an exact decimal number: {value!r}.") from exc
    if not number.is_finite() or (nonnegative and number < 0):
        raise IntakeError(f"{field} must be a finite {'nonnegative ' if nonnegative else ''}number.")
    if integer and number != number.to_integral_value():
        raise IntakeError(f"{field} must be an integer count.")
    return int(number) if integer else str(value)


def _reference(source, table, index):
    origin = table.get("row_origins", [])[index]
    return {"source_id": source["id"], "source_sha256": source["sha256"],
            "table_id": table["id"], "table_name": table["name"],
            "row_index": index, "origin": origin,
            "source_values": dict(table["rows"][index])}


def faa_airports(source: dict, calendar_year: int, table_id: str | None = None) -> dict:
    """Interpret an explicitly selected FAA enplanement table, retaining footers.

    S/L classifies data rows. A nonempty Locid alone does not identify an airport:
    the original workbook stores numeric publisher counts in that same column.
    """
    if isinstance(calendar_year, bool) or not isinstance(calendar_year, int) or not 1901 <= calendar_year <= 9999:
        raise IntakeError("Supply the actual four-digit calendar_year from the FAA publication.")
    table = _table(source, table_id)
    by_name = {}
    for column in table["columns"]:
        if column["name"] in by_name:
            raise IntakeError("FAA mapping needs unique original header names; select the correct header row.")
        by_name[column["name"]] = column["key"]
    current = f"CY {calendar_year % 100:02d} Enplanements"
    previous = f"CY {(calendar_year - 1) % 100:02d} Enplanements"
    mapping = {"rank": "Rank", "region": "RO", "state": "ST", "locid": "Locid",
               "city": "City", "name": "Airport Name", "service_level": "S/L", "hub": "Hub",
               "enplanements": current, "prior_enplanements": previous, "change_ratio": "% Change"}
    missing = [name for name in mapping.values() if name not in by_name]
    if missing:
        raise IntakeError("Selected FAA table lacks exact headers: " + ", ".join(missing))
    keys = {field: by_name[name] for field, name in mapping.items()}
    airports, summaries, blanks, unclassified, findings = [], [], [], [], []
    seen = Counter()
    for index, row in enumerate(table["rows"]):
        values = {field: row.get(key) for field, key in keys.items()}
        ref = _reference(source, table, index)
        if all(value in (None, "") for value in row.values()):
            blanks.append({"values": values, "source_ref": ref})
            continue
        if values["service_level"] not in FAA_SERVICE:
            label = values["city"]
            target = summaries if isinstance(label, str) and label.strip() in FAA_FOOTERS else unclassified
            target.append({"values": values, "source_ref": ref})
            continue
        locid = values["locid"]
        if not isinstance(locid, str) or not locid:
            raise IntakeError(f"FAA data row {index + 1} has no location identifier.")
        seen[locid] += 1
        airports.append({**values, "id": "faa-" + locid, "revision": 1,
                         "calendar_year": calendar_year,
                         "rank": _number(values["rank"], "Rank", True, True),
                         "enplanements": _number(values["enplanements"], current, True, True),
                         "prior_enplanements": _number(values["prior_enplanements"], previous, True, True),
                         "change_ratio": _number(values["change_ratio"], "% Change"),
                         "basis_kind": "published", "source_id": source["id"], "source_ref": ref})
    duplicates = [key for key, count in seen.items() if count > 1]
    if duplicates:
        findings.append({"code": "duplicate_faa_locid", "locids": duplicates,
                         "message": "Repeated location identifiers require an explicit source decision before adoption."})
    if unclassified:
        findings.append({"code": "unclassified_source_rows", "count": len(unclassified),
                         "message": "These original rows were retained separately; they were not silently discarded or treated as airports."})
    hubs = Counter(a["hub"] for a in airports)
    for summary in summaries:
        values = summary["values"]
        if values["city"].strip() == "None Count":
            count = _number(values["locid"], "Publisher None Count", True, True)
            literal = hubs.get("None", 0)
            if count != literal:
                findings.append({"code": "publisher_none_count_differs", "publisher_count": count,
                                 "literal_hub_none_rows": literal, "source_ref": summary["source_ref"],
                                 "message": "The source footer label and literal hub count differ; both original values are retained."})
    return {"schema": SCHEMA, "source_id": source["id"], "calendar_year": calendar_year,
            "airports": airports, "summary_rows": summaries, "blank_rows": blanks, "unclassified_rows": unclassified,
            "counts": {"airports": len(airports), "summary_rows": len(summaries),
                       "blank_rows": len(blanks), "unclassified_rows": len(unclassified), "service_level": dict(Counter(a["service_level"] for a in airports)),
                       "hub": dict(hubs)}, "findings": findings,
            "semantics": {"traffic": "Calendar-year revenue passenger enplanements; not total arriving plus departing passengers.",
                          "change_ratio": "Original ratio; multiply by 100 only for percent display.",
                          "local_inputs": "Published traffic does not establish staffing, AI maturity, budget, access or approval authority."}}


def map_records(source: dict, table_id: str, mapping: dict, *, collection: str,
                constants: dict | None = None, key_field: str | None = None) -> dict:
    """Stage all rows through explicit destination-field -> source-column keys.

    The engine validates destination types; nested JSON is converted only through
    an explicit mapping descriptor {column_key, decode: 'json'}. No name matching,
    trimming, join or row sampling occurs.
    """
    table = _table(source, table_id)
    valid = {column["key"] for column in table["columns"]}
    if not isinstance(mapping, dict) or not mapping:
        raise IntakeError("Supply an explicit field-to-column mapping.")
    constants = dict(constants or {})
    if set(mapping) & set(constants):
        raise IntakeError("A field cannot be both mapped and a constant.")
    descriptors = {}
    for field, value in mapping.items():
        descriptor = {"column_key": value} if isinstance(value, str) else dict(value)
        if descriptor.get("column_key") not in valid or descriptor.get("decode") not in (None, "json"):
            raise IntakeError(f"Invalid source column or explicit decoder for {field!r}.")
        descriptors[field] = descriptor
    records, findings, seen = [], [], Counter()
    for index, row in enumerate(table["rows"]):
        record = dict(constants)
        for field, descriptor in descriptors.items():
            value = row.get(descriptor["column_key"])
            if descriptor.get("decode") == "json" and value not in (None, ""):
                try:
                    value = json.loads(value, parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
                except (ValueError, TypeError) as exc:
                    raise IntakeError(f"Row {index + 1}, {field}: explicitly selected JSON decoding failed.") from exc
            record[field] = value
        key = record.get(key_field) if key_field else None
        if key_field and (not isinstance(key, str) or not key):
            raise IntakeError(f"Row {index + 1} has no nonempty text value for its declared key field.")
        record.setdefault("id", key or collection + "-" + hashlib.sha256(f"{source['id']}:{table_id}:{index}".encode()).hexdigest()[:24])
        if not isinstance(record["id"], str) or not record["id"]:
            raise IntakeError(f"Row {index + 1} maps an invalid record id; select a nonempty text identifier.")
        record.setdefault("revision", 1)
        record["source_id"] = source["id"]
        record["source_ref"] = _reference(source, table, index)
        seen[record["id"]] += 1
        records.append(record)
    duplicates = [key for key, count in seen.items() if count > 1]
    if duplicates:
        findings.append({"code": "duplicate_mapped_ids", "ids": duplicates,
                         "message": "Every row is retained. Resolve the explicit key mapping before adopting records with repeated IDs."})
    return {"schema": SCHEMA, "collection": collection, "source_id": source["id"],
            "table_id": table_id, "mapping": mapping, "constants": constants,
            "records": records, "findings": findings, "row_count": len(records)}
