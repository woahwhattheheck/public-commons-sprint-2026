"""Local HTTP application over the original airport decision engine."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import sys
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

if __package__:
    from . import engine, exports
    from .workspace import Workspace, Conflict, SCHEMA, _json, _filename
else:
    import engine
    import exports
    from workspace import Workspace, Conflict, SCHEMA, _json, _filename

ROOT = Path(__file__).resolve().parent
MAX_JSON_BYTES = 72 * 1024 * 1024
MAX_RESTORE_JSON_BYTES = 256 * 1024 * 1024 + 4096


def demo_root():
    for path in (ROOT / "demo", ROOT.parent / "demo"):
        if (path / "public-project.json").is_file() and (path / "sources/source_manifest.json").is_file():
            return path
    raise FileNotFoundError("The public example data is not installed with this application.")


def seed_demo(workspace, kind="public"):
    if kind not in ("public", "authored"):
        raise ValueError("Choose the public airport context or the separate authored planning example.")
    folder = demo_root()
    seed_path = folder / ("public-project.json" if kind == "public" else "example-planning-project.json")
    seed_bytes = seed_path.read_bytes()
    state = _json(seed_bytes)
    original_state = deepcopy(state)
    manifest_bytes = (folder / "sources/source_manifest.json").read_bytes()
    manifest = _json(manifest_bytes)
    entries = list(manifest["entries"])
    entries.append({"file": "source_manifest.json", "sha256": hashlib.sha256(manifest_bytes).hexdigest(), "bytes": len(manifest_bytes)})
    source_by_filename = {row["filename"]: row for row in state["sources"] if row.get("filename")}
    originals = {}
    for entry in entries:
        filename = _filename(entry["file"])
        raw = (folder / "sources" / filename).read_bytes()
        if len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise ValueError("Packaged public source differs from its manifest: " + filename)
        if filename in source_by_filename:
            source = source_by_filename[filename]
            if source["sha256"] != entry["sha256"]:
                raise ValueError("Example source record differs from the retained publication.")
        else:
            source = {"id": "reference-" + hashlib.sha256(filename.encode()).hexdigest()[:24], "revision": 1,
                      "title": filename, "kind": "public_reference" if entry.get("source_url") else "public_source_derivative",
                      "filename": filename, "sha256": entry["sha256"],
                      "url": entry.get("source_url", ""), "retrieved_at": entry.get("retrieved_at", ""),
                      "notes": "Retained public source package reference. " + ("Derived from " + json.dumps(entry["derived_from"], ensure_ascii=False) if entry.get("derived_from") else "")}
            state["sources"].append(source)
        originals[source["id"]] = (filename, raw)
    for source in original_state["sources"]:
        if source["id"] not in originals:
            raise ValueError("The public manifest omits an original source used by the example.")
    project_id = "acrp-public-example" if kind == "public" else "acrp-authored-planning-example"
    title = "Public airport context and planning templates" if kind == "public" else "Authored airport planning example — calculator and decision workflow"
    # Project metadata and unreferenced package sources do not change the engine's
    # historical material snapshots. The frozen original records remain identical.
    seed_identity = hashlib.sha256(seed_bytes + b"\n" + manifest_bytes).hexdigest()
    result = workspace.adopt_seed(state, originals, project_id=project_id, title=title, seed_sha256=seed_identity)
    return {**result, "kind": kind, "original_seed_sha256": hashlib.sha256(seed_bytes).hexdigest(),
            "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(), "original_count": len(originals)}


def catalog():
    result = engine.schema()
    result.update({"workspace_schema": SCHEMA,
                   "operations": ["record.save", "record.delete", "project.rename", "source.add", "records.import", "decision.record"],
                   "audiences": ["project", "airport", "use_case", "private_restore"],
                   "source_mappers": ["inspect", "faa", "fields"],
                   "limits": {"source_bytes": 32 * 1024 * 1024, "project_original_bytes": 128 * 1024 * 1024,
                              "state_bytes": 48 * 1024 * 1024, "collection_records": 100000, "preview_records": 100, "page_records": 500},
                   "import_contract": {"source_id": "", "parse_options": {}, "mapper": "inspect"},
                   "decision_contract": {"use_case_id": "", "option_id": None, "action": "investigate", "rationale": "", "conditions": [], "next_review": None}})
    try:
        contract = demo_root() / "sources/airport-decision-contract.json"
        result["source_contract"] = _json(contract.read_bytes()) if contract.is_file() else None
    except FileNotFoundError:
        result["source_contract"] = None
    return result


def handler_for(workspace):
    class Handler(BaseHTTPRequestHandler):
        server_version = "AirportAssessment/0.1"
        protocol_version = "HTTP/1.1"

        def setup(self):
            super().setup()
            self.connection.settimeout(30)

        def log_message(self, format, *args):
            sys.stderr.write(f"{self.log_date_time_string()} {format % args}\n")

        def send(self, body, content_type="application/json; charset=utf-8", status=200, filename=None):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, ensure_ascii=False, allow_nan=False).encode()
            elif isinstance(body, str):
                body = body.encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
            if filename:
                self.send_header("Content-Disposition", 'attachment; filename="' + exports.safe_name(filename) + '"')
            self.end_headers()
            self.wfile.write(body)

        def check_origin(self):
            allowed = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
            if self.headers.get("Host") not in allowed:
                raise ValueError("Open the loopback application address printed by the server.")
            origin = self.headers.get("Origin")
            if origin and (urlsplit(origin).scheme != "http" or urlsplit(origin).netloc not in allowed):
                raise ValueError("This local application does not accept cross-origin requests.")

        def body(self, maximum=MAX_JSON_BYTES):
            if self.headers.get("Transfer-Encoding"):
                raise ValueError("Send an explicit Content-Length for this bounded JSON request.")
            if self.headers.get("Content-Type", "").split(";", 1)[0].strip() != "application/json":
                raise ValueError("This endpoint accepts application/json.")
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= maximum:
                raise ValueError("The JSON request is empty or exceeds this endpoint's size limit.")
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("The request ended before its declared content length.")
            value = _json(raw)
            if not isinstance(value, dict):
                raise ValueError("Request body must be an object.")
            return value

        def do_GET(self):
            try:
                self.check_origin()
                url = urlsplit(self.path)
                bits = [unquote(part) for part in url.path.split("/") if part]
                query = {key: values[0] for key, values in parse_qs(url.query).items()}
                if not bits or bits == ["index.html"]:
                    return self.send((ROOT / "web/index.html").read_bytes(), "text/html; charset=utf-8")
                if len(bits) == 1 and bits[0] in ("app.js", "styles.css", "style.css"):
                    return self.send((ROOT / "web" / bits[0]).read_bytes(), "application/javascript; charset=utf-8" if bits[0].endswith(".js") else "text/css; charset=utf-8")
                if bits == ["api", "status"]:
                    return self.send({"workspace_schema": SCHEMA, "engine_schema": engine.SCHEMA, "mode": "local_operator", "runtime_dependencies": [], "network_clients": 0})
                if bits == ["api", "catalog"]:
                    return self.send(catalog())
                if bits == ["api", "projects"]:
                    return self.send(workspace.list_projects())
                if len(bits) >= 3 and bits[:2] == ["api", "projects"]:
                    project_id = bits[2]
                    if len(bits) == 3:
                        return self.send(workspace.get(project_id))
                    if bits[3:] == ["history"]:
                        return self.send(workspace.history(project_id, query.get("offset", 0), query.get("limit", 100)))
                    if len(bits) in (5, 6) and bits[3] == "records":
                        if len(bits) == 6:
                            return self.send(workspace.record(project_id, bits[4], bits[5]))
                        return self.send(workspace.records(project_id, bits[4], query.get("offset", 0), query.get("limit", 100), query.get("airport_id"), query.get("use_case_id")))
                    if len(bits) == 5 and bits[3] == "imports":
                        return self.send(workspace.import_record(project_id, bits[4]))
                    if len(bits) == 5 and bits[3] == "files":
                        raw, original = workspace.original(project_id, bits[4])
                        return self.send(raw, "application/octet-stream", filename=original["filename"])
                    if bits[3:] in (["projection"], ["report"], ["analysis"]):
                        projection = workspace.projection(project_id, query.get("audience", "project"), query.get("airport_id"), query.get("use_case_id"))
                        if bits[-1] == "report":
                            return self.send(exports.report_html(projection), "text/html; charset=utf-8")
                        return self.send(projection["computed"] if bits[-1] == "analysis" else projection)
                    if bits[3:] == ["export"]:
                        audience = query.get("audience", "private_restore")
                        selected = [value for value in query.get("include_source_ids", "").split(",") if value]
                        raw, manifest = exports.export_project(workspace, project_id, audience, query.get("airport_id"), query.get("use_case_id"), selected)
                        return self.send(raw, "application/zip", filename=f"airport-{audience}-{project_id}-r{manifest['revision']}.zip")
                return self.send({"error": "Resource not found."}, status=404)
            except Exception as exc:
                self.error(exc)

        def do_POST(self):
            try:
                self.check_origin()
                bits = [unquote(part) for part in urlsplit(self.path).path.split("/") if part]
                body = self.body(MAX_RESTORE_JSON_BYTES if bits == ["api", "restore"] else MAX_JSON_BYTES)
                if bits == ["api", "projects"]:
                    return self.send(workspace.create(body.get("title"), body.get("actor", "Operator"), body.get("id")), status=201)
                if bits == ["api", "demo"]:
                    return self.send(seed_demo(workspace, body.get("kind", "public")), status=201)
                if bits == ["api", "restore"]:
                    encoded = body.get("content_base64")
                    if not isinstance(encoded, str):
                        raise ValueError("Restore needs the complete private ZIP as content_base64.")
                    return self.send(exports.import_project(workspace, base64.b64decode(encoded, validate=True)))
                if len(bits) == 4 and bits[:2] == ["api", "projects"] and bits[3] == "operations":
                    return self.send(workspace.apply(bits[2], body["operation"], body.get("payload", {}), body["expected_revision"], body["request_id"], body.get("actor", "Operator")))
                if len(bits) == 5 and bits[:2] == ["api", "projects"] and bits[3:] == ["intake", "preview"]:
                    return self.send(workspace.intake_preview(bits[2], body.get("specification"), body.get("offset", 0), body.get("limit", 100)))
                return self.send({"error": "Endpoint not found."}, status=404)
            except Exception as exc:
                self.error(exc)

        def error(self, exc):
            if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
                return
            self.close_connection = True
            if isinstance(exc, Conflict):
                return self.send({"error": str(exc), "current_revision": exc.current_revision, "input_preserved": True}, status=409)
            if isinstance(exc, (KeyError, FileNotFoundError)):
                return self.send({"error": str(exc).strip("'")}, status=404)
            if isinstance(exc, (ValueError, TypeError, UnicodeError)):
                return self.send({"error": str(exc)}, status=400)
            sys.stderr.write("Airport workspace failure: " + type(exc).__name__ + "\n")
            return self.send({"error": "The operation could not complete. Its transaction was not partially saved."}, status=500)
    return Handler


def main(argv=None):
    parser = argparse.ArgumentParser(description="Airport AI assessment and implementation workbench")
    parser.add_argument("--workspace", type=Path, default=Path("airport-workspace"))
    parser.add_argument("--port", type=int, default=8771)
    parser.add_argument("--demo", action="store_true", help="Load original public airport context and planning templates once")
    parser.add_argument("--authored-demo", action="store_true", help="Load the separate authored calculator/workflow example once")
    parser.add_argument("--restore", type=Path, help="Restore a complete private continuation ZIP")
    parser.add_argument("--export", metavar="PROJECT_ID", help="Export the selected project and exit")
    parser.add_argument("--audience", choices=("private_restore", "project", "airport", "use_case"), default="private_restore")
    parser.add_argument("--airport-id")
    parser.add_argument("--use-case-id")
    parser.add_argument("--include-source-id", action="append", default=[], help="Explicit original source selection for a recipient export")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    workspace = Workspace(args.workspace / "projects.sqlite3")
    if args.restore:
        print(json.dumps(exports.import_project(workspace, args.restore.read_bytes())))
    if args.demo:
        print(json.dumps(seed_demo(workspace, "public")))
    if args.authored_demo:
        print(json.dumps(seed_demo(workspace, "authored")))
    if args.export:
        if not args.output:
            parser.error("--export requires --output")
        raw, manifest = exports.export_project(workspace, args.export, args.audience, args.airport_id, args.use_case_id, args.include_source_id)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_bytes(raw)
        print(json.dumps({"output": str(args.output), "bytes": len(raw), "project_id": manifest["project_id"], "revision": manifest["revision"], "audience": manifest["audience"]}))
        return
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler_for(workspace))
    print(f"Airport assessment workbench: http://127.0.0.1:{server.server_port}", flush=True)
    print(f"Workspace: {args.workspace.resolve()}", flush=True)
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
