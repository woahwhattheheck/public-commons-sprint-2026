"""Saved airport adoption decisions, source-bound comparisons and workpapers.

Pure functions over JSON collections. Persistence, identity and HTTP belong to
the caller. Numerical preferences are explicitly authored by the operator.
"""
from __future__ import annotations

import copy
import hashlib
import json
import uuid
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, localcontext
from functools import wraps

SCHEMA = "acrp.airport-ai-workspace.v1"


class DomainError(ValueError):
    pass


def _fields(text):
    result = {}
    for item in text.split():
        parts = item.split(":")
        name, kind = parts[0], parts[1] if len(parts) > 1 else "text"
        result[name] = {"type": kind, "label": name.replace("_", " ").capitalize()}
        if len(parts) > 2:
            result[name]["choices"] = parts[2].split(",")
    return result


_SPECS = {
    "sources": ("Sources", "title", "title kind:text url sha256 retrieved_at published_date period rights notes"),
    "airports": ("Airports", "name locid", "name locid state city region calendar_year:integer enplanements:integer prior_enplanements:integer change_ratio:number service_level:enum:P,CS,GA hub source_id"),
    "organizations": ("Organizations and authority", "name airport_id relationship", "name airport_id relationship:enum:owner,operator,approving_body,regulator,tenant,concessionaire,funder,other authority_scope effective_date:date source_id"),
    "parameters": ("Airport parameters", "name airport_id basis_kind", "name airport_id value:json unit period basis_kind:enum:published,observed,planning_assumption,unknown basis supplied_by source_id"),
    "use_cases": ("Use cases", "name airport_id basis_kind", "name airport_id problem current_workflow owner objective cohort scope basis_kind:enum:observed,planning_assumption,published,unknown source_id"),
    "data_assets": ("Data assets", "name", "name airport_id use_case_id custodian permitted_use permission_status:enum:unknown,requested,confirmed,unavailable coverage period schema:json access_method update_frequency sensitive_categories:json retention quality_findings:json source_id"),
    "capabilities": ("Readiness profile", "airport_id domain status", "airport_id domain:enum:leadership,business_ownership,workforce,change,data,integration,runtime,procurement,maintenance status:enum:unknown,absent,developing,established owner evidence review_date:date gap proposed_action source_id"),
    "rubrics": ("Operator preference models", "name criteria", "name criteria:json author adopted_by notes"),
    "assessments": ("Opportunity assessments", "use_case_id", "use_case_id rubric_id strategic_fit baseline_validity data_suitability operating_feasibility workforce_effects alternatives:json findings:json author"),
    "risks": ("Adoption risks", "name use_case_id", "name use_case_id failure_mode affected_party likelihood_basis impact_basis control owner treatment remaining_exposure review_date:date source_id"),
    "options": ("Delivery alternatives", "name use_case_id model", "name use_case_id model:enum:build,buy,partner,process_only scope responsibilities integration dependencies support exit_plan currency horizon_periods:integer periods_per_year:integer discount_rate:number rate_basis rubric_id scores:json benefit_model:json source_id"),
    "cost_items": ("Cost assumptions", "name quantity unit_rate currency basis_kind", "name option_id allocations:json category quantity:number unit unit_rate:number currency start_period:integer end_period:integer every_periods:integer basis_kind:enum:published,observed,quote,planning_assumption,unknown basis owner source_id"),
    "decisions": ("Retained decisions", "use_case_id actor action rationale", "use_case_id option_id actor action:enum:investigate,pilot,adopt,defer,decline rationale conditions:json decided_at next_review:date input_sha256 input_snapshot:json"),
    "capacity_pools": ("Shared staff capacity", "name unit availability", "name unit availability:json owner basis_kind:enum:observed,planning_assumption,unknown basis source_id"),
    "roadmap": ("Implementation and operations", "name use_case_id status", "name use_case_id decision_id status:enum:proposed,planned,in_progress,complete,cancelled owner start_date:date due_date:date predecessors:json demands:json acceptance maintenance_owner exit_owner"),
    "measures": ("Outcome definitions", "name use_case_id kind unit cohort", "name use_case_id kind:enum:rate,mean,count unit definition cohort window_basis exclusion_rule failure_criterion target:number desired_direction:enum:higher,lower target_basis comparisons:json owner source_id"),
    "observations": ("Retained observations", "measure_id phase cohort window basis_kind", "measure_id phase:enum:baseline,observed cohort window eligible:boolean exclusion_reason outcome:enum:success,failure,unknown numerator:number denominator:number value:number basis_kind:enum:observed,published,planning_assumption source_id"),
    "research": ("Research and implementation record", "name method", "name method:enum:public_source,interview,workshop,observation,authored_design source_id finding limitations guide_section gap participant_status date:date"),
}

_REFS = {"airport_id": "airports", "use_case_id": "use_cases", "option_id": "options",
         "source_id": "sources", "rubric_id": "rubrics", "decision_id": "decisions",
         "measure_id": "measures"}


def schema():
    collections = {}
    for name, (label, required, fields) in _SPECS.items():
        properties = _fields(fields)
        for key, spec in properties.items():
            if key in _REFS:
                spec["type"] = "reference"
                spec["collection"] = _REFS[key]
        collections[name] = {"label": label, "required": required.split(), "fields": properties}
    return {"schema": SCHEMA, "collections": collections,
            "notes": ["Unknown inputs remain empty; planning assumptions carry their basis.",
                      "Save decisions through freeze_decision so reviewed inputs are retained.",
                      "Currency, time horizon and cohorts must match before totals are compared."]}


def initial_state(project_id=None, title="Airport AI decision workspace"):
    return {"schema": SCHEMA, "project": {"id": project_id or "airport-" + uuid.uuid4().hex[:16],
                                        "title": title},
            **{name: [] for name in _SPECS}}


def _json(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise DomainError("Project records must contain finite JSON values.") from exc


def _hash(value):
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _calculate(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        with localcontext() as context:
            context.prec = 120
            return function(*args, **kwargs)
    return wrapped


def _decimal(value, field, *, required=True, minimum=None, maximum=None):
    if value is None or value == "":
        if required:
            raise DomainError(f"Supply {field}.")
        return None
    if isinstance(value, bool):
        raise DomainError(f"{field} must be a decimal number, not a boolean.")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise DomainError(f"{field} must be an exact decimal number.") from exc
    if not result.is_finite() or (minimum is not None and result < minimum) or (maximum is not None and result > maximum):
        raise DomainError(f"{field} is outside its permitted finite range.")
    # Bound calculation input size rather than allowing pathological exponents.
    if abs(result.adjusted()) > 100 or len(result.as_tuple().digits) > 36:
        raise DomainError(f"{field} has more precision or magnitude than this planning calculation supports.")
    return result


def _integer(value, field, *, minimum=0, maximum=1200):
    number = _decimal(value, field, minimum=minimum, maximum=maximum)
    if number != number.to_integral_value():
        raise DomainError(f"{field} must be an integer.")
    return int(number)


def _text(number):
    if number is None:
        return None
    value = format(number, "f")
    return value.rstrip("0").rstrip(".") if "." in value else value


def _index(state, collection):
    values = state.get(collection, [])
    if not isinstance(values, list):
        raise DomainError(f"{collection} must be a list of records.")
    result = {}
    for value in values:
        if not isinstance(value, dict) or not isinstance(value.get("id"), str) or not value["id"]:
            raise DomainError(f"Every {collection} record needs a nonempty text id.")
        if value["id"] in result:
            raise DomainError(f"{collection} repeats record id {value['id']!r}.")
        result[value["id"]] = value
    return result


def validate_record(collection, record, state=None):
    """Validate one record without mutating it. References use the supplied state."""
    if collection not in _SPECS or not isinstance(record, dict):
        raise DomainError("Select a known collection and a JSON object record.")
    _json(record)
    if not isinstance(record.get("id"), str) or not record["id"]:
        raise DomainError("A nonempty text record id is required.")
    spec = schema()["collections"][collection]
    for field in spec["required"]:
        if record.get(field) in (None, "") or isinstance(record.get(field), str) and not record[field].strip():
            raise DomainError(f"{spec['label']}: supply {field.replace('_', ' ')}.")
    if "revision" in record:
        _integer(record["revision"], "revision", minimum=1, maximum=2147483647)
    for field, detail in spec["fields"].items():
        value = record.get(field)
        if value in (None, ""):
            continue
        kind = detail["type"]
        if kind in ("text", "reference", "enum", "date") and not isinstance(value, str):
            raise DomainError(f"{field} must be text.")
        if kind == "number":
            _decimal(value, field)
        elif kind == "integer":
            _integer(value, field, minimum=0, maximum=10**15)
        elif kind == "boolean" and not isinstance(value, bool):
            raise DomainError(f"{field} must be true or false.")
        elif kind == "enum" and value not in detail["choices"]:
            raise DomainError(f"{field} must be one of: {', '.join(detail['choices'])}.")
        elif kind == "date":
            try:
                date.fromisoformat(value)
            except ValueError as exc:
                raise DomainError(f"{field} must be an ISO calendar date.") from exc
        elif kind == "reference" and state is not None and value not in _index(state, detail["collection"]):
            raise DomainError(f"{field} refers to a missing {detail['collection']} record.")
    if collection == "rubrics":
        _rubric(record)
    if collection == "cost_items":
        if bool(record.get("option_id")) == bool(record.get("allocations")):
            raise DomainError("A cost item needs either one option_id or explicit shared allocations.")
        _decimal(record["quantity"], "quantity", minimum=0)
        _decimal(record["unit_rate"], "unit_rate", minimum=0)
        if record.get("allocations"):
            allocations = record["allocations"]
            if not isinstance(allocations, list):
                raise DomainError("Shared allocations must be a list.")
            seen, total = set(), Decimal(0)
            for allocation in allocations:
                if not isinstance(allocation, dict) or not allocation.get("option_id"):
                    raise DomainError("Every shared allocation needs option_id and fraction.")
                if allocation["option_id"] in seen:
                    raise DomainError("A shared cost cannot allocate twice to the same option.")
                seen.add(allocation["option_id"])
                if state is not None and allocation["option_id"] not in _index(state, "options"):
                    raise DomainError("Shared allocation refers to a missing option.")
                total += _decimal(allocation.get("fraction"), "allocation fraction", minimum=0, maximum=1)
            if total > 1:
                raise DomainError("Shared cost allocations exceed the original total cost.")
    if collection == "roadmap":
        for field in ("predecessors", "demands"):
            if record.get(field) is not None and not isinstance(record[field], list):
                raise DomainError(f"{field} must be a list.")
    if collection == "capacity_pools":
        if not isinstance(record.get("availability"), dict):
            raise DomainError("Capacity availability is an explicit period-to-quantity object.")
        for period, value in record["availability"].items():
            if not period:
                raise DomainError("Capacity periods cannot be blank.")
            _decimal(value, "available capacity", minimum=0)
    return copy.deepcopy(record)


def _rubric(rubric):
    criteria = rubric.get("criteria")
    if not isinstance(criteria, list) or not criteria:
        raise DomainError("A preference model requires an explicit criteria list.")
    seen, result, total = set(), [], Decimal(0)
    for criterion in criteria:
        if not isinstance(criterion, dict) or not isinstance(criterion.get("id"), str) or not criterion["id"]:
            raise DomainError("Every criterion needs a nonempty text id.")
        if criterion["id"] in seen:
            raise DomainError("Preference criteria repeat an id.")
        seen.add(criterion["id"])
        low = _decimal(criterion.get("min"), "criterion minimum")
        high = _decimal(criterion.get("max"), "criterion maximum")
        weight = _decimal(criterion.get("weight"), "criterion weight", minimum=0)
        if high <= low or criterion.get("direction") not in ("higher", "lower"):
            raise DomainError("Criteria need max > min and direction higher or lower.")
        result.append((criterion, low, high, weight))
        total += weight
    if total <= 0:
        raise DomainError("Preference weights must have a positive total.")
    return result, total


@_calculate
def weighted_comparison(rubric, scores):
    """Missing criteria contribute an interval; their weights are not redistributed."""
    criteria, total = _rubric(rubric)
    if not isinstance(scores, dict):
        raise DomainError("Option scores must be a criterion-id object.")
    known, unknown, known_weight = Decimal(0), Decimal(0), Decimal(0)
    contributions, critical_missing = [], []
    for criterion, low, high, weight in criteria:
        value = scores.get(criterion["id"])
        if value is None or value == "":
            unknown += weight
            if criterion.get("critical"):
                critical_missing.append(criterion["id"])
            contributions.append({"criterion_id": criterion["id"], "weight": _text(weight), "value": None, "contribution": None})
            continue
        value = _decimal(value, "criterion score", minimum=low, maximum=high)
        normalized = (value - low) / (high - low) if criterion["direction"] == "higher" else (high - value) / (high - low)
        contribution = normalized * weight
        known += contribution
        known_weight += weight
        contributions.append({"criterion_id": criterion["id"], "weight": _text(weight),
                              "value": _text(value), "contribution": _text(contribution)})
    complete = all(c["value"] is not None for c in contributions if Decimal(c["weight"]) > 0) and not critical_missing
    return {"rubric_id": rubric["id"], "rubric_revision": rubric.get("revision", 1),
            "complete": complete, "score": _text(known / total) if complete else None,
            "score_lower": _text(known / total), "score_upper": _text((known + unknown) / total),
            "weight_coverage": _text(known_weight / total), "critical_missing": critical_missing,
            "contributions": contributions, "basis": "Explicit operator preference model, not an ACRP rating."}


@_calculate
def option_cost(state, option):
    currency = option.get("currency")
    if not isinstance(currency, str) or not currency:
        raise DomainError("Supply the option scenario currency.")
    horizon = _integer(option.get("horizon_periods"), "horizon_periods", minimum=1)
    per_year = _integer(option.get("periods_per_year"), "periods_per_year", minimum=1, maximum=366)
    discount = _decimal(option.get("discount_rate"), "discount_rate", required=False)
    if discount is not None and discount <= -1:
        raise DomainError("Discount rate must be greater than -1.")
    if discount is not None and not option.get("rate_basis"):
        raise DomainError("State the nominal/real and tax basis when supplying a discount rate.")
    cashflow = defaultdict(Decimal)
    rows, findings = [], []
    for item in state.get("cost_items", []):
        fraction = Decimal(1) if item.get("option_id") == option["id"] else Decimal(0)
        if item.get("allocations"):
            for allocation in item["allocations"]:
                if allocation.get("option_id") == option["id"]:
                    fraction += _decimal(allocation.get("fraction"), "allocation fraction", minimum=0, maximum=1)
        if fraction == 0:
            continue
        validate_record("cost_items", item, state)
        if item["currency"] != currency:
            raise DomainError(f"Cost {item['id']} uses {item['currency']}; no exchange rate was supplied for {currency}.")
        first = _integer(item.get("start_period", 0), "start_period", maximum=horizon)
        step = _integer(item.get("every_periods", 0), "every_periods", maximum=horizon)
        last = _integer(item.get("end_period", horizon if step else first), "end_period", maximum=horizon)
        if last < first or not step and last != first:
            raise DomainError("A one-time cost has one period; recurring cost end must follow its start.")
        periods = list(range(first, last + 1, step)) if step else [first]
        amount = _decimal(item["quantity"], "quantity", minimum=0) * _decimal(item["unit_rate"], "unit_rate", minimum=0) * fraction
        for period in periods:
            cashflow[period] += amount
        rows.append({"cost_id": item["id"], "periods": periods, "allocation_fraction": _text(fraction),
                     "amount_per_period": _text(amount), "total": _text(amount * len(periods)),
                     "basis_kind": item.get("basis_kind"), "basis": item.get("basis", "")})
        if not item.get("basis") or item.get("basis_kind") == "unknown":
            findings.append({"code": "cost_basis_missing", "record_id": item["id"]})
    total = sum(cashflow.values(), Decimal(0))
    present = None
    if discount is not None:
        with localcontext() as context:
            context.prec = 40
            present = sum((amount / ((1 + discount) ** (Decimal(period) / per_year)) for period, amount in cashflow.items()), Decimal(0))
    return {"option_id": option["id"], "currency": currency, "horizon_periods": horizon,
            "periods_per_year": per_year, "discount_rate": _text(discount), "rate_basis": option.get("rate_basis"),
            "line_count": len(rows), "complete": bool(rows) and not findings,
            "undiscounted_total": _text(total) if rows else None, "present_value": _text(present),
            "cashflow": [{"period": period, "amount": _text(amount)} for period, amount in sorted(cashflow.items())],
            "items": rows, "findings": findings}


@_calculate
def benefit_model(model):
    if not isinstance(model, dict):
        raise DomainError("Benefit inputs must be a JSON object.")
    required = ("volume", "effort_minutes", "improvement_fraction", "adoption_fraction", "review_minutes_per_case", "period", "basis")
    missing = [key for key in required if model.get(key) in (None, "")]
    if missing:
        return {"complete": False, "missing": missing, "net_hours": None}
    volume = _decimal(model["volume"], "eligible volume", minimum=0)
    effort = _decimal(model["effort_minutes"], "baseline effort minutes", minimum=0)
    improvement = _decimal(model["improvement_fraction"], "improvement fraction", minimum=0, maximum=1)
    adoption = _decimal(model["adoption_fraction"], "adoption fraction", minimum=0, maximum=1)
    review = _decimal(model["review_minutes_per_case"], "incremental review minutes", minimum=0)
    gross = volume * effort * improvement * adoption
    review_total = volume * adoption * review
    net_hours = (gross - review_total) / 60
    rate = _decimal(model.get("hourly_rate"), "hourly rate", required=False, minimum=0)
    if rate is not None and not model.get("currency"):
        raise DomainError("Supply the benefit valuation currency.")
    return {"complete": True, "period": model["period"], "basis": model["basis"],
            "gross_avoided_hours": _text(gross / 60), "incremental_review_hours": _text(review_total / 60),
            "net_hours": _text(net_hours), "valued_net_effort": _text(net_hours * rate) if rate is not None else None,
            "currency": model.get("currency"), "interpretation": "Scenario effort model; not measured savings or cash revenue."}


@_calculate
def roadmap_analysis(state):
    roadmap, pools = _index(state, "roadmap"), _index(state, "capacity_pools")
    findings, demands, proposed = [], defaultdict(Decimal), defaultdict(Decimal)
    for record in roadmap.values():
        for predecessor in record.get("predecessors") or []:
            if predecessor not in roadmap:
                findings.append({"code": "missing_predecessor", "record_id": record["id"], "predecessor": predecessor})
            elif record.get("start_date") and roadmap[predecessor].get("due_date") and roadmap[predecessor]["due_date"] > record["start_date"]:
                findings.append({"code": "dependency_date_conflict", "record_id": record["id"], "predecessor": predecessor})
        if record.get("start_date") and record.get("due_date") and record["due_date"] < record["start_date"]:
            findings.append({"code": "roadmap_date_order", "record_id": record["id"]})
        for demand in record.get("demands") or []:
            if not isinstance(demand, dict):
                raise DomainError("Every roadmap demand needs pool_id, period and quantity.")
            pool_id, period = demand.get("pool_id"), demand.get("period")
            if pool_id not in pools or not isinstance(period, str) or not period:
                findings.append({"code": "capacity_binding_missing", "record_id": record["id"], "demand": demand})
                continue
            quantity = _decimal(demand.get("quantity"), "capacity demand", minimum=0)
            if demand.get("unit") not in (None, "", pools[pool_id].get("unit")):
                raise DomainError("Capacity demand and pool units differ; no conversion was supplied.")
            key = (pool_id, period)
            if record.get("status") in ("planned", "in_progress"):
                demands[key] += quantity
            elif record.get("status") == "proposed":
                proposed[key] += quantity
    colors, stack, cycles = {}, [], []
    def visit(key):
        if colors.get(key) == 1:
            cycles.append(stack[stack.index(key):] + [key])
            return
        if colors.get(key) == 2:
            return
        colors[key] = 1
        stack.append(key)
        for predecessor in roadmap[key].get("predecessors") or []:
            if predecessor in roadmap:
                visit(predecessor)
        stack.pop()
        colors[key] = 2
    for key in roadmap:
        visit(key)
    for cycle in cycles:
        findings.append({"code": "dependency_cycle", "record_ids": cycle})
    capacity = []
    keys = set(demands) | set(proposed)
    for pool_id, pool in pools.items():
        keys.update((pool_id, period) for period in pool.get("availability", {}))
    for pool_id, period in sorted(keys):
        pool = pools[pool_id]
        available = _decimal(pool.get("availability", {}).get(period), "capacity availability", required=False, minimum=0)
        used, pending = demands[(pool_id, period)], proposed[(pool_id, period)]
        capacity.append({"pool_id": pool_id, "period": period, "unit": pool.get("unit"),
                         "available": _text(available), "committed_demand": _text(used), "proposed_demand": _text(pending),
                         "remaining": _text(available - used) if available is not None else None,
                         "oversubscribed": available is not None and used > available})
        if available is None and used:
            findings.append({"code": "availability_unknown", "pool_id": pool_id, "period": period})
    return {"capacity": capacity, "findings": findings, "dependency_cycles": cycles}


@_calculate
def measure_results(state, measure):
    """Keep cohorts, windows, phases and observation bases as distinct groups."""
    groups = defaultdict(list)
    for record in state.get("observations", []):
        if record.get("measure_id") == measure["id"]:
            groups[(record.get("cohort"), record.get("window"), record.get("phase"), record.get("basis_kind"))].append(record)
    rows = []
    for (cohort, window, phase, basis), records in sorted(groups.items(), key=lambda item: _json(item[0])):
        included, excluded, missing = [], [], []
        for record in records:
            if record.get("eligible") is False:
                excluded.append(record)
            elif record.get("eligible") is not True:
                missing.append(record)
            else:
                included.append(record)
        value, numerator, denominator, values = None, Decimal(0), Decimal(0), []
        usable = []
        for record in included:
            if measure["kind"] == "rate":
                n = _decimal(record.get("numerator"), "numerator", required=False, minimum=0)
                d = _decimal(record.get("denominator"), "denominator", required=False, minimum=0)
                if n is None or d is None:
                    missing.append(record)
                    continue
                if n > d:
                    raise DomainError("A rate numerator exceeds its eligible denominator.")
                numerator += n
                denominator += d
            elif measure["kind"] == "mean":
                v = _decimal(record.get("value"), "observed value", required=False)
                if v is None:
                    missing.append(record)
                    continue
                values.append(v)
            usable.append(record)
        if measure["kind"] == "rate" and denominator:
            value = numerator / denominator
        elif measure["kind"] == "mean" and values:
            value = sum(values, Decimal(0)) / len(values)
        elif measure["kind"] == "count":
            value = Decimal(len(usable))
        rows.append({"measure_id": measure["id"], "cohort": cohort, "window": window, "phase": phase, "basis_kind": basis,
                     "definition_cohort_match": cohort == measure.get("cohort"),
                     "sample_records": len(records), "usable_records": len(usable), "excluded_records": len(excluded),
                     "missing_records": len({r["id"] for r in missing}), "value": _text(value), "unit": measure.get("unit"),
                     "numerator": _text(numerator) if measure["kind"] == "rate" else None,
                     "denominator": _text(denominator) if measure["kind"] == "rate" else None,
                     "success_records": sum(r.get("outcome") == "success" for r in included),
                     "failure_records": sum(r.get("outcome") == "failure" for r in included),
                     "record_ids": [r["id"] for r in records],
                     "exclusions": [{"id": r["id"], "reason": r.get("exclusion_reason", "")} for r in excluded]})
    comparisons = []
    for baseline in rows:
        if baseline["phase"] != "baseline" or baseline["value"] is None:
            continue
        for observed in rows:
            if observed["phase"] != "observed" or observed["value"] is None:
                continue
            if baseline["definition_cohort_match"] and observed["definition_cohort_match"] and all(observed[key] == baseline[key] for key in ("cohort", "window", "basis_kind", "unit")):
                delta = Decimal(observed["value"]) - Decimal(baseline["value"])
                comparisons.append({"cohort": baseline["cohort"], "window": baseline["window"],
                                    "basis_kind": baseline["basis_kind"], "delta": _text(delta), "unit": baseline["unit"],
                                    "baseline_records": baseline["record_ids"], "observed_records": observed["record_ids"]})
    explicit = []
    for comparison in measure.get("comparisons") or []:
        if not isinstance(comparison, dict) or not comparison.get("rationale"):
            raise DomainError("An explicit before/after comparison needs a rationale for its selected windows.")
        cohort = comparison.get("cohort", measure["cohort"])
        if cohort != measure["cohort"]:
            raise DomainError("An explicit comparison must use the measurement definition's eligible cohort.")
        basis = comparison.get("basis_kind", "observed")
        baseline = [r for r in rows if r["phase"] == "baseline" and r["window"] == comparison.get("baseline_window")
                    and r["cohort"] == cohort and r["basis_kind"] == basis]
        observed = [r for r in rows if r["phase"] == "observed" and r["window"] == comparison.get("observed_window")
                    and r["cohort"] == cohort and r["basis_kind"] == basis]
        result = {"comparison": copy.deepcopy(comparison), "complete": False}
        if len(baseline) == len(observed) == 1 and baseline[0]["value"] is not None and observed[0]["value"] is not None:
            result.update(complete=True, delta=_text(Decimal(observed[0]["value"]) - Decimal(baseline[0]["value"])),
                          unit=measure["unit"], baseline_records=baseline[0]["record_ids"], observed_records=observed[0]["record_ids"])
        else:
            result["finding"] = "The selected source-bound before/after groups are incomplete or absent."
        explicit.append(result)
    target = _decimal(measure.get("target"), "target", required=False)
    for row in rows:
        row["target_met"] = None
        if row["phase"] == "observed" and row["definition_cohort_match"] and row["value"] is not None and target is not None:
            if measure.get("desired_direction") == "higher":
                row["target_met"] = Decimal(row["value"]) >= target
            elif measure.get("desired_direction") == "lower":
                row["target_met"] = Decimal(row["value"]) <= target
    return {"measure_id": measure["id"], "groups": rows, "matched_comparisons": comparisons,
            "explicit_comparisons": explicit,
            "target": measure.get("target"), "target_basis": measure.get("target_basis"),
            "note": "Only matching cohort, window, unit and basis groups are compared; unfavorable observations remain visible."}


def material_snapshot(state, use_case_id):
    use_case = _index(state, "use_cases").get(use_case_id)
    if use_case is None:
        raise DomainError("Select an existing use case.")
    airport_id = use_case.get("airport_id")
    selected = {"use_cases": [use_case],
                "airports": [record for record in state.get("airports", []) if record["id"] == airport_id]}
    for collection in ("organizations", "parameters", "capabilities"):
        selected[collection] = [r for r in state.get(collection, []) if r.get("airport_id") == airport_id]
    for collection in ("data_assets", "assessments", "risks", "options", "measures"):
        selected[collection] = [r for r in state.get(collection, []) if r.get("use_case_id") == use_case_id or
                                collection == "data_assets" and r.get("airport_id") == airport_id and not r.get("use_case_id")]
    option_ids = {r["id"] for r in selected["options"]}
    measure_ids = {r["id"] for r in selected["measures"]}
    selected["cost_items"] = [r for r in state.get("cost_items", []) if r.get("option_id") in option_ids or
                             any(a.get("option_id") in option_ids for a in r.get("allocations") or [])]
    selected["observations"] = [r for r in state.get("observations", []) if r.get("measure_id") in measure_ids]
    rubric_ids = {r.get("rubric_id") for r in selected["options"] + selected["assessments"]}
    selected["rubrics"] = [r for r in state.get("rubrics", []) if r["id"] in rubric_ids]
    source_ids = {r.get("source_id") for records in selected.values() for r in records if r.get("source_id")}
    selected["sources"] = [r for r in state.get("sources", []) if r["id"] in source_ids]
    return {name: copy.deepcopy(sorted(records, key=lambda r: r["id"])) for name, records in selected.items()}


def freeze_decision(state, use_case_id, option_id, actor, action, rationale, *,
                    decision_id=None, conditions=None, decided_at=None, next_review=None):
    """Record the operator's actual decision against exact material, without saving."""
    if option_id:
        option = _index(state, "options").get(option_id)
        if option is None or option.get("use_case_id") != use_case_id:
            raise DomainError("The selected option must belong to this use case.")
    snapshot = material_snapshot(state, use_case_id)
    record = {"id": decision_id or "decision-" + uuid.uuid4().hex[:16], "revision": 1,
              "use_case_id": use_case_id, "option_id": option_id, "actor": actor, "action": action,
              "rationale": rationale, "conditions": conditions or [], "next_review": next_review,
              "decided_at": decided_at or datetime.now(timezone.utc).isoformat(),
              "input_sha256": _hash(snapshot), "input_snapshot": snapshot}
    validate_record("decisions", record, state)
    return record


def analyze(state):
    """Return the complete current workpaper projection, keeping local failures visible."""
    if not isinstance(state, dict):
        raise DomainError("Project state must be a JSON object.")
    indexes = {name: _index(state, name) for name in _SPECS}
    findings, guidance = [], []
    for collection, records in indexes.items():
        for record in records.values():
            try:
                validate_record(collection, record, state)
            except DomainError as exc:
                findings.append({"code": "record_input", "collection": collection, "record_id": record["id"], "message": str(exc)})
    readiness = []
    domains = schema()["collections"]["capabilities"]["fields"]["domain"]["choices"]
    for airport in indexes["airports"].values():
        records = [r for r in indexes["capabilities"].values() if r.get("airport_id") == airport["id"]]
        profile = []
        for domain in domains:
            selected = [r for r in records if r.get("domain") == domain]
            profile.append({"domain": domain, "records": selected, "status": selected[0].get("status") if len(selected) == 1 else "unknown",
                            "evidence_present": len(selected) == 1 and bool(selected[0].get("evidence") or selected[0].get("source_id"))})
            if len(selected) > 1:
                findings.append({"code": "multiple_domain_records", "airport_id": airport["id"], "domain": domain, "record_ids": [r["id"] for r in selected]})
        readiness.append({"airport_id": airport["id"], "domains": profile,
                          "evidenced_domains": sum(p["evidence_present"] for p in profile), "domain_count": len(domains)})
    comparisons = []
    for option in indexes["options"].values():
        result = {"option_id": option["id"], "use_case_id": option.get("use_case_id"), "name": option.get("name"), "model": option.get("model")}
        try:
            result["cost"] = option_cost(state, option)
        except (DomainError, TypeError, KeyError) as exc:
            result["cost"] = {"complete": False, "error": str(exc)}
        if option.get("benefit_model") is not None:
            try:
                result["benefit"] = benefit_model(option["benefit_model"])
            except DomainError as exc:
                result["benefit"] = {"complete": False, "error": str(exc)}
        rubric = indexes["rubrics"].get(option.get("rubric_id"))
        if rubric:
            try:
                result["preference"] = weighted_comparison(rubric, option.get("scores") or {})
            except DomainError as exc:
                result["preference"] = {"complete": False, "error": str(exc)}
        comparisons.append(result)
    for use_case in indexes["use_cases"].values():
        for field in ("problem", "current_workflow", "owner", "objective", "cohort", "scope"):
            if not use_case.get(field):
                guidance.append({"use_case_id": use_case["id"], "kind": "collect_input", "field": field,
                                 "message": "Record " + field.replace("_", " ") + " for this airport process.", "owner": use_case.get("owner")})
        options = [o for o in comparisons if o["use_case_id"] == use_case["id"]]
        contexts = {(o.get("cost", {}).get("currency"), o.get("cost", {}).get("horizon_periods"), o.get("cost", {}).get("periods_per_year"))
                    for o in options if o.get("cost", {}).get("line_count")}
        if len(contexts) > 1:
            findings.append({"code": "option_cost_context_differs", "use_case_id": use_case["id"],
                             "message": "Align currency, period and horizon before comparing option totals."})
        scopes = {indexes["options"][o["option_id"]].get("scope") for o in options}
        if len(scopes) > 1 or None in scopes or "" in scopes:
            findings.append({"code": "option_scope_review", "use_case_id": use_case["id"],
                             "message": "Alternatives have different or missing scope descriptions; review functional equivalence."})
        discounted = {(o["cost"].get("discount_rate"), o["cost"].get("rate_basis")) for o in options
                      if o.get("cost", {}).get("present_value") is not None}
        if len(discounted) > 1:
            findings.append({"code": "option_discount_basis_differs", "use_case_id": use_case["id"],
                             "message": "Present values use different discount assumptions; align those assumptions before ranking."})
    for asset in indexes["data_assets"].values():
        for field in ("custodian", "permitted_use", "coverage", "access_method"):
            if not asset.get(field):
                guidance.append({"use_case_id": asset.get("use_case_id"), "record_id": asset["id"],
                                 "collection": "data_assets", "kind": "collect_input", "field": field,
                                 "message": "Record " + field.replace("_", " ") + " for this data asset.",
                                 "owner": asset.get("custodian")})
    for item in indexes["roadmap"].values():
        for field in ("owner", "acceptance", "maintenance_owner", "exit_owner"):
            if not item.get(field):
                guidance.append({"use_case_id": item.get("use_case_id"), "record_id": item["id"],
                                 "collection": "roadmap", "kind": "collect_input", "field": field,
                                 "message": "Record " + field.replace("_", " ") + " for this implementation work.",
                                 "owner": item.get("owner")})
    decisions = []
    for decision in indexes["decisions"].values():
        result = {"decision_id": decision["id"], "action": decision.get("action"), "actor": decision.get("actor")}
        if decision.get("input_snapshot") is None or not decision.get("input_sha256"):
            result.update(status="unbound", message="No retained reviewed inputs were supplied for this record.")
        elif _hash(decision["input_snapshot"]) != decision["input_sha256"]:
            result.update(status="snapshot_hash_mismatch", message="Retained decision material does not match its recorded digest.")
        else:
            try:
                current = material_snapshot(state, decision["use_case_id"])
                result["current_sha256"] = _hash(current)
                result["status"] = "current" if result["current_sha256"] == decision["input_sha256"] else "inputs_changed"
                result["changed_collections"] = [name for name in sorted(set(current) | set(decision["input_snapshot"]))
                                                  if _hash(current.get(name, [])) != _hash(decision["input_snapshot"].get(name, []))]
            except DomainError as exc:
                result.update(status="inputs_missing", message=str(exc))
        decisions.append(result)
    try:
        roadmap = roadmap_analysis(state)
    except (DomainError, TypeError, KeyError) as exc:
        roadmap = {"capacity": [], "findings": [{"code": "roadmap_input", "message": str(exc)}]}
    measures = []
    for measure in indexes["measures"].values():
        try:
            measures.append(measure_results(state, measure))
        except (DomainError, TypeError, KeyError) as exc:
            measures.append({"measure_id": measure["id"], "error": str(exc)})
    return {"schema": SCHEMA, "summary": {"counts": {name: len(values) for name, values in indexes.items()},
                                         "input_findings": len(findings), "guided_inputs": len(guidance)},
            "findings": findings, "guidance": guidance, "readiness": readiness,
            "option_comparisons": comparisons, "decisions": decisions, "roadmap": roadmap,
            "measurement": measures, "research": copy.deepcopy(state.get("research", [])),
            "organizations": copy.deepcopy(state.get("organizations", []))}
